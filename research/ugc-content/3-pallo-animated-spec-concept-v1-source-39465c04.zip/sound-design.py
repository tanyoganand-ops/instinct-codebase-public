import numpy as np
from scipy.signal import butter,sosfilt
from scipy.io import wavfile
from pathlib import Path
p=Path('/downloads/pallo-concept-v1');sr=48000;out=np.zeros((sr*15,2));rng=np.random.default_rng(13)
# Quiet stereo air sweeps. Each crest is aligned with the fast part of a slide, not the held asset.
events=[(.08,.85,.075,-.5),(.22,.8,.065,.5),(4.67,.85,.072,.7),(4.87,.85,.067,-.7),(10.23,.85,.065,-.7),(10.47,.85,.068,.7)]
for start,dur,amp,pan in events:
 n=int(dur*sr);t=np.linspace(0,1,n);noise=rng.normal(0,1,n);low=sosfilt(butter(2,950,fs=sr,output='sos'),noise);high=sosfilt(butter(2,[1600,8000],btype='bandpass',fs=sr,output='sos'),noise);wave=(low*(1-t)+high*t)*np.sin(np.pi*t)**1.7;wave/=max(np.max(np.abs(wave)),1e-9);wave*=amp;idx=int(start*sr);stereo=np.column_stack((wave*np.sqrt((1-pan)/2),wave*np.sqrt((1+pan)/2)));out[idx:idx+n]+=stereo
wavfile.write(p/'whooshes.wav',sr,(np.clip(out,-1,1)*32767).astype(np.int16));(p/'whoosh-cues.txt').write_text('\n'.join(f'{s:.2f}s duration {d:.2f}s peak {a:.3f}' for s,d,a,_ in events))
