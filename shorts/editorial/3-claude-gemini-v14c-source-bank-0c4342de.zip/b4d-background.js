window.b4dBG=(()=>{const W=1080,H=1920;const root=document.getElementById('root');const lerp=(a,b,p)=>a+(b-a)*p;
function rng(s){return()=>{s=(s*1664525+1013904223)>>>0;return s/4294967296}}
const R=rng(7);
const PAL=[['#fbd9c8','#f0b79b','#d99879'],['#cfe2f6','#a9c8ec','#86a9d4'],['#d4eddf','#acd8bf','#86bb9e'],['#cfe0f8','#9cbcec','#7a9bd2'],['#fbf0bd','#f1dc8a','#d8bf62'],['#f8d3de','#eeb0c3','#d38ea5']];
const SVG={
 term:'<svg viewBox="0 0 100 100" width="62%" height="62%"><path d="M22 28 L48 50 L22 72" fill="none" stroke="#5b6b7e" stroke-width="11" stroke-linecap="round" stroke-linejoin="round"/><path d="M54 74 H80" stroke="#5b6b7e" stroke-width="11" stroke-linecap="round"/></svg>',
 gear:'<svg viewBox="0 0 100 100" width="62%" height="62%"><circle cx="50" cy="50" r="20" fill="none" stroke="#5b6b7e" stroke-width="11"/><g stroke="#5b6b7e" stroke-width="11" stroke-linecap="round"><path d="M50 10V22M50 78V90M10 50H22M78 50H90M22 22L30 30M70 70L78 78M78 22L70 30M30 70L22 78"/></g></svg>',
 check:'<svg viewBox="0 0 100 100" width="62%" height="62%"><path d="M24 54 L43 72 L77 30" fill="none" stroke="#5b6b7e" stroke-width="12" stroke-linecap="round" stroke-linejoin="round"/></svg>',
 bars:'<svg viewBox="0 0 100 100" width="62%" height="62%"><g fill="#5b6b7e"><rect x="18" y="52" width="16" height="30" rx="6"/><rect x="42" y="30" width="16" height="52" rx="6"/><rect x="66" y="42" width="16" height="40" rx="6"/></g></svg>'
};
// ---------- lanes
const lanes=[];
function clayShape(kind,size,pal){
 const [l,m,d]=pal;const e=document.createElement('div');e.className='clay';
 let w=size,h=size,br='50%';
 if(kind==='pill'){w=size*1.7;h=size*.62;br=h/2+'px'}
 if(kind==='cube'||kind==='chip'){br=size*.26+'px'}
 e.style.cssText+=`width:${w}px;height:${h}px;border-radius:${br};background:radial-gradient(circle at 30% 26%,${l} 0,${m} 58%,${d} 130%);box-shadow:${size*.08}px ${size*.12}px ${size*.18}px ${d}66,inset ${-size*.05}px ${-size*.07}px ${size*.1}px ${d}55,inset ${size*.05}px ${size*.05}px ${size*.1}px #ffffffb0;display:flex;align-items:center;justify-content:center`;
 e.dataset.w=w;e.dataset.h=h;return e;
}
function mk(lane,kind,size,y,x0,pi,extra={}){
 const spec={back:{sp:120,blur:1.6,op:.42,z:1},mid:{sp:270,blur:0,op:1,z:2},fore:{sp:620,blur:6,op:.8,z:6}}[lane];
 let e,w,h;
 if(kind==='sphereimg'||kind==='donutimg'){e=document.createElement('img');e.src='assets/'+(kind==='sphereimg'?'clay-sphere':'clay-donut')+'.png';e.style.cssText=`position:absolute;left:0;top:0;width:${size}px;height:${size}px;filter:drop-shadow(${size*.05}px ${size*.08}px ${size*.07}px #7a869433)`;w=h=size}
 else if(kind==='logoC'||kind==='logoG'){e=document.createElement('div');e.className='clay';const lw=size*1.9,lh=size*.78;e.style.cssText+=`width:${lw}px;height:${lh}px;border-radius:${lh*.3}px;background:linear-gradient(145deg,#fffefd,#ecece8);box-shadow:10px 14px 24px #9aa6b338,inset 4px 4px 8px #fff,inset -4px -5px 10px #c9d0d84d;display:flex;align-items:center;justify-content:center`;const im=document.createElement('img');im.src='assets/'+(kind==='logoC'?'Claude-logo-Slate-0aff1e24.png':'Gemini-logo-2025-32a9eb8b.png');im.className='lg';im.style.cssText=`width:${lw*.74}px;height:auto`;e.appendChild(im);w=lw;h=lh}
 else{e=clayShape(kind==='chip'?'chip':kind,size,PAL[pi%PAL.length]);w=+e.dataset.w;h=+e.dataset.h;if(extra.icon)e.innerHTML=SVG[extra.icon]}
 const wrap=document.createElement('div');wrap.className='lane';wrap.setAttribute('data-layout-allow-overflow','');wrap.style.zIndex=spec.z;wrap.appendChild(e);
 wrap.style.opacity=spec.op*(extra.op||1);if(spec.blur)wrap.style.filter=`blur(${spec.blur}px)`;
 root.appendChild(wrap);
 lanes.push({baseOpacity:spec.op*(extra.op||1),el:e,anim:extra.anim||'',wrap,w,h,y,x0,sp:spec.sp*(extra.spm||1),lane,tilt:extra.tilt||0,ph:R()*6.28,bob:extra.bob??(lane==='fore'?10:lane==='mid'?14:8)});
}
// back lane (soft, small, behind everything)
[['sphere',90,160,0,1],['pill',90,980,900,0],['cube',80,1180,500,3],['sphere',110,1380,0,1],['cube',90,1600,640,5],['sphere',100,420,1300,4]].forEach(a=>mk('back',a[0],a[1],a[2],a[3],a[4],{tilt:(R()-.5)*20,anim:'pulse'}));
// mid lane (sharp, story assets)
mk('mid','sphereimg',190,360,0,0,{anim:'squash'});mk('mid','donutimg',230,1010,700,0,{anim:'wobble'});mk('mid','chip',170,760,350,1,{icon:'term',tilt:-6,anim:'hop'});mk('mid','logoC',110,170,500,0);mk('mid','logoG',110,1700,1100,0);mk('mid','chip',150,1560,200,5,{icon:'bars',tilt:6,anim:'hop2'});
// fore lane (large, blurred, outside the text band)
[['sphereimg',280,40,0,'squash'],['pill',230,1440,250,'wave'],['donutimg',400,1620,500,'wobble']].forEach((a,i)=>mk('fore',a[0],a[1],a[2],a[3],i+1,{tilt:(R()-.5)*16,anim:a[4]}));


function hopT(t,per,ph,H,sx){const p=((t/per)+ph/6.283)%1;const air=p<.45?Math.sin(Math.PI*p/.45):0;const lp=p>=.45&&p<.58?Math.sin(Math.PI*(p-.45)/.13):0;
 return `translateY(${-H*air}px) scale(${1+sx*.1*lp-sx*.04*air},${1-sx*.13*lp+sx*.07*air})`}
function animT(L,t){const ph=L.ph;switch(L.anim){
 case 'hop':return hopT(t,2.3,ph,55,1);case 'hop2':return hopT(t,2.7,ph,45,1);case 'squash':return hopT(t,1.8,ph,L.w*.22,1.2);
 case 'wobble':return `perspective(700px) rotateX(${20*Math.sin(t*1.3+ph)}deg) rotateY(${26*Math.sin(t*.9+ph*1.7)}deg)`;
 case 'wave':return `skewX(${9*Math.sin(t*2+ph)}deg) scaleY(${1+.08*Math.sin(t*4+ph)})`;
 case 'pulse':return `scale(${1+.07*Math.sin(t*2+ph)})`;default:return ''}}

return {update(t){ // lanes
 for(const L of lanes){const P=W+L.w;const u=(L.x0+L.sp*t)%P;const x=W-u;const y=L.y+L.bob*Math.sin(6.283*t/3.1+L.ph);
  const prog=u/P;const zs=L.lane==='fore'?lerp(.55,1.25,Math.sin(prog*3.1416)):L.lane==='mid'?lerp(.8,1.12,Math.sin(prog*3.1416)):1;L.wrap.style.transformOrigin=`${L.w/2}px ${L.h/2}px`;L.wrap.style.transform=`translate(${x}px,${y-L.h/2}px) scale(${zs}) rotate(${L.tilt+.5*Math.sin(t*1.7+L.ph)}deg)`;L.x=x;L.yc=y;const inBand=L.lane!=='fore'&&y>275&&y<1255;const left=48-L.w*zs,right=890;const entering=Math.max(0,Math.min(1,(x-left)/80)),leaving=Math.max(0,Math.min(1,(right-x)/80));const mask=entering*leaving;L.wrap.style.opacity=L.baseOpacity*(inBand?1-.96*mask:1);if(L.anim){L.el.style.transformOrigin=(L.anim==='hop'||L.anim==='hop2'||L.anim==='squash')?'50% 100%':'50% 50%';L.el.style.transform=animT(L,t)}
  if(L.anim==='hop2'){[...L.wrap.querySelectorAll('rect')].forEach((r,i)=>{const h=18+36*(.5+.5*Math.sin(t*2.6+i*1.4));r.setAttribute('height',h);r.setAttribute('y',82-h)})}
  if(L.anim==='hop'){const pth=L.wrap.querySelectorAll('path')[1];if(pth)pth.setAttribute('opacity',.2+.8*(.5+.5*Math.sin(t*5.5)))}}
}}})();