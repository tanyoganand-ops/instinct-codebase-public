// B6 whip-pan module. Pure functions of frame number f (30fps). No GSAP.
const WHIP_FPS=30;
// bezier(.85,0,.15,1) solved by bisection. Returns 0..1.
function whipEase(t,a=.85,b=0,c=.15,d=1){t=Math.max(0,Math.min(1,t));let lo=0,hi=1;
 const bx=u=>3*(1-u)**2*u*a+3*(1-u)*u*u*c+u**3,by=u=>3*(1-u)**2*u*b+3*(1-u)*u*u*d+u**3;
 for(let i=0;i<30;i++){const m=(lo+hi)/2;bx(m)<t?lo=m:hi=m}return by((lo+hi)/2)}
const WHIP_FRAMES=9;            // total whip length (8-10 reads right, <6 glitchy)
// whips = array of centre frames, e.g. [90,198,306,384]. Use a SUBSET for "sparing" use.
// cam(f): fractional scene index. Integer = settled on that scene.
function cam(f,whips,len=WHIP_FRAMES){let c=0;for(const w of whips)c+=whipEase((f-(w-4))/len);return c}
// Scene i's offset in px for an asset with parallax factor k (>=1 = arrives later, leaves faster -> staggered streaks).
function sceneX(i,camPos,k=1,W=1080){return (i-camPos)*W*k}
// Per-asset k used in B6 (stagger so assets land one after another): headline 1.0, label 1.12, row A 1.25, row B 1.5,
// card A 1.2, card B 1.45, verdict line1 1.0 / line2 1.3, logo tiles 1.6 / 1.9, CTA pill 1.1, caveat 1.5.
const K={head:1,label:1.12,rowA:1.25,rowB:1.5,cardA:1.2,cardB:1.45,v1:1,v2:1.3,tileA:1.6,tileB:1.9,cta:1.1,cav:1.5};
// Directional motion blur: stdDeviation (px, horizontal only) from this frame's x velocity.
function blurSD(x,prevX,gain=.42,cap=48){return prevX==null?0:Math.min(cap,Math.abs(x-prevX)*gain)}
// Apply in DOM: <filter id="fN" x="-80%" y="-20%" width="260%" height="140%"><feGaussianBlur stdDeviation="0 0"/></filter>
//   filterEl.firstChild.setAttribute('stdDeviation',`${sd} 0`); el.style.filter = sd>.5?`url(#fN)`:'none';
// Idle motion between whips (keeps every frame moving; amplitudes fit inside the safe rect):
const idleY=(f,seed)=>7*Math.sin(f/30*2.2+seed), idleX=(f,seed)=>4*Math.sin(f/30*1.9+seed);
const restScale=(f,seed)=>.962+.008*Math.sin(f/30*2.6+seed)+.008; // <=0.978 so 840px boxes stay in safe rect
// Margin travellers (zoom on/off): scale = (s0+(s1-s0)p)*(.7+.3 sin(pi p)), alpha=min(1,min(p,1-p)*6), p=0..1 over 75-125 frames,
// plus -cam*kc*220 px coupling so they streak with the whips (kc .3-1.2), SVG blur gain .3 cap 40.
