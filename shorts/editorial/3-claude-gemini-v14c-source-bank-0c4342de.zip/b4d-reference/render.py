import json,subprocess,time,base64,sys,os,urllib.request,websocket
os.makedirs('frames',exist_ok=True)
p=subprocess.Popen(['google-chrome','--headless=new','--no-sandbox','--disable-gpu','--hide-scrollbars','--force-device-scale-factor=1','--window-size=1080,1920','--allow-file-access-from-files','--remote-debugging-port=9333','--user-data-dir=/tmp/chp','--remote-allow-origins=*','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(6)
tabs=json.load(urllib.request.urlopen('http://127.0.0.1:9333/json'))
tab=[t for t in tabs if t['type']=='page'][0]
ws=websocket.create_connection(tab['webSocketDebuggerUrl'],max_size=None)
n=0
def call(m,**p):
    global n;n+=1;ws.send(json.dumps({'id':n,'method':m,'params':p}))
    while True:
        r=json.loads(ws.recv())
        if r.get('id')==n:return r
call('Emulation.setDeviceMetricsOverride',width=1080,height=1920,deviceScaleFactor=1,mobile=False)
call('Page.navigate',url='file:///tmp/b/index.html');time.sleep(2)
def ev(e):
    r=call('Runtime.evaluate',expression=e,returnByValue=True,awaitPromise=True)
    if 'exceptionDetails' in r['result']:print(r['result']['exceptionDetails']);sys.exit(1)
    return r['result']['result'].get('value')
ev('document.fonts.ready.then(()=>1)')
N=int(sys.argv[1]) if len(sys.argv)>1 else 450
aud=[]
for i in range(N):
    ev(f'seek({i}/30)')
    a=ev('audit()');a['i']=i;aud.append(a)
    r=call('Page.captureScreenshot',format='png',captureBeyondViewport=False)
    open(f'frames/f{i:04d}.png','wb').write(base64.b64decode(r['result']['data']))
json.dump(aud,open('audit.json','w'))
p.terminate()
