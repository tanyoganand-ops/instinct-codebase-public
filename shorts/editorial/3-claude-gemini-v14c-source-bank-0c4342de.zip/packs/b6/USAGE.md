# B6 whip-pan pack
Source cut: b6-whip-pan-claude-gemini.mp4 (P, WhatsApp 11:51: "we can use sparingly for some of them").

| Piece | What it does | Parameters |
|---|---|---|
| whipEase / cam | Lateral scene swap, bezier .85,0,.15,1 | 9 frames, centred on the swap frame (start = centre-4) |
| sceneX + K | Each asset travels at its own multiple of the swap distance, so assets streak off/on staggered, never as one slab | k 1.0 to 1.9 (higher = lands later, leaves faster) |
| blurSD | Horizontal-only motion blur from per-frame velocity | gain .42, cap 48 px, SVG feGaussianBlur "sd 0" |
| idle* / restScale | Bob/sway/breathing so nothing sits still between whips | y 7px, x 4px, scale .954-.978 |
| Travellers | Margin clay assets zoom on/off and ride the whip | see bottom of whip.js |

Sparing use: pass a short `whips` array (e.g. only [198,306]) and let the other beats change with your other transitions. Scenes not in the list never move laterally; cam() stays constant.
Wiring: per frame compute c=cam(f,whips); each asset x = baseX + sceneX(sceneIndex,c,k) + idleX; blur from x minus previous frame's x. Keep essential text inside x48-888/y288-1248 whenever c is an integer (verified: 0 violations outside whip frames; blurred text is in transit during the 9 whip frames).
Gotchas: slow drift would push 840px text out of the safe rect, so idle x stays at +/-4px and rest scale <1. Render deterministically (seek(frame), CDP screenshot per frame, ffmpeg -framerate 30). Full reference build: render.cjs + index.html in b6-whip-pan-source.zip.
