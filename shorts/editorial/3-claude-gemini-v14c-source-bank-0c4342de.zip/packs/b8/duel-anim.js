/* B8 duel animation pack. Pure functions of time t (seconds). No GSAP. Call once per frame: apply(t).
   Units: px in a "stage" container. Elements are absolutely positioned at left:0/top:0 and moved via transform. */
export const clamp=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
// Easings: out=cubic ease-out, io=cubic in-out, back=overshoot (c=1.5, ~10% overshoot), lin
export const E={lin:x=>x,io:x=>x<.5?4*x*x*x:1-Math.pow(-2*x+2,3)/2,out:x=>1-Math.pow(1-x,3),
  back:x=>{const c=1.5,d=c+1;return 1+d*Math.pow(x-1,3)+c*Math.pow(x-1,2)}};
// Keyframes: kf(t,[[t0,v0],[t1,v1,'back'],...]) - ease named on the destination key.
export function kf(t,k){if(t<=k[0][0])return k[0][1];for(let i=1;i<k.length;i++)if(t<=k[i][0]){const a=k[i-1],b=k[i];return a[1]+(b[1]-a[1])*E[b[2]||'io']((t-a[0])/(b[0]-a[0]))}return k[k.length-1][1]}
export const bob=(t,ph,a=9)=>a*Math.sin(t*3.1+ph);   // idle float, ~2s period, never fully still

/* 1. LATERAL ENTER/EXIT: asset slides in from off-stage with overshoot, holds, leaves. OFF = stage width/2 + margin (480).
   fromLeft: kf(t,[[t0,-OFF],[t0+.7,0,'back'],[tHold,0],[tHold+.6,-OFF,'io']])   (right side: +OFF)
   Pair them opposite: first asset from left at t0, second from right at t0+.2 (stagger .2s). */
export const lateral=(t,t0,t1,side=-1,OFF=480,inD=.7,outD=.6)=>kf(t,[[t0,side*OFF],[t0+inD,0,'back'],[t1,0],[t1+outD,side*OFF,'io']]);

/* 2. TRADE (card swap): two cards cross to each other's slot (x 0 <-> 440), one arcs up+larger+rotates -28deg, other down+smaller+28deg.
   Tune: ta = start, d = .65s travel to midpoint, total 1.3s. Returns CSS transform strings. */
export function trade(t,ta,xA=0,xB=440,y=250,arc=70,d=.65){
  const tm=ta+d,te=ta+2*d;
  const xa=kf(t,[[ta,xA],[te,xB,'io']]),xb=kf(t,[[ta,xB],[te,xA,'io']]);
  const ya=kf(t,[[ta,0],[tm,-arc,'io'],[te,0,'io']]),yb=kf(t,[[ta,0],[tm,arc,'io'],[te,0,'io']]);
  const sa=kf(t,[[ta,1],[tm,1.1,'io'],[te,1,'io']]),sb=kf(t,[[ta,1],[tm,.9,'io'],[te,1,'io']]);
  const ra=kf(t,[[ta,0],[tm,-28,'io'],[te,0,'io']]),rb=kf(t,[[ta,0],[tm,28,'io'],[te,0,'io']]);
  const f=(x,yy,s,r)=>`translate(${x}px,${y+yy}px) perspective(1400px) rotateY(${r}deg) scale(${s})`;
  return {a:f(xa,ya,sa,ra),b:f(xb,yb,sb,rb),aFront:sa>1};   // set zIndex of A above B when aFront
}
/* 3. LEADS BADGE PASS: badge flies in from off-left (x -300) with overshoot over .5s, rides the card, exits left (-400) .5s.
   Second badge (other card) enters from off-right (+500). Badge sits at card-x+110, card-y-28. */
export const badgeX=(t,tIn,tOut,side=-1)=>kf(t,[[tIn,side>0?500:-300],[tIn+.5,0,'back'],[tOut,0],[tOut+.5,-400,'io']]);
// Loser dip: trailing card drops 18px: kf(t,[[t0,0],[t0+.4,18,'out'],[t1,18],[t1+.65,0,'io']])
/* 4. COUNT-UP: integer 0->v over 1.1s, ease-out. Bar width % = same value. */
export const count=(t,t0,v,d=1.1)=>Math.round(v*E.out(clamp((t-t0)/d)));
/* 5. VS COIN: pops up from below (y 900 -> 330) with overshoot .6s, holds .5s, drops out .5s. wobble rotate +-8deg. */
export const coinY=(t,t0)=>kf(t,[[t0,900],[t0+.6,330,'back'],[t0+1.1,330],[t0+1.6,900,'io']]);
/* 6. CHIP SWAP: two logo chips from opposite sides settle (x 40 / 420), then swap with a 50px opposite vertical split (.6s), hold, leave opposite. */
export function chips(t,t0,t1){
  const a=kf(t,[[t0,-480],[t0+.7,40,'back'],[t0+1.3,40],[t0+1.9,420,'io'],[t1,420],[t1+.6,480,'io']]);
  const b=kf(t,[[t0+.2,480],[t0+.9,420,'back'],[t0+1.3,420],[t0+1.9,40,'io'],[t1,40],[t1+.6,-480,'io']]);
  const ya=kf(t,[[t0+1.3,0],[t0+1.6,-50,'io'],[t0+1.9,0,'io']]);return {xa:a,xb:b,ya:ya,yb:-ya}}
/* 7. CTA PILL: scale .6->1 with overshoot while flying from right (+480) and up (640->330), .7s. */

/* ===== BACKGROUND TREATMENT =====
   Pale #f4f4f1 + two soft radial washes (blue top-left #e3ecf5, rose bottom-right #f4e6e3).
   11 clay props (sphere/donut PNG) travel LINEARLY across the full 1080 frame in both directions, wrapping off-screen,
   with scale pulse .8-1.1 (sin(1.6t)), +-18px vertical bob, slow rotation (14deg/s). Far ones blurred 1-2px and lower opacity.
   spec = [kind,size,y,speed px/s (sign=direction),phase 0-1,opacity,blurPx] */
export const BG_SPECS=[['sphere',300,1500,70,.1,.9,0],['donut',240,1620,-90,.5,.85,0],['donut',170,120,80,.8,.8,1],['sphere',140,200,-110,.2,.7,1.5],
['sphere',220,1340,-60,.7,.55,2],['donut',130,1450,120,.3,.6,1.5],['sphere',190,40,-75,.35,.7,0],['donut',320,1760,50,.9,.9,0],
['sphere',110,1280,-140,.55,.6,1.5],['donut',150,1700,-100,.15,.75,1],['sphere',100,330,95,.65,.55,2]];
export const BG_CSS=`#bg{position:absolute;inset:0;background:radial-gradient(ellipse at 20% 15%,#e3ecf5 0,transparent 55%),radial-gradient(ellipse at 85% 80%,#f4e6e3 0,transparent 55%)}`;
export function bgInit(container,assetDir='assets/'){return BG_SPECS.map(s=>{const im=new Image();im.src=assetDir+'clay-'+s[0]+'.png';im.style.cssText=`position:absolute;left:0;top:0;width:${s[1]}px;height:${s[1]}px;opacity:${s[5]};`+(s[6]?`filter:blur(${s[6]}px)`:'');container.appendChild(im);return [im,s]})}
export function bgUpdate(props,t){props.forEach(([im,s])=>{const sp=s[3],span=1080+s[1]*2+200;let x=((sp*t+s[4]*span)%span+span)%span;if(sp<0)x=span-x;x-=s[1]+100;
  const sc=.8+.3*Math.sin(t*1.6+s[4]*9),y=s[2]+18*Math.sin(t*1.9+s[4]*7);
  im.style.transform=`translate(${x}px,${y}px) scale(${sc}) rotate(${(t*14*Math.sign(sp)+s[4]*90)%360}deg)`})}
