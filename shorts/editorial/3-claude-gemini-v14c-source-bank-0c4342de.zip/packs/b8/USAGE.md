# B8 duel animation pack

Files: duel-anim.js (ES module, all motion as pure functions of t), assets/clay-sphere.png + clay-donut.png (bg props). Reference build: B8-duel-source.zip (index.html shows full wiring; frames rendered with `render.cjs`).
How to use: each frame compute values from t (seconds) and write them to element transforms. Deterministic, so frame-by-frame rendering (puppeteer screenshot per frame) works. Stage = 840x960 container at (48,288) with overflow:hidden so slides clip to the safe rect; bg layer is full-frame behind it.

| Piece | What it does | Key params |
|---|---|---|
| lateral(t,t0,t1,side) | slide in from off-stage with overshoot, hold, slide out | side -1 left / +1 right; in .7s back-ease, out .6s; pair opposite sides, stagger .2s |
| trade(t,ta,...) | two cards cross to swap slots: one arcs up, bigger (1.1), rotateY -28; other down, smaller (.9), +28 | 1.3s total, arc 70px, perspective 1400px; raise A's z-index while aFront |
| badgeX + dip | LEADS badge flies in (.5s overshoot), rides card, exits; trailing card dips 18px | badge at card x+110, y-28; dip .4s out-ease |
| count(t,t0,v) | score count-up 0..v | 1.1s ease-out; bar fill = same % |
| coinY | VS coin pops from below with overshoot, wobbles +-8deg, drops out | 150px circle, 1.6s total |
| chips(t,t0,t1) | two logo chips enter opposite sides, swap places with a vertical split, leave opposite | swap 0.6s, split 50px |
| CTA pill | scale .6->1 + fly from right/below, overshoot | .7s |
| bob(t,ph,a) | idle float so nothing is ever still | 9px default, ~2s period |
| bgInit/bgUpdate | pale bg + 11 clay props crossing the frame both ways with scale pulse, blur on far ones | see BG_SPECS; bg colours in BG_CSS |

Drop-in: import, call bgInit once on a full-frame div, then per frame `bgUpdate(props,t)` plus set your element transforms from the functions above. All times are seconds; shift t0 args to re-time. Swap in other content by changing the card DOM only.
Notes: logos/text should be inside the clipped stage; scores in B8 reset to "--" during the trade and recount (count()). Overshoot uses c=1.5 (about 10%); lower c in E.back for subtler settle (P wants animations used sparingly in some cuts).
