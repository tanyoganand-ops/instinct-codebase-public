# V13 saved frame plan

450 deterministic states saved before final rendering. Full transforms, text, opacities and bounds in frames-v13.json. Visible-text and overlap audit in 450-text-audit.json.

One whip centred on frame 198. Essential layer clips to x48-888/y288-1248, including entrances/exits. Raw travelling bounds intentionally leave the safe stage; visible content never leaves it.

|Frame|Time|Beat|Visible essential assets|Text overlaps|
|---|---|---|---|---|
|0|0.000|Hook||0|
|1|0.033|Hook|#hookH|0|
|2|0.067|Hook|#hookH|0|
|3|0.100|Hook|#hookH|0|
|4|0.133|Hook|#hookH|0|
|5|0.167|Hook|#hookH|0|
|6|0.200|Hook|#hookH, #hookA|0|
|7|0.233|Hook|#hookH, #hookA|0|
|8|0.267|Hook|#hookH, #hookA|0|
|9|0.300|Hook|#hookH, #hookA|0|
|10|0.333|Hook|#hookH, #hookA|0|
|11|0.367|Hook|#hookH, #hookA|0|
|12|0.400|Hook|#hookH, #hookA|0|
|13|0.433|Hook|#hookH, #hookA, #hookB|0|
|14|0.467|Hook|#hookH, #hookA, #hookB|0|
|15|0.500|Hook|#hookH, #hookA, #hookB|0|
|16|0.533|Hook|#hookH, #hookA, #hookB|0|
|17|0.567|Hook|#hookH, #hookA, #hookB|0|
|18|0.600|Hook|#hookH, #hookA, #hookB|0|
|19|0.633|Hook|#hookH, #hookA, #hookB|0|
|20|0.667|Hook|#hookH, #hookA, #hookB|0|
|21|0.700|Hook|#hookH, #hookA, #hookB|0|
|22|0.733|Hook|#hookH, #hookA, #hookB, #hookL|0|
|23|0.767|Hook|#hookH, #hookA, #hookB, #hookL|0|
|24|0.800|Hook|#hookH, #hookA, #hookB, #hookL|0|
|25|0.833|Hook|#hookH, #hookA, #hookB, #hookL|0|
|26|0.867|Hook|#hookH, #hookA, #hookB, #hookL|0|
|27|0.900|Hook|#hookH, #hookA, #hookB, #hookL|0|
|28|0.933|Hook|#hookH, #hookA, #hookB, #hookL|0|
|29|0.967|Hook|#hookH, #hookA, #hookB, #hookL|0|
|30|1.000|Hook|#hookH, #hookA, #hookB, #hookL|0|
|31|1.033|Hook|#hookH, #hookA, #hookB, #hookL|0|
|32|1.067|Hook|#hookH, #hookA, #hookB, #hookL|0|
|33|1.100|Hook|#hookH, #hookA, #hookB, #hookL|0|
|34|1.133|Hook|#hookH, #hookA, #hookB, #hookL|0|
|35|1.167|Hook|#hookH, #hookA, #hookB, #hookL|0|
|36|1.200|Hook|#hookH, #hookA, #hookB, #hookL|0|
|37|1.233|Hook|#hookH, #hookA, #hookB, #hookL|0|
|38|1.267|Hook|#hookH, #hookA, #hookB, #hookL|0|
|39|1.300|Hook|#hookH, #hookA, #hookB, #hookL|0|
|40|1.333|Hook|#hookH, #hookA, #hookB, #hookL|0|
|41|1.367|Hook|#hookH, #hookA, #hookB, #hookL|0|
|42|1.400|Hook|#hookH, #hookA, #hookB, #hookL|0|
|43|1.433|Hook|#hookH, #hookA, #hookB, #hookL|0|
|44|1.467|Hook|#hookH, #hookA, #hookB, #hookL|0|
|45|1.500|Hook|#hookH, #hookA, #hookB, #hookL|0|
|46|1.533|Hook|#hookH, #hookA, #hookB, #hookL|0|
|47|1.567|Hook|#hookH, #hookA, #hookB, #hookL|0|
|48|1.600|Hook|#hookH, #hookA, #hookB, #hookL|0|
|49|1.633|Hook|#hookH, #hookA, #hookB, #hookL|0|
|50|1.667|Hook|#hookH, #hookA, #hookB, #hookL|0|
|51|1.700|Hook|#hookH, #hookA, #hookB, #hookL|0|
|52|1.733|Hook|#hookH, #hookA, #hookB, #hookL|0|
|53|1.767|Hook|#hookH, #hookA, #hookB, #hookL|0|
|54|1.800|Hook|#hookH, #hookA, #hookB, #hookL|0|
|55|1.833|Hook|#hookH, #hookA, #hookB, #hookL|0|
|56|1.867|Hook|#hookH, #hookA, #hookB, #hookL|0|
|57|1.900|Hook|#hookH, #hookA, #hookB, #hookL|0|
|58|1.933|Hook|#hookH, #hookA, #hookB, #hookL|0|
|59|1.967|Hook|#hookH, #hookA, #hookB, #hookL|0|
|60|2.000|Hook|#hookH, #hookA, #hookB, #hookL|0|
|61|2.033|Hook|#hookH, #hookA, #hookB, #hookL|0|
|62|2.067|Hook|#hookH, #hookA, #hookB, #hookL|0|
|63|2.100|Hook|#hookH, #hookA, #hookB, #hookL|0|
|64|2.133|Hook|#hookH, #hookA, #hookB, #hookL|0|
|65|2.167|Hook|#hookH, #hookA, #hookB, #hookL|0|
|66|2.200|Terminal-Bench|#hookA, #hookB|0|
|67|2.233|Terminal-Bench|#hookA, #hookB, #h0, #p0, #r0|0|
|68|2.267|Terminal-Bench|#hookB, #h0, #p0, #r0|0|
|69|2.300|Terminal-Bench|#hookB, #h0, #p0, #r0|0|
|70|2.333|Terminal-Bench|#hookB, #h0, #p0, #r0|0|
|71|2.367|Terminal-Bench|#hookB, #h0, #c0a, #p0, #r0|0|
|72|2.400|Terminal-Bench|#hookB, #h0, #c0a, #p0, #r0|0|
|73|2.433|Terminal-Bench|#h0, #c0a, #p0, #r0|0|
|74|2.467|Terminal-Bench|#h0, #c0a, #p0, #r0|0|
|75|2.500|Terminal-Bench|#h0, #c0a, #p0, #r0|0|
|76|2.533|Terminal-Bench|#h0, #c0a, #p0, #r0|0|
|77|2.567|Terminal-Bench|#h0, #c0a, #p0, #r0|0|
|78|2.600|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|79|2.633|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|80|2.667|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|81|2.700|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|82|2.733|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|83|2.767|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|84|2.800|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|85|2.833|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|86|2.867|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|87|2.900|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|88|2.933|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|89|2.967|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|90|3.000|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|91|3.033|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|92|3.067|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|93|3.100|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|94|3.133|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|95|3.167|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|96|3.200|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|97|3.233|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|98|3.267|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|99|3.300|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|100|3.333|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|101|3.367|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|102|3.400|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|103|3.433|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|104|3.467|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|105|3.500|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|106|3.533|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|107|3.567|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|108|3.600|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|109|3.633|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|110|3.667|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|111|3.700|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|112|3.733|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|113|3.767|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|114|3.800|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|115|3.833|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|116|3.867|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|117|3.900|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|118|3.933|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|119|3.967|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|120|4.000|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|121|4.033|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|122|4.067|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|123|4.100|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|124|4.133|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|125|4.167|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|126|4.200|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|127|4.233|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|128|4.267|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|129|4.300|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|130|4.333|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|131|4.367|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|132|4.400|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|133|4.433|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|134|4.467|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|135|4.500|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|136|4.533|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|137|4.567|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|138|4.600|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|139|4.633|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|140|4.667|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|141|4.700|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|142|4.733|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|143|4.767|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|144|4.800|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|145|4.833|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|146|4.867|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|147|4.900|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|148|4.933|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|149|4.967|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|150|5.000|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|151|5.033|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|152|5.067|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|153|5.100|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|154|5.133|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|155|5.167|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|156|5.200|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|157|5.233|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|158|5.267|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|159|5.300|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|160|5.333|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|161|5.367|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|162|5.400|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|163|5.433|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|164|5.467|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|165|5.500|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|166|5.533|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|167|5.567|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|168|5.600|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|169|5.633|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|170|5.667|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|171|5.700|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|172|5.733|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|173|5.767|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|174|5.800|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|175|5.833|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|176|5.867|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|177|5.900|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|178|5.933|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|179|5.967|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|180|6.000|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|181|6.033|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|182|6.067|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|183|6.100|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|184|6.133|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|185|6.167|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|186|6.200|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|187|6.233|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|188|6.267|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|189|6.300|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|190|6.333|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|191|6.367|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|192|6.400|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|193|6.433|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|194|6.467|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|195|6.500|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|196|6.533|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0, #lead0|0|
|197|6.567|Terminal-Bench|#h0, #c0a, #c0b, #p0, #r0|0|
|198|6.600|AutomationBench-AA|#h0, #c0a, #c0b, #p0, #r0, #h1|0|
|199|6.633|AutomationBench-AA|#h0, #h1, #c1a, #p1, #r1|0|
|200|6.667|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|201|6.700|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|202|6.733|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|203|6.767|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|204|6.800|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|205|6.833|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|206|6.867|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|207|6.900|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|208|6.933|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|209|6.967|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|210|7.000|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|211|7.033|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|212|7.067|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|213|7.100|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|214|7.133|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|215|7.167|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|216|7.200|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|217|7.233|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|218|7.267|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|219|7.300|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|220|7.333|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|221|7.367|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|222|7.400|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|223|7.433|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|224|7.467|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|225|7.500|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|226|7.533|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|227|7.567|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|228|7.600|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|229|7.633|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|230|7.667|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|231|7.700|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|232|7.733|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|233|7.767|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|234|7.800|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|235|7.833|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|236|7.867|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|237|7.900|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|238|7.933|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|239|7.967|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|240|8.000|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|241|8.033|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|242|8.067|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|243|8.100|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|244|8.133|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|245|8.167|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|246|8.200|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|247|8.233|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|248|8.267|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|249|8.300|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|250|8.333|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|251|8.367|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|252|8.400|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|253|8.433|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|254|8.467|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|255|8.500|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|256|8.533|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|257|8.567|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|258|8.600|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|259|8.633|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|260|8.667|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|261|8.700|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|262|8.733|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|263|8.767|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|264|8.800|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|265|8.833|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|266|8.867|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|267|8.900|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|268|8.933|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|269|8.967|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|270|9.000|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|271|9.033|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|272|9.067|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|273|9.100|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|274|9.133|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|275|9.167|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|276|9.200|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|277|9.233|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|278|9.267|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|279|9.300|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|280|9.333|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|281|9.367|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|282|9.400|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|283|9.433|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|284|9.467|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|285|9.500|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|286|9.533|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|287|9.567|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|288|9.600|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|289|9.633|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|290|9.667|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|291|9.700|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|292|9.733|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|293|9.767|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|294|9.800|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|295|9.833|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|296|9.867|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1, #lead1|0|
|297|9.900|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|298|9.933|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|299|9.967|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|300|10.000|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|301|10.033|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|302|10.067|AutomationBench-AA|#h1, #c1a, #c1b, #p1, #r1|0|
|303|10.100|AutomationBench-AA||0|
|304|10.133|AutomationBench-AA|#chipa|0|
|305|10.167|Verdict|#chipa|0|
|306|10.200|Verdict|#vh, #chipa|0|
|307|10.233|Verdict|#vh, #chipa|0|
|308|10.267|Verdict|#vh, #chipa|0|
|309|10.300|Verdict|#vh, #chipa|0|
|310|10.333|Verdict|#vh, #chipa, #chipb|0|
|311|10.367|Verdict|#vh, #chipa, #chipb|0|
|312|10.400|Verdict|#vh, #chipa, #chipb|0|
|313|10.433|Verdict|#vh, #chipa, #chipb, #vl|0|
|314|10.467|Verdict|#vh, #chipa, #chipb, #vl|0|
|315|10.500|Verdict|#vh, #chipa, #chipb, #vl|0|
|316|10.533|Verdict|#vh, #chipa, #chipb, #vl|0|
|317|10.567|Verdict|#vh, #chipa, #chipb, #vl|0|
|318|10.600|Verdict|#vh, #chipa, #chipb, #vl|0|
|319|10.633|Verdict|#vh, #chipa, #chipb, #vl|0|
|320|10.667|Verdict|#vh, #chipa, #chipb, #vl|0|
|321|10.700|Verdict|#vh, #chipa, #chipb, #vl|0|
|322|10.733|Verdict|#vh, #chipa, #chipb, #vl|0|
|323|10.767|Verdict|#vh, #chipa, #chipb, #vl|0|
|324|10.800|Verdict|#vh, #chipa, #chipb, #vl|0|
|325|10.833|Verdict|#vh, #chipa, #chipb, #vl|0|
|326|10.867|Verdict|#vh, #chipa, #chipb, #vl|0|
|327|10.900|Verdict|#vh, #chipa, #chipb, #vl|0|
|328|10.933|Verdict|#vh, #chipa, #chipb, #vl|0|
|329|10.967|Verdict|#vh, #chipa, #chipb, #vl|0|
|330|11.000|Verdict|#vh, #chipa, #chipb, #vl|0|
|331|11.033|Verdict|#vh, #chipa, #chipb, #vl|0|
|332|11.067|Verdict|#vh, #chipa, #chipb, #vl|0|
|333|11.100|Verdict|#vh, #chipa, #chipb, #vl|0|
|334|11.133|Verdict|#vh, #chipa, #chipb, #vl|0|
|335|11.167|Verdict|#vh, #chipa, #chipb, #vl|0|
|336|11.200|Verdict|#vh, #chipa, #chipb, #vl|0|
|337|11.233|Verdict|#vh, #chipa, #chipb, #vl|0|
|338|11.267|Verdict|#vh, #chipa, #chipb, #vl|0|
|339|11.300|Verdict|#vh, #chipa, #chipb, #vl|0|
|340|11.333|Verdict|#vh, #chipa, #chipb, #vl|0|
|341|11.367|Verdict|#vh, #chipa, #chipb, #vl|0|
|342|11.400|Verdict|#vh, #chipa, #chipb, #vl|0|
|343|11.433|Verdict|#vh, #chipa, #chipb, #vl|0|
|344|11.467|Verdict|#vh, #chipa, #chipb, #vl|0|
|345|11.500|Verdict|#vh, #chipa, #chipb, #vl|0|
|346|11.533|Verdict|#vh, #chipa, #chipb, #vl|0|
|347|11.567|Verdict|#vh, #chipa, #chipb, #vl|0|
|348|11.600|Verdict|#vh, #chipa, #chipb, #vl|0|
|349|11.633|Verdict|#vh, #chipa, #chipb, #vl|0|
|350|11.667|Verdict|#vh, #chipa, #chipb, #vl|0|
|351|11.700|Verdict|#vh, #chipa, #chipb, #vl|0|
|352|11.733|Verdict|#vh, #chipa, #chipb, #vl|0|
|353|11.767|Verdict|#vh, #chipa, #chipb, #vl|0|
|354|11.800|Verdict|#vh, #chipa, #chipb, #vl|0|
|355|11.833|Verdict|#vh, #chipa, #chipb, #vl|0|
|356|11.867|Verdict|#vh, #chipa, #chipb, #vl|0|
|357|11.900|Verdict|#vh, #chipa, #chipb, #vl|0|
|358|11.933|Verdict|#vh, #chipa, #chipb, #vl|0|
|359|11.967|Verdict|#vh, #chipa, #chipb, #vl|0|
|360|12.000|Verdict|#vh, #chipa, #chipb, #vl|0|
|361|12.033|Verdict|#vh, #chipa, #chipb, #vl|0|
|362|12.067|Verdict|#vh, #chipa, #chipb, #vl|0|
|363|12.100|Verdict|#vh, #chipa, #chipb, #vl|0|
|364|12.133|Verdict|#vh, #chipa, #chipb, #vl|0|
|365|12.167|Verdict|#vh, #chipa, #chipb, #vl|0|
|366|12.200|Verdict|#vh, #chipa, #chipb, #vl|0|
|367|12.233|Verdict|#vh, #chipa, #chipb, #vl|0|
|368|12.267|Verdict|#vh, #chipa, #chipb, #vl|0|
|369|12.300|Verdict|#vh, #chipa, #chipb, #vl|0|
|370|12.333|Verdict|#vh, #chipa, #chipb, #vl|0|
|371|12.367|Verdict|#vh, #chipa, #chipb, #vl|0|
|372|12.400|Verdict|#vh, #chipa, #chipb, #vl|0|
|373|12.433|Verdict|#vh, #chipa, #chipb, #vl|0|
|374|12.467|Verdict|#vh, #chipa, #chipb, #vl|0|
|375|12.500|Verdict|#chipa, #chipb|0|
|376|12.533|Verdict|#chipa, #chipb|0|
|377|12.567|CTA|#chipa, #chipb|0|
|378|12.600|CTA|#chipa, #chipb, #ch|0|
|379|12.633|CTA|#chipa, #chipb, #ch|0|
|380|12.667|CTA|#chipa, #chipb, #ch|0|
|381|12.700|CTA|#ch, #cta|0|
|382|12.733|CTA|#ch, #cta|0|
|383|12.767|CTA|#ch, #cta|0|
|384|12.800|CTA|#ch, #cta|0|
|385|12.833|CTA|#ch, #cta|0|
|386|12.867|CTA|#ch, #cta|0|
|387|12.900|CTA|#ch, #cta|0|
|388|12.933|CTA|#ch, #cta|0|
|389|12.967|CTA|#ch, #cta|0|
|390|13.000|CTA|#ch, #cta|0|
|391|13.033|CTA|#ch, #cta|0|
|392|13.067|CTA|#ch, #cta|0|
|393|13.100|CTA|#ch, #cta, #cav|0|
|394|13.133|CTA|#ch, #cta, #cav, #cf|0|
|395|13.167|CTA|#ch, #cta, #cav, #cf|0|
|396|13.200|CTA|#ch, #cta, #cav, #cf|0|
|397|13.233|CTA|#ch, #cta, #cav, #cf|0|
|398|13.267|CTA|#ch, #cta, #cav, #cf|0|
|399|13.300|CTA|#ch, #cta, #cav, #cf|0|
|400|13.333|CTA|#ch, #cta, #cav, #cf|0|
|401|13.367|CTA|#ch, #cta, #cav, #cf|0|
|402|13.400|CTA|#ch, #cta, #cav, #cf|0|
|403|13.433|CTA|#ch, #cta, #cav, #cf|0|
|404|13.467|CTA|#ch, #cta, #cav, #cf|0|
|405|13.500|CTA|#ch, #cta, #cav, #cf|0|
|406|13.533|CTA|#ch, #cta, #cav, #cf|0|
|407|13.567|CTA|#ch, #cta, #cav, #cf|0|
|408|13.600|CTA|#ch, #cta, #cav, #cf|0|
|409|13.633|CTA|#ch, #cta, #cav, #cf|0|
|410|13.667|CTA|#ch, #cta, #cav, #cf|0|
|411|13.700|CTA|#ch, #cta, #cav, #cf|0|
|412|13.733|CTA|#ch, #cta, #cav, #cf|0|
|413|13.767|CTA|#ch, #cta, #cav, #cf|0|
|414|13.800|CTA|#ch, #cta, #cav, #cf|0|
|415|13.833|CTA|#ch, #cta, #cav, #cf|0|
|416|13.867|CTA|#ch, #cta, #cav, #cf|0|
|417|13.900|CTA|#ch, #cta, #cav, #cf|0|
|418|13.933|CTA|#ch, #cta, #cav, #cf|0|
|419|13.967|CTA|#ch, #cta, #cav, #cf|0|
|420|14.000|CTA|#ch, #cta, #cav, #cf|0|
|421|14.033|CTA|#ch, #cta, #cav, #cf|0|
|422|14.067|CTA|#ch, #cta, #cav, #cf|0|
|423|14.100|CTA|#ch, #cta, #cav, #cf|0|
|424|14.133|CTA|#ch, #cta, #cav, #cf|0|
|425|14.167|CTA|#ch, #cta, #cav, #cf|0|
|426|14.200|CTA|#ch, #cta, #cav, #cf|0|
|427|14.233|CTA|#ch, #cta, #cav, #cf|0|
|428|14.267|CTA|#ch, #cta, #cav, #cf|0|
|429|14.300|CTA|#ch, #cta, #cav, #cf|0|
|430|14.333|CTA|#ch, #cta, #cav, #cf|0|
|431|14.367|CTA|#ch, #cta, #cav, #cf|0|
|432|14.400|CTA|#ch, #cta, #cav, #cf|0|
|433|14.433|CTA|#ch, #cta, #cav, #cf|0|
|434|14.467|CTA|#ch, #cta, #cav, #cf|0|
|435|14.500|CTA|#ch, #cta, #cav, #cf|0|
|436|14.533|CTA|#ch, #cta, #cav, #cf|0|
|437|14.567|CTA|#ch, #cta, #cav, #cf|0|
|438|14.600|CTA|#ch, #cta, #cav, #cf|0|
|439|14.633|CTA|#ch, #cta, #cav, #cf|0|
|440|14.667|CTA|#ch, #cta, #cav, #cf|0|
|441|14.700|CTA|#ch, #cta, #cav, #cf|0|
|442|14.733|CTA|#ch, #cta, #cav, #cf|0|
|443|14.767|CTA|#ch, #cta, #cav, #cf|0|
|444|14.800|CTA|#ch, #cta, #cav, #cf|0|
|445|14.833|CTA|#ch, #cta, #cav, #cf|0|
|446|14.867|CTA|#ch, #cta, #cav, #cf|0|
|447|14.900|CTA|#ch, #cta, #cav, #cf|0|
|448|14.933|CTA|#ch, #cta, #cav, #cf|0|
|449|14.967|CTA|#ch, #cta, #cav, #cf|0|
