# B3b - Blank-card fix

Same B3 content, composition, springs, stagger, travel, type, palette, logos and beat timing. Changed only the card visibility: clay card surfaces and all their contents now appear and disappear together, with a 70ms opacity ramp. A surface cannot remain visible while its essential copy is masked.

450-frame audit: zero visible blank-card frames and zero visible essential-bound violations inside x48-888/y288-1248. Encoded frame hashes: zero identical adjacent pairs. ffprobe: 1080x1920, 30fps, 450 frames, 15.000 seconds, H.264, no audio stream. Final encoded contact sheet visually checked: correct scores, verdict, CTA, source and rollout caveat; no blank clay cards in sampled handoffs.

Remaining limitation: a brief gap remains where cards are absent during some handoffs. This fixes blank surfaces, not their original beat timing. Existing spring residual and low safe-region composition unchanged. No full-speed playback inspection.
