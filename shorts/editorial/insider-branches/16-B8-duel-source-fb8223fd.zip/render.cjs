const p=require('puppeteer-core');const fs=require('fs');
(async()=>{const [a,b]=process.argv.slice(2).map(Number);
const br=await p.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--font-render-hinting=none'],headless:'new'});
const pg=await br.newPage();await pg.setViewport({width:1080,height:1920});
await pg.goto('file:///tmp/w/duel/index.html');await pg.evaluate(()=>document.fonts.ready);await new Promise(r=>setTimeout(r,500));
fs.mkdirSync('/tmp/w/duel/f',{recursive:true});
const audit=[];
for(let i=a;i<b;i++){const t=i/30;await pg.evaluate(t=>render(t),t);
 const v=await pg.evaluate(()=>{const sf=document.getElementById('safe').getBoundingClientRect();const o=[];
  document.querySelectorAll('[data-t]').forEach(e=>{if(getComputedStyle(e).opacity==0||getComputedStyle(e).display=='none')return;const r=document.createRange();r.selectNodeContents(e);const q=r.getBoundingClientRect();
  const cs=parseFloat(getComputedStyle(e).fontSize);
  // visible portion
  const l=Math.max(q.left,sf.left),rr=Math.min(q.right,sf.right);const vis=rr>l;o.push([e.id||e.textContent.slice(0,12),Math.round(q.left),Math.round(q.right),Math.round(q.top),Math.round(q.bottom),cs,e.textContent.slice(0,14)])});return o});
 audit.push([i,v]);
 await pg.screenshot({path:`/tmp/w/duel/f/${String(i).padStart(4,'0')}.png`,optimizeForSpeed:true});}
fs.writeFileSync(`/tmp/w/duel/audit-${a}.json`,JSON.stringify(audit));await br.close()})();
