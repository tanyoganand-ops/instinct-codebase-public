const {spawn}=require('child_process'),fs=require('fs');
(async()=>{fs.mkdirSync('frames',{recursive:true});
const ch=spawn('google-chrome',['--headless=new','--no-sandbox','--disable-gpu','--hide-scrollbars','--remote-debugging-port='+(9333+(+process.argv[5]||0)),'--user-data-dir=/tmp/ud'+(process.argv[5]||0),'--force-device-scale-factor=1','--window-size=1080,1920','--allow-file-access-from-files','about:blank'],{stdio:'ignore'});
let list;for(let i=0;i<50;i++){try{list=await (await fetch('http://127.0.0.1:'+(9333+(+process.argv[5]||0))+'/json')).json();if(list.find(x=>x.type==='page'))break}catch(e){}await new Promise(r=>setTimeout(r,300))}
const ws=new WebSocket(list.find(x=>x.type==='page').webSocketDebuggerUrl);await new Promise(r=>ws.onopen=r);let id=0;const pend={};
ws.onmessage=m=>{const d=JSON.parse(m.data);if(d.id&&pend[d.id]){pend[d.id](d.result||d);delete pend[d.id]}};
const call=(method,params={})=>new Promise(r=>{const i=++id;pend[i]=r;ws.send(JSON.stringify({id:i,method,params}))});
await call('Page.enable');await call('Emulation.setDeviceMetricsOverride',{width:1080,height:1920,deviceScaleFactor:1,mobile:false});
await call('Page.navigate',{url:'file:///tmp/w/b6/index.html'});await new Promise(r=>setTimeout(r,1500));
await call('Runtime.evaluate',{expression:'document.fonts.ready.then(()=>1)',awaitPromise:true});
const audit=[];const start=+process.argv[2]||0,end=+process.argv[3]||450;
const only=process.argv[4]&&process.argv[4]!=='-'?process.argv[4].split(",").map(Number):null;for(let f=start;f<end;f++){if(only&&!only.includes(f))continue;{const r=await call('Runtime.evaluate',{expression:`JSON.stringify(seek(${f}))`,returnByValue:true});audit.push(JSON.parse(r.result.value));
const s=await call('Page.captureScreenshot',{format:'png'});fs.writeFileSync(`frames/f${String(f).padStart(4,'0')}.png`,Buffer.from(s.data,'base64'));}}
fs.writeFileSync(`audit-${start}.json`,JSON.stringify(audit));ch.kill();process.exit(0)})();
