# B1 frame plan

Every frame carries the exact asset positions and text in frames-b1.json.

|Frame|Seconds|Primary beat|
|---|---|---|
|0|0.000|Hook|
|1|0.033|Hook|
|2|0.067|Hook|
|3|0.100|Hook|
|4|0.133|Hook|
|5|0.167|Hook|
|6|0.200|Hook|
|7|0.233|Hook|
|8|0.267|Hook|
|9|0.300|Hook|
|10|0.333|Hook|
|11|0.367|Hook|
|12|0.400|Hook|
|13|0.433|Hook|
|14|0.467|Hook|
|15|0.500|Hook|
|16|0.533|Hook|
|17|0.567|Hook|
|18|0.600|Hook|
|19|0.633|Hook|
|20|0.667|Hook|
|21|0.700|Hook|
|22|0.733|Hook|
|23|0.767|Hook|
|24|0.800|Hook|
|25|0.833|Hook|
|26|0.867|Hook|
|27|0.900|Hook|
|28|0.933|Hook|
|29|0.967|Hook|
|30|1.000|Hook|
|31|1.033|Hook|
|32|1.067|Hook|
|33|1.100|Hook|
|34|1.133|Hook|
|35|1.167|Hook|
|36|1.200|Hook|
|37|1.233|Hook|
|38|1.267|Hook|
|39|1.300|Hook|
|40|1.333|Hook|
|41|1.367|Hook|
|42|1.400|Hook|
|43|1.433|Hook|
|44|1.467|Hook|
|45|1.500|Hook|
|46|1.533|Hook|
|47|1.567|Hook|
|48|1.600|Hook|
|49|1.633|Hook|
|50|1.667|Hook|
|51|1.700|Hook|
|52|1.733|Hook|
|53|1.767|Hook|
|54|1.800|Hook|
|55|1.833|Hook|
|56|1.867|Hook|
|57|1.900|Hook|
|58|1.933|Hook|
|59|1.967|Hook|
|60|2.000|Hook|
|61|2.033|Hook|
|62|2.067|Hook|
|63|2.100|Hook|
|64|2.133|Hook|
|65|2.167|Hook|
|66|2.200|Hook|
|67|2.233|Hook|
|68|2.267|Hook|
|69|2.300|Hook|
|70|2.333|Hook|
|71|2.367|Hook|
|72|2.400|Hook|
|73|2.433|Hook|
|74|2.467|Terminal-Bench|
|75|2.500|Terminal-Bench|
|76|2.533|Terminal-Bench|
|77|2.567|Terminal-Bench|
|78|2.600|Terminal-Bench|
|79|2.633|Terminal-Bench|
|80|2.667|Terminal-Bench|
|81|2.700|Terminal-Bench|
|82|2.733|Terminal-Bench|
|83|2.767|Terminal-Bench|
|84|2.800|Terminal-Bench|
|85|2.833|Terminal-Bench|
|86|2.867|Terminal-Bench|
|87|2.900|Terminal-Bench|
|88|2.933|Terminal-Bench|
|89|2.967|Terminal-Bench|
|90|3.000|Terminal-Bench|
|91|3.033|Terminal-Bench|
|92|3.067|Terminal-Bench|
|93|3.100|Terminal-Bench|
|94|3.133|Terminal-Bench|
|95|3.167|Terminal-Bench|
|96|3.200|Terminal-Bench|
|97|3.233|Terminal-Bench|
|98|3.267|Terminal-Bench|
|99|3.300|Terminal-Bench|
|100|3.333|Terminal-Bench|
|101|3.367|Terminal-Bench|
|102|3.400|Terminal-Bench|
|103|3.433|Terminal-Bench|
|104|3.467|Terminal-Bench|
|105|3.500|Terminal-Bench|
|106|3.533|Terminal-Bench|
|107|3.567|Terminal-Bench|
|108|3.600|Terminal-Bench|
|109|3.633|Terminal-Bench|
|110|3.667|Terminal-Bench|
|111|3.700|Terminal-Bench|
|112|3.733|Terminal-Bench|
|113|3.767|Terminal-Bench|
|114|3.800|Terminal-Bench|
|115|3.833|Terminal-Bench|
|116|3.867|Terminal-Bench|
|117|3.900|Terminal-Bench|
|118|3.933|Terminal-Bench|
|119|3.967|Terminal-Bench|
|120|4.000|Terminal-Bench|
|121|4.033|Terminal-Bench|
|122|4.067|Terminal-Bench|
|123|4.100|Terminal-Bench|
|124|4.133|Terminal-Bench|
|125|4.167|Terminal-Bench|
|126|4.200|Terminal-Bench|
|127|4.233|Terminal-Bench|
|128|4.267|Terminal-Bench|
|129|4.300|Terminal-Bench|
|130|4.333|Terminal-Bench|
|131|4.367|Terminal-Bench|
|132|4.400|Terminal-Bench|
|133|4.433|Terminal-Bench|
|134|4.467|Terminal-Bench|
|135|4.500|Terminal-Bench|
|136|4.533|Terminal-Bench|
|137|4.567|Terminal-Bench|
|138|4.600|Terminal-Bench|
|139|4.633|Terminal-Bench|
|140|4.667|Terminal-Bench|
|141|4.700|Terminal-Bench|
|142|4.733|Terminal-Bench|
|143|4.767|Terminal-Bench|
|144|4.800|Terminal-Bench|
|145|4.833|Terminal-Bench|
|146|4.867|Terminal-Bench|
|147|4.900|Terminal-Bench|
|148|4.933|Terminal-Bench|
|149|4.967|Terminal-Bench|
|150|5.000|Terminal-Bench|
|151|5.033|Terminal-Bench|
|152|5.067|Terminal-Bench|
|153|5.100|Terminal-Bench|
|154|5.133|Terminal-Bench|
|155|5.167|Terminal-Bench|
|156|5.200|Terminal-Bench|
|157|5.233|Terminal-Bench|
|158|5.267|Terminal-Bench|
|159|5.300|Terminal-Bench|
|160|5.333|Terminal-Bench|
|161|5.367|Terminal-Bench|
|162|5.400|Terminal-Bench|
|163|5.433|Terminal-Bench|
|164|5.467|Terminal-Bench|
|165|5.500|Terminal-Bench|
|166|5.533|Terminal-Bench|
|167|5.567|Terminal-Bench|
|168|5.600|Terminal-Bench|
|169|5.633|Terminal-Bench|
|170|5.667|Terminal-Bench|
|171|5.700|Terminal-Bench|
|172|5.733|Terminal-Bench|
|173|5.767|Terminal-Bench|
|174|5.800|Terminal-Bench|
|175|5.833|Terminal-Bench|
|176|5.867|AutomationBench|
|177|5.900|AutomationBench|
|178|5.933|AutomationBench|
|179|5.967|AutomationBench|
|180|6.000|AutomationBench|
|181|6.033|AutomationBench|
|182|6.067|AutomationBench|
|183|6.100|AutomationBench|
|184|6.133|AutomationBench|
|185|6.167|AutomationBench|
|186|6.200|AutomationBench|
|187|6.233|AutomationBench|
|188|6.267|AutomationBench|
|189|6.300|AutomationBench|
|190|6.333|AutomationBench|
|191|6.367|AutomationBench|
|192|6.400|AutomationBench|
|193|6.433|AutomationBench|
|194|6.467|AutomationBench|
|195|6.500|AutomationBench|
|196|6.533|AutomationBench|
|197|6.567|AutomationBench|
|198|6.600|AutomationBench|
|199|6.633|AutomationBench|
|200|6.667|AutomationBench|
|201|6.700|AutomationBench|
|202|6.733|AutomationBench|
|203|6.767|AutomationBench|
|204|6.800|AutomationBench|
|205|6.833|AutomationBench|
|206|6.867|AutomationBench|
|207|6.900|AutomationBench|
|208|6.933|AutomationBench|
|209|6.967|AutomationBench|
|210|7.000|AutomationBench|
|211|7.033|AutomationBench|
|212|7.067|AutomationBench|
|213|7.100|AutomationBench|
|214|7.133|AutomationBench|
|215|7.167|AutomationBench|
|216|7.200|AutomationBench|
|217|7.233|AutomationBench|
|218|7.267|AutomationBench|
|219|7.300|AutomationBench|
|220|7.333|AutomationBench|
|221|7.367|AutomationBench|
|222|7.400|AutomationBench|
|223|7.433|AutomationBench|
|224|7.467|AutomationBench|
|225|7.500|AutomationBench|
|226|7.533|AutomationBench|
|227|7.567|AutomationBench|
|228|7.600|AutomationBench|
|229|7.633|AutomationBench|
|230|7.667|AutomationBench|
|231|7.700|AutomationBench|
|232|7.733|AutomationBench|
|233|7.767|AutomationBench|
|234|7.800|AutomationBench|
|235|7.833|AutomationBench|
|236|7.867|AutomationBench|
|237|7.900|AutomationBench|
|238|7.933|AutomationBench|
|239|7.967|AutomationBench|
|240|8.000|AutomationBench|
|241|8.033|AutomationBench|
|242|8.067|AutomationBench|
|243|8.100|AutomationBench|
|244|8.133|AutomationBench|
|245|8.167|AutomationBench|
|246|8.200|AutomationBench|
|247|8.233|AutomationBench|
|248|8.267|AutomationBench|
|249|8.300|AutomationBench|
|250|8.333|AutomationBench|
|251|8.367|AutomationBench|
|252|8.400|AutomationBench|
|253|8.433|AutomationBench|
|254|8.467|AutomationBench|
|255|8.500|AutomationBench|
|256|8.533|AutomationBench|
|257|8.567|AutomationBench|
|258|8.600|AutomationBench|
|259|8.633|AutomationBench|
|260|8.667|AutomationBench|
|261|8.700|AutomationBench|
|262|8.733|AutomationBench|
|263|8.767|AutomationBench|
|264|8.800|AutomationBench|
|265|8.833|AutomationBench|
|266|8.867|AutomationBench|
|267|8.900|AutomationBench|
|268|8.933|AutomationBench|
|269|8.967|AutomationBench|
|270|9.000|AutomationBench|
|271|9.033|AutomationBench|
|272|9.067|AutomationBench|
|273|9.100|AutomationBench|
|274|9.133|AutomationBench|
|275|9.167|AutomationBench|
|276|9.200|AutomationBench|
|277|9.233|AutomationBench|
|278|9.267|Verdict|
|279|9.300|Verdict|
|280|9.333|Verdict|
|281|9.367|Verdict|
|282|9.400|Verdict|
|283|9.433|Verdict|
|284|9.467|Verdict|
|285|9.500|Verdict|
|286|9.533|Verdict|
|287|9.567|Verdict|
|288|9.600|Verdict|
|289|9.633|Verdict|
|290|9.667|Verdict|
|291|9.700|Verdict|
|292|9.733|Verdict|
|293|9.767|Verdict|
|294|9.800|Verdict|
|295|9.833|Verdict|
|296|9.867|Verdict|
|297|9.900|Verdict|
|298|9.933|Verdict|
|299|9.967|Verdict|
|300|10.000|Verdict|
|301|10.033|Verdict|
|302|10.067|Verdict|
|303|10.100|Verdict|
|304|10.133|Verdict|
|305|10.167|Verdict|
|306|10.200|Verdict|
|307|10.233|Verdict|
|308|10.267|Verdict|
|309|10.300|Verdict|
|310|10.333|Verdict|
|311|10.367|Verdict|
|312|10.400|Verdict|
|313|10.433|Verdict|
|314|10.467|Verdict|
|315|10.500|Verdict|
|316|10.533|Verdict|
|317|10.567|Verdict|
|318|10.600|Verdict|
|319|10.633|Verdict|
|320|10.667|Verdict|
|321|10.700|Verdict|
|322|10.733|Verdict|
|323|10.767|Verdict|
|324|10.800|Verdict|
|325|10.833|Verdict|
|326|10.867|Verdict|
|327|10.900|Verdict|
|328|10.933|Verdict|
|329|10.967|Verdict|
|330|11.000|Verdict|
|331|11.033|Verdict|
|332|11.067|Verdict|
|333|11.100|Verdict|
|334|11.133|Verdict|
|335|11.167|Verdict|
|336|11.200|Verdict|
|337|11.233|Verdict|
|338|11.267|Verdict|
|339|11.300|Verdict|
|340|11.333|Verdict|
|341|11.367|Verdict|
|342|11.400|Verdict|
|343|11.433|Verdict|
|344|11.467|Verdict|
|345|11.500|Verdict|
|346|11.533|Verdict|
|347|11.567|Verdict|
|348|11.600|Verdict|
|349|11.633|Verdict|
|350|11.667|Verdict|
|351|11.700|Verdict|
|352|11.733|Verdict|
|353|11.767|Verdict|
|354|11.800|Verdict|
|355|11.833|Verdict|
|356|11.867|Verdict|
|357|11.900|Verdict|
|358|11.933|Verdict|
|359|11.967|Verdict|
|360|12.000|Verdict|
|361|12.033|Verdict|
|362|12.067|Verdict|
|363|12.100|Comment CTA|
|364|12.133|Comment CTA|
|365|12.167|Comment CTA|
|366|12.200|Comment CTA|
|367|12.233|Comment CTA|
|368|12.267|Comment CTA|
|369|12.300|Comment CTA|
|370|12.333|Comment CTA|
|371|12.367|Comment CTA|
|372|12.400|Comment CTA|
|373|12.433|Comment CTA|
|374|12.467|Comment CTA|
|375|12.500|Comment CTA|
|376|12.533|Comment CTA|
|377|12.567|Comment CTA|
|378|12.600|Comment CTA|
|379|12.633|Comment CTA|
|380|12.667|Comment CTA|
|381|12.700|Comment CTA|
|382|12.733|Comment CTA|
|383|12.767|Comment CTA|
|384|12.800|Comment CTA|
|385|12.833|Comment CTA|
|386|12.867|Comment CTA|
|387|12.900|Comment CTA|
|388|12.933|Comment CTA|
|389|12.967|Comment CTA|
|390|13.000|Comment CTA|
|391|13.033|Comment CTA|
|392|13.067|Comment CTA|
|393|13.100|Comment CTA|
|394|13.133|Comment CTA|
|395|13.167|Comment CTA|
|396|13.200|Comment CTA|
|397|13.233|Comment CTA|
|398|13.267|Comment CTA|
|399|13.300|Comment CTA|
|400|13.333|Comment CTA|
|401|13.367|Comment CTA|
|402|13.400|Comment CTA|
|403|13.433|Comment CTA|
|404|13.467|Comment CTA|
|405|13.500|Comment CTA|
|406|13.533|Comment CTA|
|407|13.567|Comment CTA|
|408|13.600|Comment CTA|
|409|13.633|Comment CTA|
|410|13.667|Comment CTA|
|411|13.700|Comment CTA|
|412|13.733|Comment CTA|
|413|13.767|Comment CTA|
|414|13.800|Comment CTA|
|415|13.833|Comment CTA|
|416|13.867|Comment CTA|
|417|13.900|Comment CTA|
|418|13.933|Comment CTA|
|419|13.967|Comment CTA|
|420|14.000|Comment CTA|
|421|14.033|Comment CTA|
|422|14.067|Comment CTA|
|423|14.100|Comment CTA|
|424|14.133|Comment CTA|
|425|14.167|Comment CTA|
|426|14.200|Comment CTA|
|427|14.233|Comment CTA|
|428|14.267|Comment CTA|
|429|14.300|Comment CTA|
|430|14.333|Comment CTA|
|431|14.367|Comment CTA|
|432|14.400|Comment CTA|
|433|14.433|Comment CTA|
|434|14.467|Comment CTA|
|435|14.500|Comment CTA|
|436|14.533|Comment CTA|
|437|14.567|Comment CTA|
|438|14.600|Comment CTA|
|439|14.633|Comment CTA|
|440|14.667|Comment CTA|
|441|14.700|Comment CTA|
|442|14.733|Comment CTA|
|443|14.767|Comment CTA|
|444|14.800|Comment CTA|
|445|14.833|Comment CTA|
|446|14.867|Comment CTA|
|447|14.900|Comment CTA|
|448|14.933|Comment CTA|
|449|14.967|Comment CTA|
