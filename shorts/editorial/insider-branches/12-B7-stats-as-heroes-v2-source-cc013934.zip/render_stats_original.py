from PIL import Image, ImageDraw, ImageFont, ImageFilter
import math, json, subprocess, os
from pathlib import Path
P=Path(__file__).parent; O=P/'output'; O.mkdir(exist_ok=True)
W,H=1080,1920; SAFE=(48,288,888,1248)
FONT=P/'assets/Anton-Regular.ttf'; SUPPORT=P/'assets/LiberationSans-Bold.ttf'
def f(n,s=False): return ImageFont.truetype(str(SUPPORT if s else FONT),n)
def text(im,s,xy,size=60,color='#242a36',anchor='mm',support=False):
 ImageDraw.Draw(im).text(xy,s,font=f(size,support),fill=color,anchor=anchor,stroke_width=0)
def slab(w,h,color='#f4d6c3',radius=36):
 im=Image.new('RGBA',(w+80,h+90)); d=ImageDraw.Draw(im)
 shadow=Image.new('RGBA',im.size); ImageDraw.Draw(shadow).rounded_rectangle((40,38,w+40,h+38),radius,fill='#66738748'); im.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(16)))
 d=ImageDraw.Draw(im); d.rounded_rectangle((30,24,w+30,h+24),radius,fill='#bcaea5'); d.rounded_rectangle((30,15,w+30,h+15),radius,fill=color)
 d.arc((33,18,w+27,h+12),180,270,fill='#fff5ee',width=3)
 return im
INK='#242a36'; ORANGE='#9a4b2d'; BLUE='#3453a7'
def heading(lines,size=74,width=760):
 im=Image.new('RGBA',(width, len(lines)*int(size*1.3)+18));
 for j,line in enumerate(lines):text(im,line,(width/2,9+(j+.5)*size*1.3),size)
 return im
logos=[]
for name in ['Claude-logo-Slate-0aff1e24.png','Gemini-logo-2025-32a9eb8b.png']:
 im=Image.open(P/'assets'/name).convert('RGBA'); im.thumbnail((240,60),Image.Resampling.LANCZOS); logos.append(im)
def chip(i):
 im=slab(350,156,'#f9e7da' if i==0 else '#e1e5fb',28); im.alpha_composite(logos[i],(30+(350-logos[i].width)//2,30)); text(im,['Sonnet 5.5 (Max)','Gemini 4'][i],(205,112),48); 
 if i==1:text(im,'Argon High',(205,158),35)
 return im
def counter(i,score):
 im=slab(350,260,'#f3c9b3' if i==0 else '#d2d9f6',46)
 text(im,str(score),(205,118),176,ORANGE if i==0 else BLUE); text(im,'BENCHMARK SCORE',(205,236),34,INK,support=True)
 return im
def bar(i,v):
 im=slab(740,170,'#f7e0d0' if i==0 else '#e3e7fb',32)
 text(im,['SONNET','ARGON'][i],(65,47),48,anchor='la'); text(im,str(v),(735,22),64,ORANGE if i==0 else BLUE,anchor='ra')
 d=ImageDraw.Draw(im);d.rounded_rectangle((64,113,735,157),20,fill='#ffffff');d.rounded_rectangle((64,113,64+int(671*v/100),157),20,fill='#c88764' if i==0 else '#7d97d8')
 d.line((80,116,64+int(671*v/100)-12,116),fill='#fff5eaaa',width=3)
 return im
def pill(s,color='#f0d8cb',size=56,w=740,h=92):
 im=slab(w,h,color,25);text(im,s,(30+w/2,15+h/2),size); return im
rail=heading(['Artificial Analysis - 30 Sep 2026','Sonnet Max / Argon High'],48,820)
caveat=heading(['Argon: limited rollout'],48,800)
# Each scene comprises distinct travelling sprites. Nothing morphs between scenes.
scenes=[]
def add(start,end,assets):scenes.append((start,end,assets))
def asset(name,img,x,y,delay=0,dir=1):return {'name':name,'img':img,'x':x,'y':y,'delay':delay,'dir':dir}
add(0,1.8,[asset('matchup',heading(['CLAUDE OR GEMINI?'],82),468,410),asset('claude_chip',chip(0),265,650,.03,-1),asset('gemini_chip',chip(1),675,650,.09,1),asset('hook',pill('WHICH ONE WINS?',size=66),468,920,.13,-1)])
for start,end,bench,vals,winner in [(1.8,3.7,'Terminal-Bench 4.0',(64,57),'SONNET LEADS HERE'),(5.7,7.6,'AutomationBench-AA',(71,78),'GEMINI LEADS HERE')]:
 add(start,end,[asset('benchmark',heading([bench],64),468,398),asset('claude_chip',chip(0),265,545,.04,-1),asset('gemini_chip',chip(1),675,545,.08,1),asset('sonnet_counter',counter(0,vals[0]),265,775,.08,-1),asset('argon_counter',counter(1,vals[1]),675,775,.13,1),asset('lead',pill(winner,size=56),468,1000,.17,-1)])
for start,end,bench,vals,winner in [(3.7,5.7,'Terminal-Bench 4.0',(64,57),'SONNET LEADS HERE'),(7.6,9.6,'AutomationBench-AA',(71,78),'GEMINI LEADS HERE')]:
 add(start,end,[asset('benchmark',heading([bench],64),468,398),asset('sonnet_bar',bar(0,vals[0]),468,633,.05,-1),asset('argon_bar',bar(1,vals[1]),468,860,.11,1),asset('lead',pill(winner,size=56),468,1040,.16,-1)])
add(9.6,12.1,[asset('verdict',heading(['DIFFERENT TESTS.','DIFFERENT WINNERS.'],82),468,480),asset('claude_chip',chip(0),265,850,.05,-1),asset('gemini_chip',chip(1),675,850,.1,1)])
add(12.1,15.4,[asset('closing',heading(['MAKE VIDEOS','LIKE THIS?'],94),468,480),asset('CTA',pill('Comment "VIDEO"',size=76,color='#d9e3f5',h=160),468,780,.06,-1),asset('claude_chip',chip(0),265,986,.09,-1),asset('gemini_chip',chip(1),675,986,.14,1)])
scenes.sort(key=lambda x:x[0]); bg=Image.new('RGBA',(W,H),'#f5f3ee')
# Matte quiet ground, no animated decoration or camera motion.
d=ImageDraw.Draw(bg); d.rounded_rectangle((10,235,927,1310),70,fill='#edece7'); d.rounded_rectangle((12,229,925,1301),70,fill='#faf8f3')
def ease(x):return 1-(1-max(0,min(1,x)))**3
states=[]; contact=[]; previous=None; differences=[]
enc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-an','-c:v','libx264','-preset','fast','-crf','19','-pix_fmt','yuv420p','-movflags','+faststart',str(O/'B7-stats-as-heroes.mp4')],stdin=subprocess.PIPE)
for frame in range(450):
 t=frame/30; im=bg.copy(); layer=Image.new('RGBA',(W,H)); active=[]
 for st,en,aa in scenes:
  for a in aa:
   u=t-st-a['delay']; duration=en-st-a['delay'];
   if u<-.35 or u>duration+.36:continue
   entry=ease((u+.35)/.55); out=max(0,min(1,(u-duration+.22)/.58))**3; opacity=min(entry,1-out)
   if opacity<.001:continue
   drift=(u/max(duration,.5)-.5)
   scale=(.57+.43*entry)*(1+.055*drift+.28*out)
   x=a['x']+a['dir']*(920*(1-entry)+1040*out)+a['dir']*32*drift
   y=a['y']+180*(1-entry)-150*out+24*drift
   spr=a['img']; rw,rh=round(spr.width*scale),round(spr.height*scale)
   spr=spr.resize((rw,rh),Image.Resampling.BICUBIC)
   if opacity<.999:spr.putalpha(spr.getchannel('A').point(lambda v:round(v*opacity)))
   layer.alpha_composite(spr,(round(x-rw/2),round(y-rh/2)))
   active.append({'asset':a['name'],'x':round(x,3),'y':round(y,3),'scale':round(scale,5),'opacity':round(opacity,4),'bounds':[round(x-rw/2),round(y-rh/2),round(x+rw/2),round(y+rh/2)]})
 # Source rail moves imperceptibly by design-independent content travel, while scene assets do the main moving.
 if t>1.55:
  r=rail if t<9.6 else caveat; x=468+8*math.sin(t*1.1); y=1171+3*math.sin(t*1.3)
  layer.alpha_composite(r,(round(x-r.width/2),round(y-r.height/2)));active.append({'asset':'rail','x':round(x,3),'y':round(y,3),'scale':1,'opacity':1})
 # Transition text is masked to the supplied safe region. No visible essential pixels leave it.
 clipped=Image.new('RGBA',(W,H));clipped.paste(layer.crop(SAFE),SAFE);im.alpha_composite(clipped)
 rgb=im.convert('RGB');enc.stdin.write(rgb.tobytes());states.append({'frame':frame,'t':t,'assets':active})
 if frame in [0,18,42,65,86,110,130,155,177,205,232,258,294,321,355,380,410,449]:contact.append((frame,rgb.copy()))
 if frame%60==0:print('Rendered',frame,flush=True)
enc.stdin.close();assert enc.wait()==0
sheet=Image.new('RGB',(6*270,3*500),'#ece9e4');sd=ImageDraw.Draw(sheet)
for j,(n,im) in enumerate(contact):im.thumbnail((270,480));sheet.paste(im,((j%6)*270,(j//6)*500));sd.text(((j%6)*270+8,(j//6)*500+478),f'{n/30:.2f}s',fill='black',font=f(16,True))
sheet.save(O/'B7-contact-sheet.jpg');contact[4][1].save(O/'B7-terminal.png');contact[9][1].save(O/'B7-automation.png')
json.dump(states,open(O/'450-frame-plan.json','w'),indent=1)
print('DONE',flush=True)
