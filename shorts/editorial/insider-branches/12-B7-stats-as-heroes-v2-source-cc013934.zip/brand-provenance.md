# Brand asset provenance

Received 3 October 2026. Editorial comparison use; no endorsement or partnership claimed. Preserve logos' original colours, aspect ratios and shapes. Animate their carrier/position, not their geometry.

## Claude

- `Claude-Spark-Clay-1d4af4ae.png`: 937x937 RGBA, transparent.
- `Claude-logo-Slate-0aff1e24.png`: 2289x500 RGBA, transparent.
- Source supplied by logo-research handoff: https://anthropic.com/press-kit
- These received original files were visually inspected. This production agent's independent fetch returned only a 301 page; press-kit page retrieval and download grounding rest on the dedicated source report, not an independently confirmed fetch here.

## Gemini

- `Gemini-logo-2025-d94a8593.svg`: supplied original SVG.
- `Gemini-logo-2025-32a9eb8b.png`: 1152x260 RGBA supplied rasterisation.
- Actual retrieval source: Wikimedia Commons, not a direct Google brand-download endpoint: https://commons.wikimedia.org/wiki/File:Google_Gemini_logo_2025.svg
- Commons description: Google Gemini logo as of July 1, 2025; source listed as extracted from About Gemini inline SVG; author listed as Google LLC. Commons labels it PD-textlogo and Trademarked. These are the publisher's labels, not legal clearance supplied by this project.
- Google's brand hub linked Gemini introduction routes returned 404 during our direct lookup. Do not describe this file as a firsthand official Google download or claim its current brand status independently verified by that unavailable page.

## Publication caveat

The files are for a user-review comparison render. General publication permission and trademark compliance are separate. Avoid altering marks, implying endorsement, or using the marks as our channel identity. No claim of universal model superiority is authorised by logo availability.
