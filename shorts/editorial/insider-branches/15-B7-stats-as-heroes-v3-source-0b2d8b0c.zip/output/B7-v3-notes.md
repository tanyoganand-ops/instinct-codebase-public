# B7 v3: animation used sparingly

Latest feedback: "Animation individually good. Not good when u apply to all of them, use sparingly" (4 Oct, 11:47).

The large travel/zoom/spring treatment is now reserved for the paired score heroes, paired proportional bars and the final Comment "VIDEO" pill. Benchmark headings, raster logo cards, lead labels and verdict have only a restrained 28 px reveal, no spring or scale treatment, and no idle motion. Source rail and caveat are fixed. The opening and verdict are allowed to breathe with still holds instead of forcing everything to move.

Same 15 seconds, 1080x1920, 30fps, 450 frames, silent. Locked scores, models, benchmarks, verdict, CTA, source and rollout caveat unchanged. Same matte pastel-clay palette and faint static dot grid. Exact safe mask preserved. Partial travelling hero sprites are clipped during entrance/exit; settled text is legible.

Re-audited the exact v3 encode. Deliberate repeated frames are expected now, not an audit failure: latest sparing-animation feedback supersedes the earlier never-static interpretation. Actual duplicate and stationary counts are in audit.json.

Visual inspection: updated 15-sample encoded contact sheet and full-resolution encoded AutomationBench frame at 6.6s. Scores, brands and source are clear. No new fact/source research. Prior v2 and original renderers are preserved in the source ZIP for comparison. Run `python3 render_stats.py` to rebuild v3 with Python 3, Pillow and ffmpeg.
