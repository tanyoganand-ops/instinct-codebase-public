# B5 carousel orbit
15s 1080x1920 30fps silent, 450 frames h264. Render: node render.js (puppeteer-core + chrome, deterministic setT(t)).
Six cards on a ring (Claude, Gemini, Terminal-Bench, AutomationBench-AA, verdict, CTA). Camera index s(t) eases between rests; cards at |u|>1.8 hidden. Satellites: clay sphere + donut travel behind.
