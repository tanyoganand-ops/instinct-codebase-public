const pp=require('/tmp/r/node_modules/puppeteer-core');const {spawn}=require('child_process');const fs=require('fs');
(async()=>{const br=await pp.launch({executablePath:'/usr/bin/google-chrome',args:['--no-sandbox','--allow-file-access-from-files','--font-render-hinting=none']});
const pg=await br.newPage();await pg.setViewport({width:1080,height:1920});await pg.goto('file:///tmp/b5/index.html');await pg.evaluate(()=>document.fonts.ready);
const N=+process.env.N||450, only=process.env.ONLY;
const plan=[],viol=[];
if(only){for(const f of only.split(',')){await pg.evaluate(t=>setT(t),f/30);await pg.screenshot({path:`/tmp/b5/f${f}.png`})}await br.close();return}
const ff=spawn('ffmpeg',['-y','-f','image2pipe','-framerate','30','-i','-','-c:v','libx264','-pix_fmt','yuv420p','-crf','16','-preset','medium','-r','30','-movflags','+faststart','/tmp/b5/out.mp4'],{stdio:['pipe','inherit','inherit']});
for(let f=0;f<N;f++){const t=f/30;const st=await pg.evaluate(t=>setT(t),t);const a=await pg.evaluate(()=>audit());
 a.forEach(x=>{const minfs=x.t.startsWith('Artificial')||x.t.startsWith('Sonnet Max')?48:0;
  if(x.l<47.5||x.r>888.5||x.tp<287.5||x.bt>1248.5)viol.push({f,...x});if(minfs&&x.fs<minfs)viol.push({f,fs:x.fs,t:x.t})});
 st.visible=st.cards.filter(c=>c.op>.5).length;plan.push(st);
 const buf=await pg.screenshot({type:'png'});if(!ff.stdin.write(buf))await new Promise(r=>ff.stdin.once('drain',r));}
ff.stdin.end();await new Promise(r=>ff.on('close',r));fs.writeFileSync('/tmp/b5/frame-plan.json',JSON.stringify(plan));fs.writeFileSync('/tmp/b5/violations.json',JSON.stringify(viol));
console.log('done',viol.length,'min visible',Math.min(...plan.map(p=>p.visible)));await br.close()})();
