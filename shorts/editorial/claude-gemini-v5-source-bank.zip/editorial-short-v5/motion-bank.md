# Reusable v5 motion and visual bank

- Plain swipe: x offset -105px or +105px to settled x in 15 frames, out_cubic; scale=1, rotation=0, opacity=1.
- Dropdown: verdict y -140px to settled y in 15 frames, out_cubic.
- Fade-rise type: y +32px to settled y, masked_bezier easing (.625,.05,0,1), independent opacity. No actual clipping mask.
- Score count-up: 30-frame in_out_cubic, starts 17 frames after scene start.
- Dot ripple: 42px grid, 240px wavelength, 72-frame period, 34px decay displacement, 22px/28px crossing waves, 2.4-4.4px radius, text-zone attenuation.
- Gradient: blue/violet/coral palette stop crossfades over 90 frames, moving color pools with 180-frame orbit.
- Six glass glyphs: 70px nominal size, original code, margin drift.
- Three original wire torus groups: seven elliptical rings each.
- Carrier refraction approximation: sampled blurred backdrop, 9px displaced edges; frost, bright rims, 72-frame independent diagonal specular sweep.
- Black display serif and bold supporting sans. Exact supplied brand raster lockups. Synthetic stereo cue bed. No purchased/generated assets.
