# Vid-3 legal reliability clay asset pack
Prepared 4 October 2026. Asset prep only; no video, publication or repo mutation.

## Files
Three independent generated RGBA props, 1254x1254:
- vid3-legal-research.png: abstract document stack with magnifying glass.
- vid3-work-product-folder.png: folder with file tabs, not real client work.
- vid3-human-review.png: clipboard with EMPTY checklist boxes and pencil. It indicates review needed, never approved work.

Four RGBA fixed-score states, 1536x1024:
- sonnet-research-score.png 48.08%, Legal Research Bench.
- argon-research-score.png 54.81%, Legal Research Bench.
- sonnet-work-product-score.png 2.92%, Harvey's Legal Agent Benchmark, Final score.
- argon-work-product-score.png 19.58%, Harvey's Legal Agent Benchmark, Final score.

Two reusable blank blue/peach textured carriers and four transparent typography overlays. Typography is deterministic, not generated. DejaVu Sans Bold is provisional. Full Harvey benchmark name wraps to two lines rather than shrinking too small. For final phone layout, treat benchmark labels as independent text at established series font floors; these packed tiles are reusable asset states, not completed video layouts.

## QA
Inspected final alpha-check.png and actual pale-dark-composite-check.png. All sprites have true zero-alpha transparent areas and partial-alpha edges; no checkerboard/background baked in. Pale and navy composites show clean edges, coherent props and correct text. No floor shadow baked into cutouts; self-shading retained. Add independent ground shadows in the compositor if desired. alpha-metrics.json records dimensions and alpha tests.

## Limits
Raster sprites, not 3D meshes. Each grouped prop is independently movable; internal parts are not independently layered. Illustrations contain no real citations, client details or case data. Reviewer icon has no checkmark or approval stamp.
Score sources, checked in today's research:
https://www.vals.ai/models/anthropic_claude-sonnet-5-5
https://www.vals.ai/models/google_gemini-4-argon
Keep content-plan caveats: shared harness verified, equal reasoning/compute settings NOT verified; model defaults Max vs High may not describe individual benchmark runs. Legal Research Bench all-pass differs from Harvey's averaged judge final score. Recheck sources before export. No universal legal-capability or real-world reliability claim.
