# Reusable motion and asset bank v4

## Motion

- fly_bezier: cubic-bezier(0,.71,.2,1.01); 16 frames; x +/-95, y +/-90 or -150, scale .88->1, rotation +/-12->0.
- masked_bezier: cubic-bezier(.625,.05,0,1); text y +32->0, alpha 0->1. Name denotes easing reference, not an actual mask.
- in_out_cubic: 30-frame score count-up, 17-frame start offset.
- radial dots: 42px grid, 240px wavelength, period 72 frames, 18px decayed displacement, synchronized 1.5-2.8px radius.
- drift: six glyphs, +/-24px horizontal / +/-36px vertical movement, phase offset per glyph.
- torus: seven nested moving elliptical rings per group, three margin groups.
- specular: 72-frame diagonal carrier sweep, clipped to rounded card silhouette.
- lens: per-pixel edge displacement from a live sampled backdrop, blurred 11px before sampling.

## Assets

Exact supplied Claude and Gemini raster lockups; brand notes in assets/provenance.md. Local font binaries and licenses in fonts/ and root. Synthetic stereo cue bed in cues.wav. Dot, glyph, torus and glass treatments are original code-defined layers; no downloaded generic glass illustration or generated logo is used.
