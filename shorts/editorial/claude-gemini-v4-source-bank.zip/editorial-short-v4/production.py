from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np,math,pathlib,json,subprocess,sys
from frame_engine import expand,track,write_plan
R=pathlib.Path(__file__).parent;W,H=1080,1920
FONT=str(R/'fonts/LiberationSans-Regular.ttf');BOLD=str(R/'fonts/LiberationSans-Bold.ttf');SERIF=str(R/'fonts/NotoSerifDisplay-Regular.ttf')
C='#d57855';G='#4285f4';INK='#182133';N=[]
def node(id,kind,start=0,end=450,z=10,**kw):
 n={'id':id,'kind':kind,'start':start,'end':end,'z':z,'x':0,'y':0,'scale':1,'opacity':1,'rotation':0,'progress':1,'tracks':[],**kw};N.append(n);return n
def tr(n,k,a,b,v,w,c='out_quint'):n['tracks'].append({'property':k,'start':a,'end':b,'from':v,'to':w,'curve':c});return n
def enter(n,at,delay=0,span=12):
 tr(n,'opacity',at+delay,at+delay+span,0,1,'masked_bezier');tr(n,'y',at+delay,at+delay+span,n['y']+32,n['y'],'masked_bezier');return n
def text(id,s,y,size,start,end,bold=False,color=INK):return node(id,'text',start,end,30,x=540,y=y,text=s,size=size,bold=bold,color=color)
claude=str(R/'assets/Claude-logo-Slate-0aff1e24.png');gemini=str(R/'assets/Gemini-logo-2025-32a9eb8b.png')
node('ambient','ambient',z=0)
# One/two hero objects + one/two main lines, all other evidence relegated to source/label rails.
scenes=[(0,90,'faceoff'),(90,195,'terminal'),(195,300,'workflow'),(300,390,'verdict'),(390,450,'cta')]
for st,en,scene in scenes:
 for i,(name,path,x,color) in enumerate([('claude',claude,117,C),('gemini',gemini,577,G)]):
  yy=604 if scene=='faceoff' else 550
  n=node(scene+'-'+name,'hero',st,en,20,x=x,y=yy,width=386,height=320 if scene in ['terminal','workflow'] else 232,path=path,color=color,scene=scene,model='Sonnet 5.5' if i==0 else 'Gemini 4 Argon',value=([64,57] if scene=='terminal' else [71,78] if scene=='workflow' else [None,None])[i],count=0)
  enter(n,st,i*2,4)
  # Padded diagonal fly/drop with a brief zoom, settling rather than endless bounce.
  tr(n,'x',st+i*2,st+i*2+16,x+(-95 if i==0 else 95),x,'fly_bezier')
  tr(n,'y',st+i*2,st+i*2+16,yy-150 if scene=='faceoff' or scene=='verdict' else yy+90,yy,'fly_bezier')
  tr(n,'scale',st+i*2,st+i*2+16,.88,1,'fly_bezier')
  tr(n,'rotation',st+i*2,st+i*2+16,-12 if i==0 else 12,0,'out_quint')
  if scene in ['terminal','workflow']:
   tr(n,'count',st+17,st+47,0,n['value'],'in_out_cubic')
  n['tracks'][0]['from']=.9 if st==0 else .6
  # Hero stays present until the next scene replaces it; no vacant boundary.
 if scene=='faceoff':
  for id,s,y,size,b in [('hook','CLAUDE OR GEMINI?',985,86,True),('models','Sonnet 5.5 vs Gemini 4 Argon',1100,40,False)]:
   t=enter(text(id,s,y,size,st,en,b),st,6,14);t['tracks'][0]['from']=.65
 elif scene=='terminal':
  enter(text('coding-result','Sonnet leads here.',1012,85,st,en,True,C),st,40)
  enter(text('coding-label','Terminal-Bench 4.0',1130,43,st,en),st,4)
 elif scene=='workflow':
  enter(text('workflow-result','Gemini leads here.',1012,85,st,en,True,G),st,40)
  enter(text('workflow-label','AutomationBench-AA',1130,43,st,en),st,4)
 elif scene=='verdict':
  enter(text('verdict-a','Different tests.',990,86,st,en,True),st,4)
  enter(text('verdict-b','Different winners.',1090,84,st,en,True),st,12)
 elif scene=='cta':
  enter(text('cta-a','Make videos like this?',990,80,st,en,True),st,4)
  enter(node('cta-b','pill',st,en,40,x=540,y=1100,text='Comment "VIDEO"',size=64,color=INK),st,10)
# Non-hero factual rails never become chart blocks.
node('source','text',90,450,50,x=540,y=1508,text='Artificial Analysis · 30 Sep 2026',size=29,bold=False,color='#5b6675')
node('effort','text',90,300,50,x=540,y=1553,text='Sonnet Max / Argon High',size=26,bold=False,color='#6c7685')
node('rollout','text',300,450,50,x=540,y=1562,text='Argon: limited rollout',size=27,bold=False,color='#6c7685')
w=node('reset','wipe',445,450,100,progress=0);tr(w,'progress',445,449,0,1,'in_out_cubic')
shots=[{'id':f'sec-{i:02}','start':i*30,'end':(i+1)*30,'purpose':next(s for st,en,s in scenes if st<=i*30<en)} for i in range(15)]
frs=expand(N,shots)
for f in frs:
 for n in f['nodes']:
  if n['kind']=='ambient':
   n['dot_phase']=round(2*math.pi*(f['frame']/30)/2.4,6)
   n['icon_phase']=round(f['frame']*.02,6)
   n['light_phase']=round(f['frame']/90,6)
  if n['kind']=='hero' and n['value'] is not None:n['display_score']=str(round(n['count']))+'%'
write_plan(R/'frames-v4.json',frs,'V4 owner steering: maximum two hero visuals and two hero lines per scene, ambient background motion only. Two verified independent benchmark pairs unchanged. CTA unchanged in intent. Values below are resolved before rendering.')
(R/'tracks-v4.json').write_text(json.dumps({'nodes':N,'shots':shots},indent=2));frs=json.loads((R/'frames-v4.json').read_text())['frames']
fontcache={};logos={}
def ft(s,b=False):
 k=(s,b)
 if k not in fontcache:fontcache[k]=ImageFont.truetype(BOLD if b else FONT,s)
 return fontcache[k]
def word(s,size,b=False,color=INK,serif=False):
 font=ImageFont.truetype(SERIF,size) if serif else ft(size,b);bb=font.getbbox(s);im=Image.new('RGBA',(math.ceil(font.getlength(s))+6,size+16));ImageDraw.Draw(im).text((3,3-bb[1]),s,font=font,fill=color);return im
# Ambient luminous backdrop with slowly drifting unfocused light, not front-and-centre charts.
y,x=np.mgrid[0:480,0:270];y=y*4;x=x*4;base=np.zeros((480,270,3));base[:]=[241,243,247]
def backdrop(f):
 a=base.copy()
 for xx,yy,col,sig,amp in [(180+45*math.sin(f/90),490+60*math.cos(f/100),[164,196,246],430,.62),(850+55*math.cos(f/120),1110+50*math.sin(f/80),[204,180,238],460,.55),(380,1530,[229,222,210],370,.4)]:
  v=np.exp(-((x-xx)**2+(y-yy)**2)/(2*sig**2))*amp;a=a*(1-v[:,:,None])+np.array(col)*v[:,:,None]
 im=Image.fromarray(a.astype('uint8')).resize((W,H),Image.Resampling.BICUBIC).convert('RGBA');d=ImageDraw.Draw(im)
 # Dim chart-like lines are pure ambient texture, not data encodings.
 lines=Image.new('RGBA',(W,H));d=ImageDraw.Draw(lines)
 for k in range(8):
  xx=round(-190+k*225+16*math.sin(f/80));d.line((xx,200,xx+180,1700),fill=(190,202,224,35),width=1)
 im.alpha_composite(lines)
 # Fluid radial dot grid: visual ripple, no encoded benchmark data.
 dots=Image.new('RGBA',(W,H));dd=ImageDraw.Draw(dots)
 for ry in range(230,1750,42):
  for rx in range(20,1080,42):
   rr=math.hypot(rx-540,ry-900);phase=2*math.pi*rr/240-2*math.pi*(f/30)/2.4;zz=math.sin(phase)
   delta=18*zz*math.exp(-rr/900)
   px=rx+delta*(rx-540)/max(rr,1);py=ry+delta*(ry-900)/max(rr,1)+12*math.sin(rx*.007+f*.025)+18*math.sin(ry*.009+f*.03);rad=1.5+1.3*(zz+1)/2
   # Clear zone behind main reading line avoids foreground clutter.
   op=55 if py<930 or py>1230 else 18
   dd.ellipse((px-rad,py-rad,px+rad,py+rad),fill=(82,114,180,round(op*(.45+.55*(zz+1)/2))))
 im.alpha_composite(dots)
 # Six original tiny glass glyphs around the margins, well behind hero focus.
 amb=Image.new('RGBA',(W,H));ad=ImageDraw.Draw(amb)
 for j,(px,py) in enumerate([(70,350),(875,245),(42,1240),(920,1370),(220,1640),(750,1710)]):
  px+=24*math.sin(f*.02+j);py+=36*math.cos(f*.018+j);sz=58+8*math.sin(f*.014+j)
  ad.rounded_rectangle((px,py,px+sz,py+sz),16,fill=(255,255,255,60),outline=(255,255,255,175),width=2)
  cx=px+sz/2;cy=py+sz/2
  if j%3==0:
   ad.line((cx-12,cy,cx+12,cy),fill=(89,118,174,95),width=3);ad.line((cx,cy-12,cx,cy+12),fill=(89,118,174,95),width=3)
  elif j%3==1:ad.ellipse((cx-11,cy-11,cx+11,cy+11),outline=(100,125,185,105),width=3)
  else:ad.polygon([(cx,cy-13),(cx+12,cy+10),(cx-12,cy+10)],outline=(100,125,185,105),width=2)
 # Offset elliptic torus: nested ellipses rolling in depth, low contrast at margins.
 for j,(cx,cy) in enumerate([(70,910),(1025,440),(825,1770)]):
  cx+=18*math.sin(f*.02+j);cy+=20*math.cos(f*.02+j);ph=f*.023+j
  for z in range(7):
   rx=72+z*3;ry=18+8*math.sin(ph+z*.35)
   ad.ellipse((cx-rx,cy-ry+z*5,cx+rx,cy+ry+z*5),outline=(245,250,255,90),width=2)
 im.alpha_composite(amb)
 return im

def draw(f):
 im=backdrop(f['frame'])
 def put(s,x,y,alpha=1,rot=0,center=False,scale=1):
  if scale!=1:
   nw,nh=round(s.width*scale),round(s.height*scale);x+=(s.width-nw)/2;y+=(s.height-nh)/2;s=s.resize((max(1,nw),max(1,nh)),Image.Resampling.LANCZOS)
  if center:x-=s.width/2
  if rot:s=s.rotate(rot,Image.Resampling.BICUBIC,expand=True)
  if alpha<1:s=s.copy();s.putalpha(s.getchannel('A').point(lambda v:round(v*alpha)))
  im.alpha_composite(s,(round(x),round(y)))
 for n in f['nodes']:
  if n['kind']=='ambient':continue
  if n['kind']=='wipe':
   b=round(W*n['progress']);first=draw(frs[0]);im.paste(first.crop((0,0,b,H)),(0,0));continue
  if n['opacity']<=0:continue
  if n['kind']=='text':
   s=word(n['text'],n['size'],n['bold'],n['color'],serif=n['id'] not in ['source','effort','rollout']);
   if s.width>980:s=s.resize((980,round(s.height*980/s.width)),Image.Resampling.LANCZOS)
   put(s,n['x'],n['y'],n['opacity'],center=True)
  elif n['kind']=='pill':
   t=word(n['text'],n['size'],True,'white');s=Image.new('RGBA',(t.width+64,t.height+34));ImageDraw.Draw(s).rounded_rectangle((0,0,s.width-1,s.height-1),18,fill=n['color']);s.alpha_composite(t,(32,15));put(s,n['x'],n['y'],n['opacity'],center=True)
  elif n['kind']=='hero':
   ww,hh=n['width'],n['height'];xx,yy=round(n['x']),round(n['y'])
   sha=Image.new('RGBA',(ww+100,hh+100));d=ImageDraw.Draw(sha);d.rounded_rectangle((42,48,ww+42,hh+48),36,fill=(34,52,94,40));sha=sha.filter(ImageFilter.GaussianBlur(24));put(sha,xx-42,yy-35,n['opacity'])
   # Glass carrier: blur actual backdrop underneath + restrained frost and rim.
   # Lens displacement across the card, strongest near the curved border.
   backing=im.crop((max(0,xx-30),max(0,yy-30),min(W,xx+ww+30),min(H,yy+hh+30))).resize((ww+60,hh+60),Image.Resampling.BICUBIC).filter(ImageFilter.GaussianBlur(11))
   yygrid,xxgrid=np.mgrid[0:hh,0:ww];dist=np.minimum.reduce([xxgrid,ww-1-xxgrid,yygrid,hh-1-yygrid]);edge=np.exp(-dist/14)
   ox=9*edge*np.tanh((xxgrid-ww/2)/50);oy=9*edge*np.tanh((yygrid-hh/2)/45)
   pixels=np.asarray(backing);samplex=np.clip(np.round(xxgrid+30+ox).astype(int),0,ww+59);sampley=np.clip(np.round(yygrid+30+oy).astype(int),0,hh+59)
   s=Image.fromarray(pixels[sampley,samplex]);frost=Image.new('RGBA',(ww,hh),(255,255,255,80));s.alpha_composite(frost)
   mask=Image.new('L',(ww,hh));ImageDraw.Draw(mask).rounded_rectangle((0,0,ww-1,hh-1),35,fill=255);s.putalpha(mask);d=ImageDraw.Draw(s);d.rounded_rectangle((1,1,ww-2,hh-2),34,outline=(255,255,255,235),width=3);d.line((36,5,ww-36,5),fill=(255,255,255,255),width=3)
   d.rounded_rectangle((7,7,ww-8,hh-8),29,outline=(255,255,255,105),width=7)
   d.rounded_rectangle((14,14,ww-15,hh-15),23,outline=(130,158,214,55),width=2)
   # Specular sweep is clipped to the rounded glass silhouette.
   gleam=Image.new('RGBA',(ww,hh));gd=ImageDraw.Draw(gleam);gx=round(-110+(f['frame']%72)/72*(ww+200));gd.polygon([(gx,0),(gx+50,0),(gx+170,hh),(gx+115,hh)],fill=(255,255,255,65));gleam=gleam.filter(ImageFilter.GaussianBlur(12));s.alpha_composite(gleam);s.putalpha(mask)
   if n['path'] not in logos:logos[n['path']]=Image.open(n['path']).convert('RGBA')
   lg=logos[n['path']].copy();lg.thumbnail((ww-65,95),Image.Resampling.LANCZOS);s.alpha_composite(lg,((ww-lg.width)//2,40))
   label=word(n['model'],30,True,'#596575');s.alpha_composite(label,((ww-label.width)//2,125))
   if n['value'] is not None:
    score=word(n['display_score'],94,True,n['color']);s.alpha_composite(score,((ww-score.width)//2,194))
   put(s,xx,yy,n['opacity'],n['rotation'],scale=n['scale'])
 return im
if __name__=='__main__':
 selected=[0,15,45,75,95,120,145,175,195,225,245,275,305,335,365,385,405,425,446,449]
 sh=Image.new('RGB',(360*4,665*5),'white');d=ImageDraw.Draw(sh)
 for i,f in enumerate(selected):
  a=draw(frs[f]).convert('RGB');a.save(R/f'qa-{f:03}.png');xx=i%4*360;yy=i//4*665;sh.paste(a.resize((360,640),Image.Resampling.LANCZOS),(xx,yy));d.text((xx+5,yy+643),str(f),font=ft(18),fill='black')
 sh.save(R/'qa-v4-contact.png')
 if '--preview' in sys.argv:sys.exit()
 p=subprocess.Popen(['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-i',str(R/'cues.wav'),'-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-t','15','-movflags','+faststart',str(R/'claude-vs-gemini-v4.mp4')],stdin=subprocess.PIPE)
 for f in frs:
  p.stdin.write(draw(f).convert('RGB').tobytes())
  if f['frame']%90==0:print('frame',f['frame'],flush=True)
 p.stdin.close();assert p.wait()==0
