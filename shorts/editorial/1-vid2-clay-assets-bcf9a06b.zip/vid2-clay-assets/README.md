# Vid-2 reusable clay asset pack
Prepared 4 October 2026. Concept 1 is still a proposal; no video or repository changes.

- Three separate generated RGBA props at 1254 x 1254: laptop with illustrative generic UI, filings stack, blank-key calculator.
- Four RGBA fixed-value score states at 1536 x 1024: Sonnet apps 92.39%; Argon apps 91.91%; Sonnet finance 58.10%; Argon finance 65.40%.
- Two matching blank clay carriers and four separate transparent text overlays. Use separate overlays for animation/count-up; do not morph one score card into another.
- Score typography was composited deterministically, not generated. DejaVu Sans Bold is a provisional font, not declared user-approved.
- Scores from Vals model pages checked during concept research on 4 Oct: https://www.vals.ai/models/anthropic_claude-sonnet-5-5 and https://www.vals.ai/models/google_gemini-4-argon . Recheck before publishing. Finance is partial credit, app score is functional testing; settings/fallback limitations in the content plan still apply.
- Illustrations are generic, not screenshots of benchmark runs or real financial reports. No digits or text baked into laptop/filings/calculator props.
- Alpha metrics in alpha-metrics.json. PNG alpha includes zero and partial alpha values. Inspected checkerboard contact sheet and actual pale/dark composites; clean cutouts, no painted checkerboard or opaque ground. Object self-shadows retained; no baked floor shadow, so compositor should add independent ground shadows if needed.
- alpha-check.png and pale-dark-composite-check.png are QA contact sheets, not proposed video layouts.
- Props are independent raster sprites, not layered 3D geometry. Their orientation cannot be freely rotated in depth. Blank carriers/text overlays allow independent score animation.
