import pathlib,shutil
R=pathlib.Path(__file__).parent;source=pathlib.Path('/downloads/hyperframes-test')
html=(source/'index.html').read_text()
names=['Pearl ripple','Satin wave','Twin pulse','Glass orbit','Aurora depth','Breathing lattice']
for i,name in enumerate(names,1):
 d=R/f'V{i}';d.mkdir(exist_ok=True)
 for directory in ['assets','vendor']:shutil.copytree(source/directory,d/directory,dirs_exist_ok=True)
 s=html.replace('data-duration="12"','data-duration="8"').replace('LOCAL MOTION TEST - V6 UNCHANGED',f'V{i} / {name.upper()}')
 s=s.replace('<svg id="mesh" viewBox="0 0 1080 1920" aria-hidden="true"></svg>','<canvas id="dots" width="1080" height="1920" style="position:absolute;inset:0" data-layout-allow-overflow></canvas>')
 a=s.index('<svg class="shape"');b=s.index('</svg>',a)+6;s=s[:a]+s[b:]
 s=s.replace('Seek-driven SVG draw-on + shape morph','Apple-inspired frost + purposeful motion').replace('12s local validation, not a v7','8s motion study - choose V1-V6')
 s=s.replace('.copy{position:absolute;', '.copy{padding:28px 20px 30px;border-radius:32px;background:rgba(255,255,255,.32);backdrop-filter:blur(12px);border:1px solid #ffffffb0;box-shadow:0 8px 35px #71839a12;position:absolute;')
 s=s.replace('.rail{position:absolute;', '.rail{padding:20px;border-radius:24px;background:rgba(255,255,255,.32);backdrop-filter:blur(10px);border:1px solid #ffffff88;position:absolute;')
 s=s.replace('background:rgba(255,255,255,.5);backdrop-filter:blur(9px)',f'background:rgba(255,255,255,{[.38,.52,.40,.30,.48,.62][i-1]});backdrop-filter:blur({[18,24,15,20,28,32][i-1]}px)')
 s=s.replace('width:386px;height:320px','width:386px;height:320px')
 a=s.index('<script>\ngsap.registerPlugin');s=s[:a]+'''<script>
const canvas=document.getElementById('dots'),ctx=canvas.getContext('2d');
const motion={t:0};
function renderDots(){
 const t=motion.t;ctx.clearRect(0,0,1080,1920);
 for(let j=0;j<53;j++)for(let k=0;k<32;k++){
  let x=k*36-18,y=j*36+25,r=2.2,alpha=.35;let rr=Math.hypot(x-540,y-940),ang=Math.atan2(y-940,x-540);
  const v=VARIANT;
  if(v===1){let z=Math.sin(rr*.025-t*1.25)*Math.exp(-rr/1200);x+=12*z*Math.cos(ang);y+=12*z*Math.sin(ang);r=2+1.6*(z+1)/2;alpha=.24+.27*(z+1)/2;}
  if(v===2){let z=Math.sin(k*.24+t*.65)+Math.sin(j*.19+t*.8);y+=22*z;x+=8*Math.cos(j*.19+t*.8);r=2.2+z*.55;alpha=.30+z*.07;}
  if(v===3){let a=Math.hypot(x-180,y-600),b=Math.hypot(x-900,y-1320);let z=(Math.sin(a*.026-t*1.3)+Math.sin(b*.022-t*1.2))*.5;r=2.1+1.3*(z+1)/2;x+=10*z;y+=14*z;alpha=.22+.3*(z+1)/2;}
  if(v===4){let z=Math.sin(rr*.013+ang*3-t*.8);x+=18*Math.cos(ang+t*.15)*z;y+=18*Math.sin(ang+t*.15)*z;r=2.3+z*.7;alpha=.30+z*.15;}
  if(v===5){let depth=(Math.sin(k*.3+j*.2+t*.7)+1)/2;y+=25*Math.sin(k*.15+t*.8);x+=12*Math.cos(j*.2+t*.65);r=1.2+depth*3;alpha=.17+depth*.30;ctx.shadowBlur=depth*5;ctx.shadowColor='rgba(140,176,218,.4)';}
  if(v===6){let z=Math.sin(t*.7+j*.08+k*.06);x+=7*Math.sin(j*.14+t*.7);y+=10*Math.cos(k*.17+t*.7);r=1.8+1.3*(z+1)/2;alpha=.18+.22*(z+1)/2;}
  ctx.fillStyle=`rgba(${v===5?'116,148,184':'86,115,151'},${alpha})`;ctx.beginPath();ctx.arc(x,y,Math.max(.6,r),0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
 }
}
renderDots();
const tl=gsap.timeline({paused:true});
tl.to(motion,{t:8,duration:8,ease:'none',onUpdate:renderDots},0);
tl.fromTo('#claude',{x:-140,opacity:.05},{x:0,opacity:1,duration:PACE,ease:'power2.inOut'},0);
tl.fromTo('#gemini',{x:140,opacity:.05},{x:0,opacity:1,duration:PACE,ease:'power2.inOut'},.15);
const counts={a:0,b:0};tl.to(counts,{a:71,b:78,duration:1.6,ease:'power2.inOut',onUpdate:()=>{document.getElementById('scoreA').textContent=Math.round(counts.a)+'%';document.getElementById('scoreB').textContent=Math.round(counts.b)+'%'}},1.3);
tl.fromTo('#copy',{opacity:0,y:45},{opacity:1,y:0,duration:1.15,ease:'power2.inOut'},2.3);
tl.fromTo('.rail',{opacity:0},{opacity:1,duration:1.2},.6);
tl.fromTo('#shineA,#shineB',{x:0},{x:640,duration:4,repeat:1,ease:'none'},0);
tl.to('#pool1',{x:150,y:60,duration:4,ease:'sine.inOut'},0).to('#pool1',{x:0,y:0,duration:4,ease:'sine.inOut'},4);
tl.to('#pool2',{x:-140,y:-50,duration:4,ease:'sine.inOut'},0).to('#pool2',{x:0,y:0,duration:4,ease:'sine.inOut'},4);
window.__timelines['validation']=tl;
</script></body></html>
'''.replace('VARIANT',str(i)).replace('PACE',str([1.2,1.4,1.1,1.6,1.4,1.8][i-1]))
 (d/'index.html').write_text(s)
