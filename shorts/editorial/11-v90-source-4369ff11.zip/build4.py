import sys, json, subprocess, math
import build3 as B3
from build3 import *
B3.assets.clear(); assets=B3.assets
add=B3.add; line=B3.line; wordspr=B3.wordspr
CAD=8/30; MUTc=(120,126,138); INKc=(42,47,58)
def W(txt,y,t0,t1,fnt=SANS,sz=84,col=INKc,pre='x'):
    line([(txt,fnt,sz,col)],y,t0,CAD,t1,abs(hash((txt,t0)))%900+30)
def Wl(words,y,t0,t1,cad=CAD):
    line(words,y,t0,cad,t1,abs(hash((str(words),t0)))%900+30)
def badges(t0,t1,hl=None):
    a=add('cb%.1f'%t0,brand('c'),t0,t1,(160,375,.5,0),'zoom',ph=1); a.dyn_from=(160,375)
    a=add('gb%.1f'%t0,brand('g'),t0+.1,t1,(776,375,.5,0),'zoom',ph=2); a.dyn_from=(776,375)
def rail_(t0,t1): add('rail%.1f'%t0,rail(),t0,t1,(468,1165,1,0),'bottom',ph=3)
def tag(txt,pal,t0,t1,y,kind='left',rot=0,fs=96,w=700):
    def mk():
        im=clay(w,140,50,*pal).copy(); d=ImageDraw.Draw(im); ctext(d,w//2,74,txt,fit(txt,ANT,w-60,fs),INK); return im
    return add('tg%.1f%s'%(t0,txt[:3]),mk(),t0,t1,(468,y,1,rot),kind,ph=int(t0*7)%13)
# S1 0-7 hook
Wl([('Which',SANS,84,INKc),('AI',SANS,84,INKc),('is',SANS,84,MUTc)],340,0,7)
Wl([('actually',SANS,84,MUTc),('better?',SANS,84,INKc)],430,0.9,7)
add('c1a',brand('c'),1.8,7,(262,780,1,-5),'left',ph=1); add('g1a',brand('g'),2.4,7,(674,780,1,5),'right',ph=2)
tag('SONNET 5.5 VS GEMINI 4',LILAC,3.4,7,1010,'bottom',fs=70)
# S2 7-14 tier framing
Wl([('Same',SANS,84,INKc),('test.',SANS,84,INKc)],340,7,14)
Wl([('Top',SANS,84,MUTc),('settings.',SANS,84,INKc)],430,8.0,14)
tag('SONNET 5.5  MAX',PEACH,8.8,14,640,'left',-2,fs=84)
tag('GEMINI 4  ARGON HIGH',BLUE,9.7,14,820,'right',2,fs=84)
add('c2a',brand('c'),10.6,14,(262,1050,.7,-4),'left',ph=3); add('g2a',brand('g'),11.2,14,(674,1050,.7,4),'right',ph=4)
# S3 14-19 source
Wl([('Scores',SANS,84,MUTc),('from',SANS,84,MUTc)],340,14,19)
tag('ARTIFICIAL ANALYSIS',LILAC,14.8,19,520,'left',-1,fs=80)
tag('30 SEP 2026',MINT,15.7,19,700,'right',1,fs=96)
add('rail3',rail(),16.6,19,(468,900,1,0),'bottom',ph=3)
# S4 TB 19-36
badges(19,36)
Wl([('Test',SANS,84,MUTc),('one',SANS,84,INKc)],340,19,24)
tag('TERMINAL-BENCH 4.0',CREAM,19.9,24,520,'left',-2,fs=70,w=800)
add('tbA',None,24,36,(468,720,1,-3),'right',dyn=lambda t:bench('TERMINAL-BENCH 4.0',64,57,ease((t-25.0)/2.2)),ph=4)
add('leadS4',pill('SONNET LEADS',PEACH,(151,80,49,255)),29.5,36,(468,1010,1,2),'left',ph=5)
Wl([('Sonnet',SANS,72,INKc),('wins',SANS,72,INKc),('this',SANS,72,MUTc),('one.',SANS,72,INKc)],1108,25.6,36)
# 7-point gap beat inside S4
Wl([('By',SANS,72,MUTc),('7',SANS,100,INKc),('points.',SANS,72,MUTc)],1205,31,36)
# S5 AB 36-53
badges(36,53)
Wl([('Test',SANS,84,MUTc),('two',SANS,84,INKc)],340,36,41)
tag('AUTOMATIONBENCH-AA',CREAM,36.9,41,520,'right',2,fs=70,w=800)
add('abA',None,41,53,(468,720,1,3),'left',dyn=lambda t:bench('AUTOMATIONBENCH-AA',71,78,ease((t-42.0)/2.2)),ph=6)
add('leadG5',pill('GEMINI LEADS',BLUE,(51,91,185,255)),46.5,53,(468,1010,1,-2),'right',ph=7)
Wl([('Gemini',SANS,72,INKc),('wins',SANS,72,INKc),('this',SANS,72,MUTc),('one.',SANS,72,INKc)],1108,42.6,53)
Wl([('By',SANS,72,MUTc),('7',SANS,100,INKc),('points.',SANS,72,MUTc)],1205,48,53)
# S6 sum 53-64
Wl([('Add',SANS,84,MUTc),('it',SANS,84,MUTc),('up.',SANS,84,INKc)],340,53,64)
tag('SONNET  64 + 71 = 135',PEACH,54.4,64,560,'left',-2,fs=70,w=800)
tag('GEMINI  57 + 78 = 135',BLUE,56.2,64,740,'right',2,fs=70,w=800)
Wl([('A',SANS,96,MUTc),('tie',SANS,120,INKc),('on',SANS,96,MUTc),('paper.',SANS,96,INKc)],940,58.5,64)
add('c6',brand('c'),60.5,64,(180,1120,.45,-4),'left',ph=3); add('g6',brand('g'),61.2,64,(756,1120,.45,4),'right',ph=4)
# S7 verdict 64-74
def kt(txt,pal):
    im=clay(560,150,55,*pal).copy(); d=ImageDraw.Draw(im); ctext(d,280,80,txt,ANT(112),INK); return im
W('Different',320,64,74,sz=84)
add('v1x',kt('TESTS.',PEACH),64.4,74,(468,465,1,-1.5),'left',ph=8)
W('Different',610,65.2,74,sz=84)
add('v2x',kt('WINNERS.',BLUE),65.6,74,(468,755,1,1.5),'right',ph=9)
add('c7a',chip('TERMINAL-BENCH  64 / 57',MINT),67.5,74,(468,940,1,0),'top',ph=10)
add('c7b',chip('AUTOMATIONBENCH  71 / 78',MINT),68.5,74,(468,1065,1,0),'top',ph=11)
# S8 caveat 74-82
Wl([('One',SANS,84,MUTc),('catch.',SANS,84,INKc)],340,74,82)
tag('GEMINI 4  ARGON',BLUE,74.8,82,540,'left',-2,fs=84)
cav=bar('LIMITED ROLLOUT')
a=add('cavs',cav,76.0,82,(468,740,1,0),'left',ph=14)
def wipe_at(t0,spr):
    def d(t):
        p=eo((t-t0)*FPS/8); w=max(2,int(spr.width*p)); im=Image.new('RGBA',spr.size,(0,0,0,0)); im.paste(spr.crop((0,0,w,spr.height)),(0,0)); return im
    return d
a.dyn=wipe_at(76.0,cav); a.kind='wipe'
Wl([('Not',SANS,84,MUTc),('everyone',SANS,84,INKc)],930,77.2,82)
Wl([('can',SANS,84,MUTc),('use',SANS,84,MUTc),('it',SANS,84,MUTc),('yet.',SANS,84,INKc)],1030,78.0,82)
add('g8',brand('g'),79,82,(468,1170,.5,3),'zoom',ph=5); assets[-1].dyn_from=(468,1170)
# S9 CTA 82-90
Wl([('Which',SANS,84,MUTc),('one',SANS,84,INKc)],330,82,90)
Wl([('would',SANS,84,MUTc),('you',SANS,84,MUTc),('pick?',SANS,84,INKc)],430,82.9,90)
add('cta0x',None,83.5,90.1,(468,680,1,0),'word',dyn=wordspr('Comment',SANS,72,MUTc)(83.5),ph=12)
a=add('ctax',word('"VIDEO"',ANT,150,INKc+(255,)),84.0,90.1,(468,805,1,0),'zoom',ph=13); a.dyn_from=(468,805)
add('c9a',chip('SONNET LEADS  TERMINAL-BENCH 64 / 57',MINT),85.5,90.1,(468,935,1,0),'top',ph=10)
add('c9b',chip('GEMINI LEADS  AUTOMATIONBENCH 78 / 71',BLUE),86.2,90.1,(468,1050,1,0),'top',ph=11)
cav2=bar('ARGON: LIMITED ROLLOUT'); a=add('cav9',cav2,87.0,90.1,(468,1195,1,0),'left',ph=14); a.dyn=wipe_at(87.0,cav2); a.kind='wipe'
TOT=90*30
def r(f): im,info=B3.render(f); return im.tobytes()
if __name__=='__main__':
    import multiprocessing as mp
    if sys.argv[1]=='still':
        fs=list(map(int,sys.argv[2:])); sh=Image.new('RGB',(270*len(fs),480))
        for i,f in enumerate(fs): sh.paste(B3.render(f)[0].resize((270,480)),(i*270,0))
        sh.save('/tmp/v12/sheet4.png')
    elif sys.argv[1]=='seg':
        a,b=int(sys.argv[2]),int(sys.argv[3])
        ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','/tmp/v12/seg_%04d.mp4'%a],stdin=subprocess.PIPE)
        with mp.Pool(2) as p:
            for bb in p.imap(r,range(a,b),chunksize=6): ff.stdin.write(bb)
        ff.stdin.close(); ff.wait(); print('seg',a,b)
    else:
        ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-stream_loop','-1','-i','/tmp/src/cues.wav','-t','90','-c:v','libx264','-preset','medium','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','/tmp/v12/v90.mp4'],stdin=subprocess.PIPE)
        with mp.Pool(2) as p:
            for b in p.imap(r,range(TOT),chunksize=8): ff.stdin.write(b)
        ff.stdin.close(); ff.wait(); print('done')
