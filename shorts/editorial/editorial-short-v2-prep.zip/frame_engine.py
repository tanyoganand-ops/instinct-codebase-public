"""Frame-exact production contract. No clock, random motion, network or interpolating renderer."""
import math,json,pathlib
FPS=30;FRAMES=450;W=1080;H=1920

def clamp(v):return min(1,max(0,v))
def curve(t,kind):
 t=clamp(t)
 if kind=='linear':return t
 if kind=='out_quint':return 1-(1-t)**5
 if kind=='in_out_cubic':return 4*t*t*t if t<.5 else 1-(-2*t+2)**3/2
 if kind=='out_cubic':return 1-(1-t)**3
 if kind=='out_back':
  c=1.35;return 1+(c+1)*(t-1)**3+c*(t-1)**2
 if kind=='critically_damped':
  if t==1:return 1
  z=8*t;return (1-(1+z)*math.exp(-z))/(1-9*math.exp(-8))
 raise ValueError(kind)

def track(f,start,end,a,b,kind='out_quint'):
 if f<=start:return a
 if f>=end:return b
 p=curve((f-start)/(end-start),kind);return a+(b-a)*p

def expand(nodes,shots):
 result=[]
 for f in range(FRAMES):
  shot=next(s for s in shots if s['start']<=f<s['end'])
  state=[]
  for n in nodes:
   if not n['start']<=f<n['end']:continue
   s={k:v for k,v in n.items() if k!='tracks'}
   for tr in n.get('tracks',[]):
    if f>=tr['start']:
     s[tr['property']]=round(track(f,tr['start'],tr['end'],tr['from'],tr['to'],tr.get('curve','out_quint')),4)
   state.append(s)
  state.sort(key=lambda s:s['z'])
  result.append({'frame':f,'time_seconds':round(f/FPS,6),'shot':shot['id'],'design_purpose':shot['purpose'],'nodes':state})
 assert len(result)==450
 return result

def write_plan(path,frames,content_notes):
 path=pathlib.Path(path)
 path.write_text(json.dumps({'canvas':{'width':W,'height':H,'fps':FPS,'frames':FRAMES},'frames':frames},indent=2))
 md=['# 15s Short v2: exact frame plan','',content_notes,'','450 unique frames. Time = frame / 30. Every number below is a resolved value, not an instruction to interpolate. Renderer reads these exact states.','', '## Per-frame states','', 'The full machine-readable states are in `frames-v2.json`. Each frame below lists visible node IDs and exact [x,y,scale,rotation,opacity,progress] values. Values absent from a node use [0,0,1,0,1,1].','']
 for fr in frames:
  md.append(f"### Frame {fr['frame']:03d} / {fr['time_seconds']:.6f}s / {fr['shot']}")
  md.append(fr['design_purpose'])
  md.append('```text')
  for n in fr['nodes']:
   v=[n.get(k,d) for k,d in [('x',0),('y',0),('scale',1),('rotation',0),('opacity',1),('progress',1)]]
   md.append(f"{n['id']}: {v}")
  md.append('```')
 pathlib.Path(path.parent/'450-frame-plan-v2.md').write_text('\n'.join(md)+'\n')
