# Editorial Shorts reusable foundation

Status: Claude vs Gemini v2 awaits approval of the second-by-second proposal. No v2 image/video render exists.

Suggested install root: `shorts/editorial/` in the existing private project repo.

- Put `frame_engine.py` at `banks/motion/frame_engine.py`.
- Put the review plan under `projects/claude-gemini-v2/brief.md`.
- Asset bank folders are planned, not yet populated with approved logos.
- After approval, expand exact 450-frame states first and render from the JSON.
- Preserve source URLs, logo terms, font licences and audio provenance alongside every reusable asset.
- Keep each project's `resume.md` updated with approved script, generated artifacts, QA issues and next step. Avoid using an exported video as the only saved state.

The frame engine has no runtime platform dependencies. It holds deterministic easing primitives, expands node tracks into resolved exact frame values, validates a 450-frame count, sorts the draw order, and emits per-frame Markdown. Production code and visual primitives will be added after review of the new topic.
