# Reusable v6 bank

- Plain horizontal swipe +/-105px, 15 frames, out_cubic. Verdict dropdown -140px, same easing. Scale 1, rotation 0, opacity 1.
- Type fade-rise +32px, 12 frames, cubic-bezier(.625,.05,0,1) with x inversion. No actual reveal clipping mask.
- Score count-up: 30 frames, in_out_cubic, starting frame offset 17.
- W1 continuous mesh: 102 lines, 15px spacing, 48px sine displacement, x frequency .004, line phase .10, frame phase .023. Full width behind every text/rail, no local fade.
- Pale white-biased blue/lilac/coral shifting gradient: 90-frame stop transitions, 180-frame moving pool paths.
- Six original margin glyphs and three elliptic wire ring groups.
- Glass: live backdrop sampling, edge displacement 9px, blur 11px, frost, rim, independent 72-frame clipped specular sweep.
- Anton heavy condensed hero/model labels; bold supporting sans. Exact supplied brand rasters. Synthetic cue bed.
