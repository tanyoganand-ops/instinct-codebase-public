# Clay physics pack

Three RGBA clips, 720x1280, 24 fps. Each clip folder has the same files.

| File | What it is |
|---|---|
| layer_card_rgba.webm | Clay objects only (straight alpha, VP9 yuva420p). Includes the clay base slab or bin. |
| layer_shadow_rgba.webm | Shadow only: black RGB, alpha 0-0.4. Soft wall shadow (light from upper left) plus floor contact shadow. Put it under the card layer. |
| composite_rgba.webm | Shadow + objects flattened, still transparent background. |
| preview_on_backdrop.mp4 | Composite on a flat cream wall and table, for quick viewing. |
| qa/ | contact_sheet.png (8 evenly spaced frames), preview_fNNN.png, card_alpha_fNNN.png (RGBA stills from the card layer). |

| Clip | Frames | Length | Content |
|---|---|---|---|
| 01_ball_pit_pour | 168 | 7.0 s | 64 clay spheres (r 26-34 px, 7 colours) pour in from above the frame into an open clay bin and settle. Rigid-body physics, spheres spin and show thumbprint dimples. |
| 02_domino_chain | 168 | 7.0 s | 12 small clay cards (20x130 px) in a row. A clay ball rolls in from the left and tips the first card, the chain falls. |
| 03_cube_drop | 132 | 5.5 s | 8x8 mass-spring soft body with internal pressure. Cube (about 210 px) drops tilted 14 degrees, lands on a corner, squashes, flops flat and recovers to a square. |

Floor line is y=1100 in all clips, so the clips line up if you stack them.

## Notes
- Side view, 2D physics rendered with a clay shader (bevelled height map, fingerprint grain, warm light from upper left). Not a 3D render, so cards read as thin slabs.
- The cube is the squashiest in frames 36-60. The squash is moderate (about 25 percent), recovery has no visible bounce.
- Domino chain jams at a lean (cards rest on each other), and the last card ends just past the right edge of the slab. All motion stops by about 2.5 s, the rest of the clip is a hold.
- Ball pit settles by about 5 s; balls stop moving once asleep.
- Alpha only works in players and editors that read VP9 alpha (Chrome, Firefox, ffmpeg with libvpx-vp9 decoder, most compositors). Safari and QuickTime may drop it. PNG sequences and ProRes 4444 were left out to keep the zip small; src/ regenerates frames.
- src/ holds the Python used (pymunk, numpy, scipy, Pillow, ffmpeg). Nothing was committed to any repo.

## QA done
- ffprobe: all 12 webm and 3 mp4 files are 720x1280, 24 fps, and the right frame count.
- Decoded the card layer with the libvpx-vp9 decoder: alpha runs 0-255, corners are transparent, about 77 percent of pixels transparent mid-pour.
- Checked 8 frames per clip visually on the contact sheets. Nothing clipped at the frame edges except the trigger ball entering from the left and the spheres entering from the top, as intended.
- Shadow alpha peaks at 0.34-0.39 in every clip.
