from clay import *
import pymunk, random
def run(outdir):
    random.seed(7); rs=np.random.RandomState(3)
    NF=168; sub=8
    sp=pymunk.Space(); sp.gravity=(0,1900); sp.iterations=30
    sp.sleep_time_threshold=0.35
    for a,b in [((84,0),(84,FLOOR)),((636,0),(636,FLOOR)),((60,FLOOR),(660,FLOOR))]:
        s=pymunk.Segment(sp.static_body,a,b,2); s.friction=0.8; s.elasticity=0.2; sp.add(s)
    balls=[]; NB=64
    plan=[]
    for i in range(NB):
        r=random.uniform(26,34)
        plan.append(dict(f=int(i*1.45),r=r,col=PAL[i%len(PAL)] if False else random.choice(PAL),
            x=360+random.uniform(-45,45),vx=random.uniform(-90,90),
            dimples=[tuple(v) for v in [ (lambda t:(math.cos(t)*math.sqrt(1-z*z),math.sin(t)*math.sqrt(1-z*z),z))(random.uniform(0,6.28)) if True else 0 for z in [random.uniform(0.2,0.9) for _ in range(3)]]]))
    out=Out('balls',outdir,NF)
    for f in range(NF):
        for p in plan:
            if p['f']==f:
                r=p['r']; m=math.pi*r*r*0.002
                b=pymunk.Body(m,pymunk.moment_for_circle(m,0,r)); b.position=(p['x'],-r-5); b.velocity=(p['vx'],250)
                b.angular_velocity=random.uniform(-6,6)
                c=pymunk.Circle(b,r); c.friction=0.7; c.elasticity=0.28; sp.add(b,c); p['b']=b
        for _ in range(sub):
            sp.step(1/FPS/sub)
            for p in plan:
                if 'b' in p: p['b'].angular_velocity*=0.998
        cm=np.zeros((H,W,4),np.float32)
        slab(cm,40,FLOOR,680,FLOOR+56)
        slab(cm,40,520,84,FLOOR+20,rad=12,bevel=18); slab(cm,636,520,680,FLOOR+20,rad=12,bevel=18)
        ell=[]
        for p in plan:
            if 'b' in p:
                x,y=p['b'].position
                ball(cm,x,y,p['r'],p['b'].angle,p['col'],p['dimples'])
        # only draw balls last-in-front fine
        sa=shadow_layer(cm[...,3],[(p['b'].position.x,p['r']*1.0,10,0.4*max(0,1-(FLOOR-p['b'].position.y-p['r'])/160)) for p in plan if 'b' in p and FLOOR-p['b'].position.y-p['r']<160])
        out.push(cm,sa)
    out.close()
if __name__=='__main__': run(sys.argv[1])
