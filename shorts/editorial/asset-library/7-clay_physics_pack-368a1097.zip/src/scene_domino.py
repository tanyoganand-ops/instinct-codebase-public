from clay import *
import pymunk, random
def run(outdir):
    random.seed(11)
    NF=168; sub=10
    sp=pymunk.Space(); sp.gravity=(0,1900); sp.iterations=40
    g=pymunk.Segment(sp.static_body,(0,FLOOR),(W,FLOOR),2); g.friction=0.9; g.elasticity=0.05; sp.add(g)
    CT,CH=20,130; N=12
    cards=[]
    x=100
    for i in range(N):
        b=pymunk.Body(1,pymunk.moment_for_box(1,(CT,CH))); b.position=(x,FLOOR-CH/2-0.5)
        sh=pymunk.Poly.create_box(b,(CT,CH),radius=2); sh.friction=0.75; sh.elasticity=0.05; sh.mass=1.0
        sp.add(b,sh); cards.append((b,PAL[(i*2+1)%len(PAL)])); x+=42
    # trigger ball
    bb=pymunk.Body(3,pymunk.moment_for_circle(3,0,34)); bb.position=(-40,760); bb.velocity=(330,0)
    bc=pymunk.Circle(bb,34); bc.friction=0.6; bc.elasticity=0.3; bc.mass=3; sp.add(bb,bc)
    ballcol=(226,170,72); dimp=[(0.3,0.2,0.93),(-0.5,0.4,0.77),(0.4,-0.6,0.69)]
    # hold cards still until frame 6 (start settled)
    out=Out('dom',outdir,NF)
    for f in range(NF):
        for _ in range(sub):
            sp.step(1/FPS/sub)
            bb.angular_velocity*=0.998
        cm=np.zeros((H,W,4),np.float32)
        slab(cm,40,FLOOR,680,FLOOR+56)
        ell=[]
        for b,col in cards:
            c=b.position; a=b.angle
            shade_poly(cm,rrect(c.x,c.y,CT,CH,a,6),col,9,noise_rot=a,center=(c.x,c.y),noise_origin=(c.x*0,0))
            bot=max(c.y+ (CH/2)*abs(math.cos(a))+(CT/2)*abs(math.sin(a)) ,0)
            hw=(CH/2)*abs(math.sin(a))+(CT/2)*abs(math.cos(a))
            ell.append((c.x,hw*1.05+4,9,0.42*max(0,1-(FLOOR-bot)/160)))
        x_,y_=bb.position
        ball(cm,x_,y_,34,bb.angle,ballcol,dimp)
        ell.append((x_,34,10,0.4*max(0,1-(FLOOR-y_-34)/200)))
        out.push(cm,shadow_layer(cm[...,3],ell))
    out.close()
if __name__=='__main__': run(sys.argv[1])
