from clay import *
N=8; S=30.0
def build():
    P=np.array([[ (i-(N-1)/2)*S,(j-(N-1)/2)*S] for i in range(N) for j in range(N)])
    idx=lambda i,j:i*N+j
    sp=[]
    for i in range(N):
        for j in range(N):
            for (di,dj,k) in [(1,0,1),(0,1,1),(1,1,.8),(1,-1,.8),(2,0,.5),(0,2,.5)]:
                a,b=i+di,j+dj
                if 0<=a<N and 0<=b<N: sp.append((idx(i,j),idx(a,b),k))
    A=np.array([s[0] for s in sp]);B=np.array([s[1] for s in sp]);K=np.array([s[2] for s in sp])
    L0=np.linalg.norm(P[A]-P[B],axis=1)
    ring=[idx(i,0) for i in range(N)]+[idx(N-1,j) for j in range(1,N)]+[idx(i,N-1) for i in range(N-2,-1,-1)]+[idx(0,j) for j in range(N-2,0,-1)]
    return P,A,B,K,L0,np.array(ring)
def area(Q):
    x,y=Q[:,0],Q[:,1]; return 0.5*np.sum(x*np.roll(y,-1)-np.roll(x,-1)*y)
def chaikin(Q,it=3):
    for _ in range(it):
        Q2=np.roll(Q,-1,0); R=np.empty((len(Q)*2,2)); R[0::2]=0.75*Q+0.25*Q2; R[1::2]=0.25*Q+0.75*Q2; Q=R
    return Q
def run(outdir,kstruct=9000.,cd=35.,kp=9000.,NF=132):
    P,A,B,K,L0,ring=build(); n=len(P)
    ang=math.radians(14); c,s=math.cos(ang),math.sin(ang)
    X=np.stack([P[:,0]*c-P[:,1]*s+290,P[:,0]*s+P[:,1]*c+170],1)
    V=np.zeros_like(X); V[:,0]=5; V[:,1]=150
    A0=abs(area(P[ring])); g=2000.; sub=70; dt=1/FPS/sub
    out=Out('cube',outdir,NF); col=(222,118,104)
    for f in range(NF):
        for _ in range(sub):
            d=X[A]-X[B]; l=np.linalg.norm(d,axis=1)+1e-9; u=d/l[:,None]
            rv=np.sum((V[A]-V[B])*u,axis=1)
            fs=(-(K*kstruct)*(l-L0)-cd*K*rv)[:,None]*u
            F=np.zeros_like(X)
            F[:,0]=np.bincount(A,fs[:,0],n)-np.bincount(B,fs[:,0],n)
            F[:,1]=np.bincount(A,fs[:,1],n)-np.bincount(B,fs[:,1],n)
            Q=X[ring]; Qn=np.roll(Q,-1,0); e=Qn-Q
            Ar=abs(area(Q)); pr=kp*(A0/Ar-1.0)
            nrm=np.stack([e[:,1],-e[:,0]],1)*pr
            for sgn,arr in ((0.5,ring),(0.5,np.roll(ring,-1))):
                F[:,0]+=np.bincount(arr,nrm[:,0]*sgn,n); F[:,1]+=np.bincount(arr,nrm[:,1]*sgn,n)
            F[:,1]+=g
            V+=F*dt; V*=(1-0.15*dt)
            X+=V*dt
            hit=X[:,1]>FLOOR
            X[hit,1]=FLOOR; V[hit,1]=np.where(V[hit,1]>0,-0.05*V[hit,1],V[hit,1]); V[hit,0]*=0.80
        cm=np.zeros((H,W,4),np.float32)
        slab(cm,40,FLOOR,680,FLOOR+56)
        ring_pts=chaikin(X[ring],3)
        cx=X[:,0].mean(); cy=X[:,1].mean()
        shade_poly(cm,ring_pts,col,48,center=(cx,cy))
        ymax=X[:,1].max(); hw=(X[:,0].max()-X[:,0].min())/2
        out.push(cm,shadow_layer(cm[...,3],[((X[:,0].max()+X[:,0].min())/2,hw*1.0+4,12,0.45*max(0,1-(FLOOR-ymax)/220))]))
        if f%12==0: print(f,'h',round(X[:,1].max()-X[:,1].min()),'w',round(hw*2),'ymax',round(ymax),flush=True)
    out.close()
if __name__=='__main__': run(sys.argv[1],kstruct=float(sys.argv[2]),cd=float(sys.argv[3]),kp=float(sys.argv[4]))
