# 19. Creativity Art

Six theme objects in four treatments: matte clay pale/dark and frosted-glass panel pale/dark.

## Files

| Object | Clay pale | Clay dark | Glass pale | Glass dark |
|---|---|---|---|---|
| paint-palette | `clay-paint-palette-pale.png` | `clay-paint-palette-dark.png` | `glass-paint-palette-pale.png` | `glass-paint-palette-dark.png` |
| paintbrush | `clay-paintbrush-pale.png` | `clay-paintbrush-dark.png` | `glass-paintbrush-pale.png` | `glass-paintbrush-dark.png` |
| sketchbook | `clay-sketchbook-pale.png` | `clay-sketchbook-dark.png` | `glass-sketchbook-pale.png` | `glass-sketchbook-dark.png` |
| lightbulb | `clay-lightbulb-pale.png` | `clay-lightbulb-dark.png` | `glass-lightbulb-pale.png` | `glass-lightbulb-dark.png` |
| easel | `clay-easel-pale.png` | `clay-easel-dark.png` | `glass-easel-pale.png` | `glass-easel-dark.png` |
| fountain-pen | `clay-fountain-pen-pale.png` | `clay-fountain-pen-dark.png` | `glass-fountain-pen-pale.png` | `glass-fountain-pen-dark.png` |

## Technical notes

- Clay assets: 1024 x 1024 RGBA PNG. Glass assets: 1408 x 1024 RGBA PNG.
- Real alpha transparency, transparent corner pixels, antialiased outlines and soft offset shadows. Contact-sheet checkerboard is not embedded in assets.
- Pale uses the supplied ivory / powder-blue / coral-peach matte palette. Dark is a cooler, slightly deeper treatment of the same geometry, not a black background.
- Glass panels are translucent gradient overlays with fine rim highlights. A PNG cannot dynamically blur whatever is behind it. For live glassmorphism apply backdrop blur in the destination UI; these PNGs supply the tint, rim, shadow and clay motif.
- Resolution caveat: image source sheets returned at 1536 x 1024, six objects per sheet. Individual clay objects are extracted and Lanczos-upscaled into the 1024 canvas, not native 1024 renders. Panel geometry is native output resolution.
- All six motifs are decorative, not medical advice, product branding or application interface controls.
- Generated to match the supplied visual references, then cleaned and composited. No third-party icon downloads.

## QA

See `alpha-contact-sheet.png` for all 24 variants over checkerboard. See `pale-dark-proof.png` for every asset over alternating pale and dark backgrounds. `manifest.json` records dimensions and source-object pixel size.
