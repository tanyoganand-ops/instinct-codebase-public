# Travel Places

Six tactile clay subjects, each in pale and dark material variants. All asset files are true RGBA PNGs, 1254 x 1254 pixels. Blue, peach and cream palette matched to the supplied clay reference; upper-left lighting and subtle alpha shadows.

## Assets

| Subject | Pale file | Dark file | Detail provenance |
|---|---|---|---|
| suitcase | `travel-places-suitcase-pale.png` | `travel-places-suitcase-dark.png` | native individual render |
| airplane | `travel-places-airplane-pale.png` | `travel-places-airplane-dark.png` | native individual render |
| globe | `travel-places-globe-pale.png` | `travel-places-globe-dark.png` | native individual render |
| map-pin | `travel-places-map-pin-pale.png` | `travel-places-map-pin-dark.png` | native individual render |
| instant-camera | `travel-places-instant-camera-pale.png` | `travel-places-instant-camera-dark.png` | native individual render |
| passport-tickets | `travel-places-passport-tickets-pale.png` | `travel-places-passport-tickets-dark.png` | native individual render |

## Use

Import an individual PNG into your slide, editor or animation timeline. The pale and dark names describe object materials, not a baked-in backdrop. Keep aspect ratio locked. Both work over light and dark backgrounds. Shadows are included in alpha. These are generated illustrative objects, not product photography or branded assets.

`alpha-contact-sheet.png` is an actual transparent sheet. The separate external preview uses a checkerboard to make the alpha easy to inspect. `pale-dark-background-check.png` previews both materials on both backgrounds.

## Resolution caveat

Native individual renders have 1254px detail. Assets labelled upsampled were extracted from a 512px-wide sheet cell, keyed, decontaminated and resized to 1254px. They meet the canvas-size requirement but do not have native 1024px object detail. Individual regeneration was stopped by the daily image quota. Do not present upsampled files as native high-resolution renders.

## Construction

Pale material preserves the source render. Dark uses a locally graded navy blue and richer muted terracotta with warmer cream, preserved shading and preserved alpha. No fake frosted blur is included: these packs follow the clay style, not backdrop-dependent glass.

The `map-pin` filename denotes a standalone location pin. The final isolated render does not include the folded map from the original concept.

## Alpha check

Visually inspected contact sheets, pale/dark-background composites and magnified edge crops. Magenta key spill was removed and edge colours pulled from the opaque object interior. Grid-derived assets are visibly softer when magnified and remain candidates for native rerender.
