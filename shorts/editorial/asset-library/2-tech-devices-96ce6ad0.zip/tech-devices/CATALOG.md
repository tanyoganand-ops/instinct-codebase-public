# Tech & Devices - theme asset set (tech-devices)

Part of the 20-theme asset library. Clay-3D + glassmorphism, matching the pastel matte clay look of the existing library (shorts/editorial/asset-library).

## Files
6 assets x 2 variants = 12 transparent PNGs, 1024 x 1024, RGBA (straight alpha, no matte/halo), object centred with margin, soft baked contact shadow in the alpha.
- `*-pale.png`: pastel clay for light backgrounds. `*-dark.png`: deeper night-clay tones for dark backgrounds.
- `tech-devices-alpha-contact-sheet.png`: all assets on a checkerboard (top row pale, bottom row dark).

- `earbuds-case` : `earbuds-case-pale.png`, `earbuds-case-dark.png`
- `headphones` : `headphones-pale.png`, `headphones-dark.png`
- `laptop` : `laptop-pale.png`, `laptop-dark.png`
- `smartphone` : `smartphone-pale.png`, `smartphone-dark.png`
- `smartwatch` : `smartwatch-pale.png`, `smartwatch-dark.png`
- `wireless-mouse` : `wireless-mouse-pale.png`, `wireless-mouse-dark.png`

Glass pieces (frosted, semi-transparent alpha with rim light): see names containing `glass`, plus glass screens/cups/bottles where the object has one.

## Palette
| key | role | pale | dark |
|---|---|---|---|
| A | primary | #6C93D1 | #5071A7 |
| B | secondary | #A9C4E8 | #7D95B8 |
| C | accent | #E8A28A | #AC7C73 |
| D | accent 2 | #F0C27A | #B29367 |
| W | cream / neutral light | #F3E9DB | #4B4862 |
| K | ink / detail | #3F4F6E | #2B2A3C |
| R | warm gold-brown / crust | #D9A066 | #A17A58 |
| G | glass tint | #C9DDF3 | #5E87B0 |
| M | metal grey | #C9CED8 | #6E7488 |

## Parameters
- Render: procedural height-field renderer (numpy), 1536 px internal, Lanczos downsample to 1024 (1.5x supersampling), premultiplied alpha compositing, colours un-premultiplied on export.
- Clay: soft diffuse (ambient 0.70 + 0.42 x N.L), key light from top-left (-0.5, -0.7, 0.55), faint warm bounce from lower right, broad low specular (0.16, power 28), edge ambient occlusion, fine grain noise (sigma ~0.012).
- Glass: base alpha 0.28-0.42, Fresnel edge alpha + rim highlight, white-ish edge sheen, specular streak, tint from the palette 'glass' colour.
- Contact shadow: blurred offset (+0.008, +0.016 of canvas), opacity 0.20 clay / 0.10 glass, plus a ground ellipse (opacity 0.18).
- Dark variant: palette colours x0.74 + slight blue lift, neutrals remapped (#4B4862 body, #2B2A3C ink).

## Caveats
Generated procedurally because the image generator hit its daily limit. Forms are simpler and flatter than the AI-rendered 3D clay references; swap in generated versions after the limit resets if more depth is wanted.
