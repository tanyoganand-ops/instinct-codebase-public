# Celebration Events asset set

Created 4 October 2026. Six original illustrative concepts in the supplied matte-clay palette, with pale and dark translucent glass-tile treatments.

## Files

| Concept | Clay file | Pale glass | Dark glass | Resolution source |
|---|---|---|---|---|
| gift-box | `gift-box-clay.png` | `gift-box-glass-pale.png` | `gift-box-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| birthday-cake | `birthday-cake-clay.png` | `birthday-cake-glass-pale.png` | `birthday-cake-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| balloon-trio | `balloon-trio-clay.png` | `balloon-trio-glass-pale.png` | `balloon-trio-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| party-hat | `party-hat-clay.png` | `party-hat-glass-pale.png` | `party-hat-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| trophy | `trophy-clay.png` | `trophy-glass-pale.png` | `trophy-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| event-calendar | `event-calendar-clay.png` | `event-calendar-glass-pale.png` | `event-calendar-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |

All 18 asset PNGs: 1254 x 1254 pixels, RGBA, genuine alpha channel. Empty corners are fully transparent. The contact-sheet checkerboard is not baked into asset PNGs.

## Use

- Clay files are standalone illustrations. Pale and dark glass variants are the same clay subjects on different translucent frosted-looking tiles, not alternate clay recolours.
- Glass PNGs provide tinted transparency and static reflection highlights. PNG cannot dynamically blur content behind it. Add backdrop blur in an editable layout or browser if actual live frost is needed.
- No typography is baked into the asset PNGs.
- Drop onto slide backgrounds; avoid extreme enlargements of master-sheet-crop assets.

## Quality notes

- Lower-resolution master-sheet crops were used where the image-generation daily limit prevented individual rerenders. These meet canvas dimensions but do not have native 1254-pixel detail.
- Soft shadows retained, tiny isolated alpha specks removed, low-alpha edge colour cleaned.
- `alpha-contact-sheet.png` shows every file on checkerboard. `pale-dark-check.png` shows glass treatment on opposite-tone backgrounds.
- Illustrative, generated objects. Not product photography. No third-party stock assets included.
