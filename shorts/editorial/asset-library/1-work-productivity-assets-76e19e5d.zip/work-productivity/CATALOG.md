# Work Productivity asset set

Created 4 October 2026. Six original illustrative concepts in the supplied matte-clay palette, with pale and dark translucent glass-tile treatments.

## Files

| Concept | Clay file | Pale glass | Dark glass | Resolution source |
|---|---|---|---|---|
| laptop | `laptop-clay.png` | `laptop-glass-pale.png` | `laptop-glass-dark.png` | Individual 1254 px render |
| hourglass | `hourglass-clay.png` | `hourglass-glass-pale.png` | `hourglass-glass-dark.png` | Individual 1254 px render |
| desk-clock | `desk-clock-clay.png` | `desk-clock-glass-pale.png` | `desk-clock-glass-dark.png` | Individual 1254 px render |
| clipboard | `clipboard-clay.png` | `clipboard-glass-pale.png` | `clipboard-glass-dark.png` | Individual 1254 px render |
| notebook-pencil | `notebook-pencil-clay.png` | `notebook-pencil-glass-pale.png` | `notebook-pencil-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |
| desk-organizer | `desk-organizer-clay.png` | `desk-organizer-glass-pale.png` | `desk-organizer-glass-dark.png` | Master-sheet crop, upscaled to 1254 px |

All 18 asset PNGs: 1254 x 1254 pixels, RGBA, genuine alpha channel. Empty corners are fully transparent. The contact-sheet checkerboard is not baked into asset PNGs.

## Use

- Clay files are standalone illustrations. Pale and dark glass variants are the same clay subjects on different translucent frosted-looking tiles, not alternate clay recolours.
- Glass PNGs provide tinted transparency and static reflection highlights. PNG cannot dynamically blur content behind it. Add backdrop blur in an editable layout or browser if actual live frost is needed.
- No typography is baked into the asset PNGs.
- Drop onto slide backgrounds; avoid extreme enlargements of master-sheet-crop assets.

## Quality notes

- Lower-resolution master-sheet crops were used where the image-generation daily limit prevented individual rerenders. These meet canvas dimensions but do not have native 1254-pixel detail.
- Soft shadows retained, tiny isolated alpha specks removed, low-alpha edge colour cleaned.
- `alpha-contact-sheet.png` shows every file on checkerboard. `pale-dark-check.png` shows glass treatment on opposite-tone backgrounds.
- Illustrative, generated objects. Not product photography. No third-party stock assets included.
