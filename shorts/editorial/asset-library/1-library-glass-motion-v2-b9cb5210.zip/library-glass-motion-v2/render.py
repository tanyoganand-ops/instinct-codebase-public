from PIL import Image,ImageDraw,ImageFilter,ImageFont
from pathlib import Path
import numpy as np, math, subprocess,json
p=Path(__file__).resolve().parent;p.mkdir(parents=True,exist_ok=True);W,H=720,1280;FPS=30
regular='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';bold='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
ft=ImageFont.truetype(regular,30);fb=ImageFont.truetype(bold,46)
def ease(t):
 t=max(0,min(1,t));return t*t*(3-2*t)
def bg(t,dark):
 im=Image.new('RGBA',(W,H),'#172638' if dark else '#f4f4f2');d=ImageDraw.Draw(im)
 for y in range(130,H,120):d.line((0,y,W,y),fill='#35485e' if dark else '#d5dfe8',width=3)
 x=125+70*math.sin(t*.7);d.ellipse((x-140,370,x+220,750),fill='#547daa' if dark else '#a2c3e6')
 x=530+45*math.sin(t*.8);d.ellipse((x-180,590,x+150,970),fill='#b27b65' if dark else '#f1c3a6')
 return im

def glass(im,box,rad,tint,alpha,blur,opacity=1,highlight=115,shadow=True):
 x,y,w,h=[int(v) for v in box];mask=Image.new('L',(W,H));d=ImageDraw.Draw(mask);d.rounded_rectangle((x,y,x+w,y+h),radius=rad,fill=round(255*opacity))
 if shadow:
  shmask=Image.new('L',(W,H));sd=ImageDraw.Draw(shmask);sd.rounded_rectangle((x+3,y+14,x+w+3,y+h+14),radius=rad,fill=round(45*opacity));shmask=shmask.filter(ImageFilter.GaussianBlur(17));sh=Image.new('RGBA',(W,H),(8,17,27,0));sh.putalpha(shmask);im=Image.alpha_composite(im,sh)
 actual=im.filter(ImageFilter.GaussianBlur(blur));im.paste(actual,(0,0),mask)
 layer=Image.new('RGBA',(W,H));d=ImageDraw.Draw(layer);d.rounded_rectangle((x,y,x+w,y+h),radius=rad,fill=(*tint,round(alpha*opacity)),outline=(255,255,255,round(highlight*opacity)),width=2)
 d.line((x+rad,y+2,x+w-rad,y+2),fill=(255,255,255,round(170*opacity)),width=3);layer=layer.filter(ImageFilter.GaussianBlur(.25));return Image.alpha_composite(im,layer)
def text(im,s,x,y,font,col):ImageDraw.Draw(im).text((x,y),s,font=font,fill=col)
def scene(t,kind):
 dark=kind=='parallax-dark';im=bg(t,dark);ink='#ecf3fb' if dark else '#233449'
 text(im,'Glass motion / '+('dark' if dark else 'pale'),46,185,fb,ink)
 text(im,'Component test - no product claims',46,250,ft,ink)
 if kind=='blur-pale':
  enter=ease(t/1.1);exit=1-ease((t-5.1)/.9);op=enter*exit;yy=420+(1-enter)*100-(1-exit)*50
  state='hover' if 1.6<t<2.8 else 'pressed' if 2.8<=t<3.6 else 'loading' if 3.6<=t<5.1 else 'default'
  hover=ease((t-1.6)/.25)*(1-ease((t-2.65)/.25));pressed=ease((t-2.8)/.15)*(1-ease((t-3.45)/.15));scale=1+.015*hover-.02*pressed
  ww=560*scale;hh=375*scale;xx=(W-ww)/2
  im=glass(im,(xx,yy,ww,hh),40,(224,235,247),55+25*hover+20*pressed,22*enter,op,115+55*hover)
  if op>.04:
   d=ImageDraw.Draw(im);colour=(35,52,73,round(255*op));d.text((xx+42,yy+55),'Frosted panel',font=fb,fill=colour);d.text((xx+42,yy+120),state.capitalize(),font=ft,fill=colour)
   im=glass(im,(xx+42,yy+210,310,76),32,(245,218,198),80,14,op)
   d=ImageDraw.Draw(im);d.text((xx+66,yy+232),'Loading' if state=='loading' else 'Interaction state',font=ft,fill=colour)
   if state=='loading':d.arc((xx+385,yy+225,xx+425,yy+265),start=t*260,end=t*260+255,fill=colour,width=5)
 else:
  en=ease(t/.95);ex=1-ease((t-5.1)/.9);op=en*ex
  # Independent staggered depth planes rather than a morphing carrier.
  for j,(dy,w,h) in enumerate([(0,545,310),(210,440,170),(335,305,90)]):
   ee=ease((t-j*.18)/1.15);xx=85+j*25+(1-ee)*(570 if j%2==0 else -570)+30*math.sin(t*.9+j);yy=400+dy+7*math.sin(t*1.4+j)
   im=glass(im,(xx,yy,w,h),38 if j<2 else 35,(36+8*j,62+5*j,89+4*j),100 if j==0 else 80,24 if j==0 else 16,op,140)
   if ee>.85 and op>.08:text(im,['Depth layer 01','Layer slide','Loading'][j],xx+28,yy+36 if j<2 else yy+25,ft,(239,245,252,round(255*op)))
   if j==2 and op>.1:
    d=ImageDraw.Draw(im);d.arc((xx+230,yy+23,xx+270,yy+63),start=t*220,end=t*220+250,fill=(243,212,190,round(255*op)),width=4)
 text(im,'Live backdrop blur + separate layers',46,1045,ft,ink);return im.convert('RGB')
for kind in ['blur-pale','parallax-dark']:
 target=p/f'glass-{kind}-6s.mp4';proc=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libx264','-crf','20','-pix_fmt','yuv420p','-movflags','+faststart',str(target)],stdin=subprocess.PIPE)
 picks=[]
 for n in range(180):
  im=scene(n/FPS,kind);proc.stdin.write(im.tobytes())
  if n in [0,20,45,70,95,125,155,179]:picks.append((n,im.copy()))
 proc.stdin.close();proc.wait();assert proc.returncode==0
 sheet=Image.new('RGB',(1440,1420),'#ffffff');d=ImageDraw.Draw(sheet)
 for i,(n,im) in enumerate(picks):im.thumbnail((350,625));x=(i%4)*360;y=(i//4)*700;sheet.paste(im,(x,y));d.text((x+12,y+644),f'Frame {n} / {n/FPS:.2f}s',font=ft,fill='#233449')
 sheet.save(p/f'{kind}-contact-sheet.png')
print('Rendered two 180-frame motion clips')
