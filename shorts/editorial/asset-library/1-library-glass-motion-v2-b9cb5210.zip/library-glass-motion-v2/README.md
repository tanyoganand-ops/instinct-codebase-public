# Glass motion v2

Two silent portrait motion studies, 720 x 1280, 30 fps, 180 frames, 6 seconds.

- glass-blur-pale-6s.mp4: live masked backdrop-blur entrance and fade, hover/pressed/loading sequence, separate peach chip and spinner.
- glass-parallax-dark-6s.mp4: three separate staggered depth layers with backdrop frost, lateral parallax and loading spinner.
- *-encoded-qa.png: eight labelled samples decoded from the final MP4, including entrance, settled state, exit and final frame.
- *-contact-sheet.png: original renderer samples.
- render.py and params.json: reproducible source and key parameters.

## Reuse
Run `python3 render.py` with Pillow, NumPy and ffmpeg installed. The included DejaVu font paths target Linux; substitute local font files on other systems. Change backgrounds, tint values, panel boxes or timing in scene(). Motion uses smoothstep easing for entrances/exits and hover/pressed transitions. Dark layers have independent offsets and sinusoidal drift.

These are composited preview clips, not transparent overlays. MP4 has no alpha. Actual frost blurs the scene underneath the rounded mask on each frame; a skin PNG alone cannot blur an unknown background. Use the glass-v1 RGBA skins/masks/shadows for separate static overlays, and port this blur/mask logic to the final compositor. UI wording is demonstration text, not product claims or a functional UI. No audio. Not seamless loops: entrance and exit are intentional.

## QA
Final encodes decoded successfully. Metadata checked: 720 x 1280, 30/1 fps, 180 frames, 6.000 s. Final encoded sheets visually inspected for text fit, panel edges, readable light/dark contrast, separate layers and visible background blur. No repository commits made.
