# Glass button redo

Two button-only clips rendered from the glass motion v3 source. The original button design and timing are retained: squeeze, spring overshoot/release, two press cycles, ripple rings, rim refraction, and pressure-following glow. The page copy and moving background were removed and replaced with flat, static pale-blue and deep-navy backgrounds.

- `glass_button_pale.mp4` and `glass_button_dark.mp4`: 720x1280, 30 fps, 6 seconds, H.264/yuv420p.
- `sources/`: renderer and scene sources; `scenes.py` contains the button backdrop change.
- `qa_*.png` and `qa_report.json`: decoded-frame QA sheets and report.

The videos were encoded with `python3 render_button.py` using NumPy, Pillow, SciPy, and FFmpeg. The v3 renderer uses Noto fonts from `/usr/share/fonts/truetype/noto/`.
