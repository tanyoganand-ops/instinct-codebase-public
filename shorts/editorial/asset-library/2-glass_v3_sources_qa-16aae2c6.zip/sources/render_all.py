import sys, os, time
from multiprocessing import Pool
from scenes import *
OUT = sys.argv[1] if len(sys.argv) > 1 else '/downloads/glass_v3'
def job(a):
    name, th = a; t0 = time.time()
    rc = write_mp4(f'{OUT}/glass_{name}_{th}.mp4', SCENES[name](th))
    return name, th, rc, round(time.time() - t0)
if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    jobs = [(n, t) for n in SCENES for t in ('pale', 'dark')]
    with Pool(2) as p:
        for r in p.imap_unordered(job, jobs): print(r, flush=True)
