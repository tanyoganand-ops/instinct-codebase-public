# Glass motion library v3

Four frosted-glass motion studies, each in a pale and a dark variant. 720x1280, 30 fps, 6 s (180 frames), H.264 yuv420p, all loop seamlessly.

| clip | what moves |
|---|---|
| glass_button_{pale,dark} | Liquid-glass button: two press/release cycles with squash, spring overshoot, expanding ripple rings, rim refraction and a glow that follows pressure. |
| glass_blurreveal_{pale,dark} | Hero line "Clear as glass." reveals word by word from heavy blur on a glass plate, then a specular sweep, then blurs out. |

Rendering: numpy + PIL + scipy, no external assets. Fonts are Noto Sans / Noto Serif.
- glasslib.py: backdrop, glass layer (rim light, sheen), `place()` (frosted blur, edge refraction, tint, shadow, halo), mp4 writer (dithered to avoid banding).
- scenes.py: the four scenes. Themes live in `THEMES`.
- render_all.py: renders all 8 clips (`python3 render_all.py OUT_DIR`, about 3.5 min per clip on 2 cores).
- qa.py: decodes every frame of each mp4 and writes qa_<clip>.png sheets + qa_report.json.
- still.py: render single frames to PNG for tuning (`python3 still.py stack dark 0.5 1.2`).
