"""Decode every mp4 frame and check it; write QA sheet PNG per clip + qa_report.md/json."""
import sys, glob, json, subprocess, os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
D = sys.argv[1]; Wd, Hd = 720, 1280
F = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 18)
def probe(p):
    o = subprocess.check_output(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-count_frames', '-show_entries',
        'stream=codec_name,width,height,r_frame_rate,nb_read_frames,pix_fmt:format=duration', '-of', 'json', p])
    return json.loads(o)
rep = {}
for p in sorted(glob.glob(D + '/*.mp4')):
    nm = os.path.basename(p)[:-4]; pr = probe(p); st = pr['streams'][0]
    pp = subprocess.Popen(['ffmpeg', '-loglevel', 'error', '-i', p, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], stdout=subprocess.PIPE)
    smL, lumL, stdL, chL, clL, keep = [], [], [], [], [], {}
    n = 0
    while True:
        buf = pp.stdout.read(Wd * Hd * 3)
        if len(buf) < Wd * Hd * 3: break
        f = np.frombuffer(buf, np.uint8).reshape(Hd, Wd, 3)
        q = f[::4, ::4].astype(np.float32); smL.append(q)
        lumL.append(float(f[::2, ::2].mean() / 255)); stdL.append(float(q.std()))
        chL.append(float((f[::4, ::4].min(axis=2) >= 250).mean())); clL.append(float((f[::4, ::4].max(axis=2) <= 5).mean()))
        if n % 15 == 0: keep[n] = f.copy()
        n += 1
    pp.wait()
    lum = np.array(lumL); sm = np.stack(smL); std = np.array(stdL); clip_hi = np.array(chL); clip_lo = np.array(clL)
    diffs = np.abs(np.diff(sm, axis=0)).mean(axis=(1, 2, 3))
    loopd = float(np.abs(sm[0] - sm[-1]).mean()); wrap = float(np.abs(sm[-1] - sm[0]).mean())
    med = float(np.median(diffs)); spikes = [int(i + 1) for i in range(len(diffs)) if diffs[i] > 1.0 and diffs[i] > 2.5 * max(diffs[max(i-1,0)] if i>0 else 0, diffs[i+1] if i+1<len(diffs) else 0)]  # isolated pops only (big smooth motion is fine)
    frozen = [int(i + 1) for i in np.where(diffs < 0.02)[0]]
    chk = dict(frames=n, ffprobe_frames=int(st['nb_read_frames']), size=f"{st['width']}x{st['height']}", fps=st['r_frame_rate'],
               codec=st['codec_name'], pix_fmt=st['pix_fmt'], duration=float(pr['format']['duration']),
               luma_min=float(lum.min()), luma_max=float(lum.max()), blank_frames=int((std < 6).sum()),
               max_clip_hi_pct=float(clip_hi.max() * 100), max_clip_lo_pct=float(clip_lo.max() * 100),
               diff_median=med, diff_max=float(diffs.max()), spikes=spikes, frozen_pairs=frozen,
               first_last_diff=loopd, nan_or_black=int((lum < .01).sum()))
    ok = (n == 180 and chk['size'] == '720x1280' and chk['fps'] == '30/1' and chk['blank_frames'] == 0 and not spikes
          and len(frozen) < 25 and chk['max_clip_hi_pct'] < 30 and chk['nan_or_black'] == 0 and abs(chk['duration'] - 6) < .05)
    chk['pass'] = bool(ok); rep[nm] = chk
    # QA sheet: 12 decoded frames (idx 0..165 step 15) + diff plot
    cols, rows, tw, th_ = 6, 2, 240, 427
    sheet = Image.new('RGB', (cols * tw, rows * th_ + 190), (24, 24, 28)); d = ImageDraw.Draw(sheet)
    for k, i in enumerate(range(0, 180, 15)):
        im = Image.fromarray(keep[i]).resize((tw, th_), Image.LANCZOS); sheet.paste(im, ((k % cols) * tw, (k // cols) * th_))
        d.text(((k % cols) * tw + 6, (k // cols) * th_ + 4), f'f{i} {i/30:.1f}s', fill=(255, 255, 0), font=F)
    y0 = rows * th_ + 10; d.text((8, y0), f"{nm}  {'PASS' if ok else 'FAIL'}  frames={n} {chk['size']} {chk['fps']}fps  luma {chk['luma_min']:.2f}-{chk['luma_max']:.2f}  spikes={spikes} frozen={len(frozen)} loopdiff={loopd:.2f}", fill=(255, 255, 255), font=F)
    gx0, gy0, gw, gh = 10, y0 + 36, cols * tw - 20, 130
    d.rectangle([gx0, gy0, gx0 + gw, gy0 + gh], outline=(90, 90, 90))
    mx = max(diffs.max(), 1e-3)
    pts = [(gx0 + gw * i / len(diffs), gy0 + gh - gh * v / mx) for i, v in enumerate(diffs)]
    d.line(pts, fill=(80, 220, 255), width=2); d.text((gx0 + 4, gy0 + 2), f'frame-to-frame mean abs diff (max {mx:.2f})', fill=(160, 160, 160), font=F)
    sheet.save(f'{D}/qa_{nm}.png'); print(nm, 'PASS' if ok else 'FAIL', chk, flush=True)
json.dump(rep, open(f'{D}/qa_report.json', 'w'), indent=1)
