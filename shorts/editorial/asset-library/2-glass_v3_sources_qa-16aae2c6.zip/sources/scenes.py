import math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from glasslib import *

SZ = (W, H)

# ======================= 1. SLIDE-OVER (layered sheets) =======================

# ======================= 2. LIQUID BUTTON =======================
def make_button(th):
    T = THEMES[th]
    bw_, bh_ = 540, 160
    S = (bw_, bh_)
    c = rgba_text(S, (bw_ / 2, bh_ / 2 - 2), 'Continue', font('NotoSans-SemiBold.ttf', 50), T['text'], 1, 'mm')
    L = glass_layer(bw_, bh_, 80, th, c)
    mk, ov = L
    yy, xx = np.mgrid[0:bh_, 0:bw_].astype(np.float32)
    maskf = np.asarray(mk, np.float32) / 255
    txt_alpha = np.asarray(c, np.float32)[..., 3] / 255
    ov0 = np.asarray(ov, np.float32) / 255
    def press(t, td, tr):
        if t < td: return 0.0
        if t < tr: return eo3((t - td) / .18)
        return 1 - spring((t - tr) / .95)
    events = [(.9, 1.55, 175, 80), (3.5, 4.15, 395, 62)]
    small = font('NotoSans-Medium.ttf', 30); head = font('NotoSerif-Regular.ttf', 66)
    lab = Image.new('RGBA', SZ, (0, 0, 0, 0))
    lab = comp(lab, rgba_text(SZ, (360, 400), 'Ready when', head, T['text'], 1, 'mm'), rgba_text(SZ, (360, 480), 'you are.', head, T['text'], 1, 'mm'),
               rgba_text(SZ, (360, 1010), 'Press and hold to feel the glass', small, T['sub'], 1, 'mm'))
    def frame(t):
        fr = bg(t, th)
        fr = blit(fr, lab, 360, 640)
        p = sum(press(t, td, tr) for (td, tr, tx, ty) in events)
        o = ov0.copy()
        rip = np.zeros((bh_, bw_), np.float32)
        for (td, tr, tx, ty) in events:
            age = t - td
            if 0 <= age < 1.5:
                dist = np.hypot(xx - tx, yy - ty)
                R = age * 560 * (1 - .25 * age / 1.5)
                fade = (1 - age / 1.5) ** 1.6
                rip += np.exp(-((dist - R) / 24) ** 2) * fade * .60
                rip += np.exp(-((dist - R * .62) / 34) ** 2) * fade * .30 * (age > .12)
                rip += np.exp(-dist ** 2 / (2 * 80 ** 2)) * press(t, td, tr) * .30
        rip = np.clip(rip, 0, .9) * maskf
        # blend ripple highlight (white) under text colour
        a0 = o[..., 3]; a1 = a0 + rip * (1 - a0)
        rgb = np.where(a1[..., None] > 0, (o[..., :3] * a0[..., None] + 1.0 * (rip * (1 - a0))[..., None]) / np.maximum(a1[..., None], 1e-5), 1)
        o2 = np.concatenate([rgb, a1[..., None]], -1)
        ov2 = Image.fromarray((np.clip(o2, 0, 1) * 255 + .5).astype(np.uint8), 'RGBA')
        # re-apply text on top so it stays crisp
        ov2 = Image.alpha_composite(ov2, c)
        sxv = 1 - .05 * p; syv = 1 - .085 * p
        fr = place(fr, (mk, ov2), 360, 700, th, sx=sxv, sy=syv, backdrop=None, blur_s=22, K=750 + 500 * max(p, 0), rim=.75,
                   tint_a=T['ta'] + .10 * max(p, 0), glow=T['glow'], glow_amt=.35 + .5 * max(p, 0))
        return fr
    return frame

# ======================= 3. CARD STACK SHUFFLE =======================

# ======================= 4. BLUR-REVEAL HERO LINE =======================
def make_reveal(th):
    T = THEMES[th]
    pw, ph_ = 620, 520
    LP = glass_layer(pw, ph_, 64, th, None)
    lines = [['Clear', 'as'], ['glass.']]
    fsz = 150
    fn = font('NotoSerif-Regular.ttf', fsz)
    while fn.getlength('Clear as') > 520: fsz -= 4; fn = font('NotoSerif-Regular.ttf', fsz)
    sp = fn.getlength(' ')
    words = []; ys = [470, 470 + int(fsz * 1.18)]
    for li, ln in enumerate(lines):
        tot = sum(fn.getlength(w) for w in ln) + sp * (len(ln) - 1); x = 360 - tot / 2
        for w in ln:
            wl = fn.getlength(w); words.append(dict(w=w, x=x, y=ys[li], wl=wl)); x += wl + sp
    PADW = 90
    for d in words:
        im = Image.new('L', (int(d['wl']) + 2 * PADW, int(fsz * 1.5) + 2 * PADW), 0)
        ImageDraw.Draw(im).text((PADW, PADW), d['w'], font=fn, fill=255, anchor='ls' if False else 'la')
        d['im'] = im
    # plate mask in frame coords (for sweep)
    pm = Image.new('L', SZ, 0); pm.paste(LP[0], (360 - pw // 2, 640 - ph_ // 2))
    plate_m = np.asarray(pm, np.float32) / 255
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    proj = xx * .80 + yy * .60
    starts = [.55, 1.0, 1.45]
    tc = A(T['text'])
    def frame(t):
        fr = bg(t, th)
        pl = eo3(t / .9) * (1 - eio((t - 5.25) / .65))
        fr = place(fr, LP, 360, 640, th, sx=.94 + .06 * pl, op=pl, blur_s=30, tint_a=T['ta'] + .03, rim=.6)
        ex = eio((t - 5.0) / .85)
        tm_all = np.zeros((H, W), np.float32)
        for i, d in enumerate(words):
            e = eo3((t - starts[i]) / 1.4)
            if e <= 0 or ex >= 1: continue
            b = 38 * (1 - e) ** 1.7 + 34 * ex
            im = d['im'].filter(ImageFilter.GaussianBlur(b)) if b > .3 else d['im']
            m = np.asarray(im, np.float32) / 255
            m = np.clip(m * (1 + b * .035), 0, 1) * e ** .8 * (1 - ex)
            x0 = int(d['x'] - PADW); y0 = int(d['y'] - PADW + 22 * (1 - e) * -1 + 24 * (1 - e) - 24 * (1 - e) + 0)
            y0 = int(d['y'] - PADW - 26 * (1 - e) + 26 * ex * -0)
            h_, w_ = m.shape
            sx0, sy0 = max(0, -x0), max(0, -y0); ex0, ey0 = min(w_, W - x0), min(h_, H - y0)
            if ex0 <= sx0 or ey0 <= sy0: continue
            mm = m[sy0:ey0, sx0:ex0]
            reg = fr[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0]
            fr[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0] = reg * (1 - mm[..., None]) + tc * mm[..., None]
            tm_all[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0] = np.maximum(tm_all[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0], mm)
        # specular sweep across plate + text
        if 3.0 < t < 4.7:
            pos = -150 + (t - 3.0) / 1.7 * 1500
            band = np.exp(-((proj - pos) / 90) ** 2)
            hl = band * plate_m * (.30 if th == 'pale' else .22) * pl
            fr = fr + (1 - fr) * hl[..., None]
            tb = band * tm_all * .75
            lightcol = A((1, 1, 1)) if th == 'dark' else A((1, .96, .90))
            fr = fr * (1 - tb[..., None]) + lightcol * tb[..., None]
        return fr
    return frame

SCENES = dict(button=make_button, blurreveal=make_reveal)
