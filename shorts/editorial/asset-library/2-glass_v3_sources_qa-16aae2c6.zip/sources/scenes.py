import math
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from glasslib import *

SZ = (W, H)

# ======================= 1. SLIDE-OVER (layered sheets) =======================
def make_slideover(th):
    T = THEMES[th]
    # page behind (static RGBA, full frame)
    pg = Image.new('RGBA', SZ, (0, 0, 0, 0))
    pg = comp(pg, rgba_text(SZ, (56, 96), 'Today', font('NotoSans-Bold.ttf', 92), T['text']),
              rgba_text(SZ, (60, 205), 'Sunday, 4 October', font('NotoSans-Regular.ttf', 32), T['sub']))
    names = [('Aurora', 'Morning light'), ('Meadow', 'Soft focus'), ('Lantern', 'After dark'), ('Tidepool', 'Slow tide')]
    for i, (n, s) in enumerate(names):
        y = 290 + i * 230
        pg = comp(pg, rr_shape(SZ, (40, y, 680, y + 200), 38, T['card'][i], .96),
                  rr_shape(SZ, (70, y + 40, 190, y + 160), 30, T['accents'][i], 1),
                  rgba_text(SZ, (222, y + 52), n, font('NotoSans-SemiBold.ttf', 44), T['text']),
                  rgba_text(SZ, (222, y + 112), s, font('NotoSans-Regular.ttf', 30), T['sub']))
    # sheet A
    aw, ah = 680, 940
    ca = Image.new('RGBA', (aw, ah), (0, 0, 0, 0)); S = (aw, ah)
    ca = comp(ca, rr_shape(S, (aw / 2 - 42, 20, aw / 2 + 42, 29), 4.5, T['text'], .35),
              rgba_text(S, (46, 64), 'Library', font('NotoSans-Bold.ttf', 64), T['text']))
    rows = [('Aurora', '24 items'), ('Meadow', '18 items'), ('Lantern', '31 items'), ('Tidepool', '9 items')]
    for i, (n, s) in enumerate(rows):
        y = 190 + i * 150
        ca = comp(ca, rr_shape(S, (46, y, 46 + 96, y + 96), 28, T['accents'][i], .95),
                  rgba_text(S, (172, y + 6), n, font('NotoSans-SemiBold.ttf', 40), T['text']),
                  rgba_text(S, (172, y + 56), s, font('NotoSans-Regular.ttf', 28), T['sub']),
                  rr_shape(S, (46, y + 128, aw - 46, y + 129.5), .7, T['text'], .12))
    LA = glass_layer(aw, ah, 58, th, ca)
    # sheet B
    bw_, bh_ = 560, 600
    cb = Image.new('RGBA', (bw_, bh_), (0, 0, 0, 0)); S2 = (bw_, bh_)
    cb = comp(cb, rgba_text(S2, (44, 46), 'Share', font('NotoSans-Bold.ttf', 54), T['text']),
              rgba_text(S2, (46, 116), 'Send to someone nearby', font('NotoSans-Regular.ttf', 28), T['sub']))
    for i in range(3):
        x = 46 + i * 160
        cb = comp(cb, rr_shape(S2, (x, 190, x + 120, 310), 60, T['accents'][i], .95))
    cb = comp(cb, rr_shape(S2, (46, 440, bw_ - 46, 540), 50, T['accents'][1] if th == 'dark' else T['text'], .85),
              rgba_text(S2, (bw_ / 2, 490), 'Send', font('NotoSans-SemiBold.ttf', 38), (1, 1, 1) if th == 'pale' else (.02, .05, .1), 1, 'mm'))
    LB = glass_layer(bw_, bh_, 50, th, cb)
    dimv = T['dim']

    def frame(t):
        base = bg(t, th)
        ain = sstep(.3, 1.45, t) * (1 - sstep(5.0, 5.9, t))
        a = spring((t - .3) / 1.3); aout = eio((t - 5.0) / .9)
        topA = 420 + (1 - a) * 900 + aout * 900
        pa = ain
        fr = blit(base, pg, 360, 640, 1 - .06 * pa, dy=-34 * pa)
        fr = fr * (1 - dimv * pa)
        # backdrop for A: the page with extra parallax (live shift) 
        bdA = blit(bg(t, th), pg, 360, 640, 1.04 - .06 * pa, dy=-34 * pa - (900 - (topA - 420)) * .18 - 40 * pa)
        bdA = bdA * (1 - dimv * pa)
        bpres = eio((t - 2.4) / 1.1) * (1 - eio((t - 4.5) / .8))
        aS = 1 - .045 * bpres
        fr = place(fr, LA, 360, topA + ah / 2 - (1 - aS) * 100, th, sx=aS, op=min(1, 1.2 * c01(a * 3)), backdrop=bdA, blur_s=24)
        if bpres > 0 or 2.3 < t < 5.4:
            b = spring((t - 2.4) / 1.15); bo = eio((t - 4.5) / .8)
            cxB = 360 + (1 - b) * 760 + bo * 760
            bd = shift_img(fr, -60 * (1 - bpres) * 0 - 50 * bpres, 0)
            fr = place(fr, LB, cxB, 760, th, backdrop=bd, blur_s=20, tint_a=T['ta'] + .06, rim=.6)
        return fr
    return frame

# ======================= 2. LIQUID BUTTON =======================
def make_button(th):
    T = THEMES[th]
    bw_, bh_ = 540, 160
    S = (bw_, bh_)
    c = rgba_text(S, (bw_ / 2, bh_ / 2 - 2), 'Continue', font('NotoSans-SemiBold.ttf', 50), T['text'], 1, 'mm')
    L = glass_layer(bw_, bh_, 80, th, c)
    mk, ov = L
    yy, xx = np.mgrid[0:bh_, 0:bw_].astype(np.float32)
    maskf = np.asarray(mk, np.float32) / 255
    txt_alpha = np.asarray(c, np.float32)[..., 3] / 255
    ov0 = np.asarray(ov, np.float32) / 255
    def press(t, td, tr):
        if t < td: return 0.0
        if t < tr: return eo3((t - td) / .18)
        return 1 - spring((t - tr) / .95)
    events = [(.9, 1.55, 175, 80), (3.5, 4.15, 395, 62)]
    small = font('NotoSans-Medium.ttf', 30); head = font('NotoSerif-Regular.ttf', 66)
    lab = Image.new('RGBA', SZ, (0, 0, 0, 0))
    lab = comp(lab, rgba_text(SZ, (360, 400), 'Ready when', head, T['text'], 1, 'mm'), rgba_text(SZ, (360, 480), 'you are.', head, T['text'], 1, 'mm'),
               rgba_text(SZ, (360, 1010), 'Press and hold to feel the glass', small, T['sub'], 1, 'mm'))
    def frame(t):
        fr = bg(t, th)
        fr = blit(fr, lab, 360, 640)
        p = sum(press(t, td, tr) for (td, tr, tx, ty) in events)
        o = ov0.copy()
        rip = np.zeros((bh_, bw_), np.float32)
        for (td, tr, tx, ty) in events:
            age = t - td
            if 0 <= age < 1.5:
                dist = np.hypot(xx - tx, yy - ty)
                R = age * 560 * (1 - .25 * age / 1.5)
                fade = (1 - age / 1.5) ** 1.6
                rip += np.exp(-((dist - R) / 24) ** 2) * fade * .60
                rip += np.exp(-((dist - R * .62) / 34) ** 2) * fade * .30 * (age > .12)
                rip += np.exp(-dist ** 2 / (2 * 80 ** 2)) * press(t, td, tr) * .30
        rip = np.clip(rip, 0, .9) * maskf
        # blend ripple highlight (white) under text colour
        a0 = o[..., 3]; a1 = a0 + rip * (1 - a0)
        rgb = np.where(a1[..., None] > 0, (o[..., :3] * a0[..., None] + 1.0 * (rip * (1 - a0))[..., None]) / np.maximum(a1[..., None], 1e-5), 1)
        o2 = np.concatenate([rgb, a1[..., None]], -1)
        ov2 = Image.fromarray((np.clip(o2, 0, 1) * 255 + .5).astype(np.uint8), 'RGBA')
        # re-apply text on top so it stays crisp
        ov2 = Image.alpha_composite(ov2, c)
        sxv = 1 - .05 * p; syv = 1 - .085 * p
        fr = place(fr, (mk, ov2), 360, 700, th, sx=sxv, sy=syv, backdrop=None, blur_s=22, K=750 + 500 * max(p, 0), rim=.75,
                   tint_a=T['ta'] + .10 * max(p, 0), glow=T['glow'], glow_amt=.35 + .5 * max(p, 0))
        return fr
    return frame

# ======================= 3. CARD STACK SHUFFLE =======================
def make_stack(th):
    T = THEMES[th]
    cw, chh = 540, 340; S = (cw, chh)
    titles = [('Morning', 'Slow start, soft light'), ('Focus', 'Two hours, no noise'), ('Evening', 'Wind down together'), ('Rest', 'Lights low, phone away')]
    layers = []
    for i, (n, s) in enumerate(titles):
        c = Image.new('RGBA', S, (0, 0, 0, 0))
        c = comp(c, rr_shape(S, (40, 44, 130, 134), 45, T['accents'][i], .95),
                 rgba_text(S, (160, 44), n, font('NotoSans-Bold.ttf', 50), T['text']),
                 rgba_text(S, (162, 104), s, font('NotoSans-Regular.ttf', 27), T['sub']),
                 rr_shape(S, (40, 190, 360, 204), 7, T['text'], .16), rr_shape(S, (40, 224, 280, 238), 7, T['text'], .10),
                 rgba_text(S, (cw - 40, chh - 36), f'0{i+1}', font('NotoSans-Light.ttf', 56), T['text'], .55, 'rs'))
        layers.append(glass_layer(cw, chh, 46, th, c))
    SL = [dict(cy=700, s=1.0, r=0.0, op=1.0), dict(cy=632, s=.93, r=-2.2, op=.96), dict(cy=568, s=.86, r=2.4, op=.92), dict(cy=508, s=.79, r=-3.0, op=.88)]
    P = 1.5
    head = Image.new('RGBA', SZ, (0, 0, 0, 0))
    head = comp(head, rgba_text(SZ, (360, 170), 'Your day', font('NotoSerif-Regular.ttf', 74), T['text'], 1, 'mm'),
                rgba_text(SZ, (360, 240), 'Four moods, one deck', font('NotoSans-Medium.ttf', 30), T['sub'], 1, 'mm'))
    def lerp(a, b, e): return a + (b - a) * e
    def pose(j, e):  # slot j -> j-1
        a, b = SL[j], SL[j - 1]
        return {k: lerp(a[k], b[k], e) for k in a}
    def frame(t):
        fr = bg(t, th)
        fr = blit(fr, head, 360, 640)
        k = int(t // P); ph = (t - k * P) / P
        u = c01((ph - .10) / .80)
        order = [(k + j) % 4 for j in range(4)]   # card id at slot j
        e = spring(u) if u < 1 else 1.0
        e_arc = eio(u)
        items = []
        for j in range(4):
            cid = order[j]
            if j == 0:
                a, b = SL[0], SL[3]
                pz = {kk: lerp(a[kk], b[kk], e_arc) for kk in a}
                pz['x'] = 360 + math.sin(math.pi * e_arc) * 320
                pz['r'] += math.sin(math.pi * e_arc) * 13
                pz['cy'] -= math.sin(math.pi * e_arc) * 40
                z = -1 if u < .5 else 9
            else:
                pz = pose(j, e); pz['x'] = 360; z = j - e
                if u > 0: pass
            items.append((z, cid, pz))
        items.sort(key=lambda a: -a[0])
        for z, cid, pz in items:
            fr = place(fr, layers[cid], pz['x'], pz['cy'], th, sx=pz['s'], rot=pz['r'], op=pz['op'], blur_s=22, rim=.55)
        return fr
    return frame

# ======================= 4. BLUR-REVEAL HERO LINE =======================
def make_reveal(th):
    T = THEMES[th]
    pw, ph_ = 620, 520
    LP = glass_layer(pw, ph_, 64, th, None)
    lines = [['Clear', 'as'], ['glass.']]
    fsz = 150
    fn = font('NotoSerif-Regular.ttf', fsz)
    while fn.getlength('Clear as') > 520: fsz -= 4; fn = font('NotoSerif-Regular.ttf', fsz)
    sp = fn.getlength(' ')
    words = []; ys = [470, 470 + int(fsz * 1.18)]
    for li, ln in enumerate(lines):
        tot = sum(fn.getlength(w) for w in ln) + sp * (len(ln) - 1); x = 360 - tot / 2
        for w in ln:
            wl = fn.getlength(w); words.append(dict(w=w, x=x, y=ys[li], wl=wl)); x += wl + sp
    PADW = 90
    for d in words:
        im = Image.new('L', (int(d['wl']) + 2 * PADW, int(fsz * 1.5) + 2 * PADW), 0)
        ImageDraw.Draw(im).text((PADW, PADW), d['w'], font=fn, fill=255, anchor='ls' if False else 'la')
        d['im'] = im
    # plate mask in frame coords (for sweep)
    pm = Image.new('L', SZ, 0); pm.paste(LP[0], (360 - pw // 2, 640 - ph_ // 2))
    plate_m = np.asarray(pm, np.float32) / 255
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    proj = xx * .80 + yy * .60
    starts = [.55, 1.0, 1.45]
    tc = A(T['text'])
    def frame(t):
        fr = bg(t, th)
        pl = eo3(t / .9) * (1 - eio((t - 5.25) / .65))
        fr = place(fr, LP, 360, 640, th, sx=.94 + .06 * pl, op=pl, blur_s=30, tint_a=T['ta'] + .03, rim=.6)
        ex = eio((t - 5.0) / .85)
        tm_all = np.zeros((H, W), np.float32)
        for i, d in enumerate(words):
            e = eo3((t - starts[i]) / 1.4)
            if e <= 0 or ex >= 1: continue
            b = 38 * (1 - e) ** 1.7 + 34 * ex
            im = d['im'].filter(ImageFilter.GaussianBlur(b)) if b > .3 else d['im']
            m = np.asarray(im, np.float32) / 255
            m = np.clip(m * (1 + b * .035), 0, 1) * e ** .8 * (1 - ex)
            x0 = int(d['x'] - PADW); y0 = int(d['y'] - PADW + 22 * (1 - e) * -1 + 24 * (1 - e) - 24 * (1 - e) + 0)
            y0 = int(d['y'] - PADW - 26 * (1 - e) + 26 * ex * -0)
            h_, w_ = m.shape
            sx0, sy0 = max(0, -x0), max(0, -y0); ex0, ey0 = min(w_, W - x0), min(h_, H - y0)
            if ex0 <= sx0 or ey0 <= sy0: continue
            mm = m[sy0:ey0, sx0:ex0]
            reg = fr[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0]
            fr[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0] = reg * (1 - mm[..., None]) + tc * mm[..., None]
            tm_all[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0] = np.maximum(tm_all[y0 + sy0:y0 + ey0, x0 + sx0:x0 + ex0], mm)
        # specular sweep across plate + text
        if 3.0 < t < 4.7:
            pos = -150 + (t - 3.0) / 1.7 * 1500
            band = np.exp(-((proj - pos) / 90) ** 2)
            hl = band * plate_m * (.30 if th == 'pale' else .22) * pl
            fr = fr + (1 - fr) * hl[..., None]
            tb = band * tm_all * .75
            lightcol = A((1, 1, 1)) if th == 'dark' else A((1, .96, .90))
            fr = fr * (1 - tb[..., None]) + lightcol * tb[..., None]
        return fr
    return frame

SCENES = dict(slideover=make_slideover, button=make_button, stack=make_stack, blurreveal=make_reveal)
