"""Glass motion library v3 - numpy/PIL renderer. 720x1280, 30fps, 6s, seamless loops."""
import math, subprocess
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from scipy.ndimage import gaussian_filter

W, H, FPS, DUR = 720, 1280, 30, 6.0
N = int(FPS * DUR)
FD = '/usr/share/fonts/truetype/noto/'
def font(n, s): return ImageFont.truetype(FD + n, s)
def c01(x): return min(1.0, max(0.0, x))
def sstep(a, b, x): t = c01((x - a) / (b - a)); return t * t * (3 - 2 * t)
def eo3(t): t = c01(t); return 1 - (1 - t) ** 3
def eio(t): t = c01(t); return 0.5 - 0.5 * math.cos(math.pi * t)
def spring(t): t = c01(t); return 1 - math.exp(-7 * t) * math.cos(11 * t)
def A(c): return np.array(c, np.float32)

THEMES = {
 'pale': dict(top=(.78,.89,.99), bot=(1.0,.91,.87),
   orbs=[(.2,.22,300,(1,.74,.62),.10,.06,1,0.0,.85),(.85,.5,330,(.62,.93,.84),.08,.07,1,2.0,.8),
         (.3,.82,320,(.76,.72,.99),.10,.05,1,4.0,.85),(.7,.1,260,(.62,.82,1),.08,.05,2,1.0,.7)],
   dot=(1,1,1), dot_a=.55,
   discs=[(.25,.40,95,(1,.62,.55)),(.78,.58,120,(.45,.75,1)),(.35,.66,70,(.98,.82,.40)),(.72,.30,60,(.60,.88,.72)),(.50,.52,110,(.78,.60,.98))],
   ringcol=(1,1,1), tint=(1,1,1), ta=.30, sat=1.18, text=(.10,.14,.27), sub=(.33,.38,.55),
   shadow=.20, shadow_col=(.15,.2,.4), spec=1.0, card=[(1,.93,.90),(.90,.97,.96),(.93,.92,1),(1,.97,.88)],
   accents=[(1,.55,.45),(.35,.78,.65),(.55,.5,.95),(.95,.72,.25)], glow=(.55,.7,1), dim=.10),
 'dark': dict(top=(.03,.04,.10), bot=(.08,.03,.13),
   orbs=[(.2,.22,300,(.05,.75,.80),.10,.06,1,0.0,.75),(.85,.5,330,(.85,.15,.60),.08,.07,1,2.0,.7),
         (.3,.82,320,(.30,.25,.95),.10,.05,1,4.0,.8),(.7,.1,260,(.95,.50,.15),.08,.05,2,1.0,.55)],
   dot=(.7,.8,1), dot_a=.45,
   discs=[(.25,.40,95,(.10,.85,.85)),(.78,.58,120,(.95,.25,.65)),(.35,.66,70,(.98,.65,.20)),(.72,.30,60,(.40,.45,1)),(.50,.52,110,(.55,.30,.95))],
   ringcol=(.7,.85,1), tint=(.72,.8,1), ta=.10, sat=1.25, text=(.96,.97,1), sub=(.70,.75,.90),
   shadow=.55, shadow_col=(0,0,.03), spec=.8, card=[(.25,.15,.2),(.12,.24,.26),(.18,.17,.34),(.28,.22,.12)],
   accents=[(1,.45,.5),(.2,.85,.8),(.55,.55,1),(1,.75,.3)], glow=(.3,.45,1), dim=.35),
}

# ---------- primitives ----------
def disc_sdf(fr, cx, cy, r, col, a=1.0, ring=None, rw=3.0):
    x0, x1 = int(max(0, cx - r - 6)), int(min(W, cx + r + 6)); y0, y1 = int(max(0, cy - r - 6)), int(min(H, cy + r + 6))
    if x1 <= x0 or y1 <= y0: return
    y, x = np.mgrid[y0:y1, x0:x1].astype(np.float32)
    d = np.hypot(x + .5 - cx, y + .5 - cy) - r
    if ring is None:
        m = np.clip(.5 - d, 0, 1) * a
    else:
        m = np.clip(1 - np.abs(d) / rw + .0, 0, 1) * a
    fr[y0:y1, x0:x1] = fr[y0:y1, x0:x1] * (1 - m[..., None]) + A(col) * m[..., None]

def bg(t, th):
    T = THEMES[th]; ph = 2 * math.pi * t / DUR
    lw, lh = 90, 160
    gy = np.linspace(0, 1, lh, dtype=np.float32)[:, None]; gx = np.linspace(0, 1, lw, dtype=np.float32)[None, :]
    base = A(T['top'])[None, None, :] * (1 - gy[..., None]) + A(T['bot'])[None, None, :] * gy[..., None]
    base = np.broadcast_to(base, (lh, lw, 3)).copy()
    for (cx, cy, r, col, ax, ay, k, p, amp) in T['orbs']:
        x = cx + ax * math.sin(ph * k + p); y = cy + ay * math.cos(ph * k + p)
        g = np.exp(-(((gx - x) * W) ** 2 + ((gy - y) * H) ** 2) / (2 * r * r)) * amp
        base = base * (1 - g[..., None]) + A(col) * g[..., None]
    out = np.empty((H, W, 3), np.float32)
    for c in range(3):
        out[..., c] = np.asarray(Image.fromarray(base[..., c].astype(np.float32), 'F').resize((W, H), Image.BICUBIC))
    # drifting dot grid (loops exactly each DUR)
    sp = 48.0
    axv = np.cos(2 * np.pi * (np.arange(W) + t / DUR * sp) / sp); ayv = np.cos(2 * np.pi * (np.arange(H) + t / DUR * sp * .5 * 2) / sp)
    m = np.clip((ayv[:, None] * axv[None, :] - .88) / .08, 0, 1) * T['dot_a']
    out = out * (1 - m[..., None]) + A(T['dot']) * m[..., None]
    # sharp discs and rings that glass can refract
    for i, (cx, cy, r, col) in enumerate(T['discs']):
        x = cx * W + 70 * math.sin(ph + i * 1.3); y = cy * H + 60 * math.cos(ph + i * 1.7)
        disc_sdf(out, x, y, r, col, .95)
        disc_sdf(out, x, y, r * 1.45, T['ringcol'], .7, ring=True, rw=3)
    return np.clip(out, 0, 1)

def blur(img, s):
    sq = img.ndim == 2
    if sq: img = img[..., None]
    h, w, c = img.shape
    ds = 4 if s >= 14 else (2 if s >= 6 else 1)
    if ds > 1:
        hh, ww = h // ds * ds, w // ds * ds
        small = img[:hh, :ww].reshape(hh // ds, ds, ww // ds, ds, c).mean((1, 3))
        small = gaussian_filter(small, (s / ds, s / ds, 0), mode='nearest')
        up = np.empty((hh, ww, c), np.float32)
        for k in range(c):
            up[..., k] = np.asarray(Image.fromarray(small[..., k].astype(np.float32), 'F').resize((ww, hh), Image.BICUBIC))
        out = np.pad(up, ((0, h - hh), (0, w - ww), (0, 0)), mode='edge')
    else:
        out = gaussian_filter(img, (s, s, 0), mode='nearest')
    return out[..., 0] if sq else out

def remap(img, dx, dy):
    h, w, c = img.shape
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float32)
    x = np.clip(xs + dx, 0, w - 1.001); y = np.clip(ys + dy, 0, h - 1.001)
    x0 = x.astype(int); y0 = y.astype(int); fx = (x - x0)[..., None]; fy = (y - y0)[..., None]
    a = img[y0, x0] * (1 - fx) + img[y0, x0 + 1] * fx
    b = img[y0 + 1, x0] * (1 - fx) + img[y0 + 1, x0 + 1] * fx
    return a * (1 - fy) + b * fy

def rgba_text(size, xy, txt, fnt, col, alpha=1.0, anchor='la'):
    L = Image.new('RGBA', size, tuple(int(c * 255) for c in col) + (0,))
    ImageDraw.Draw(L).text(xy, txt, font=fnt, fill=tuple(int(c * 255) for c in col) + (int(alpha * 255),), anchor=anchor)
    return L

def rr_shape(size, box, r, col, alpha=1.0):
    """antialiased rounded rect (or circle) as RGBA layer of full `size`"""
    x0, y0, x1, y1 = box; w, h = size
    xa, xb = int(max(0, x0 - 2)), int(min(w, x1 + 2)); ya, yb = int(max(0, y0 - 2)), int(min(h, y1 + 2))
    out = np.zeros((h, w, 4), np.float32); out[..., :3] = A(col)
    y, x = np.mgrid[ya:yb, xa:xb].astype(np.float32); x += .5; y += .5
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    qx = np.abs(x - cx) - ((x1 - x0) / 2 - r); qy = np.abs(y - cy) - ((y1 - y0) / 2 - r)
    sd = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
    out[ya:yb, xa:xb, 3] = np.clip(.5 - sd, 0, 1) * alpha
    return Image.fromarray((out * 255 + .5).astype(np.uint8), 'RGBA')

def comp(base, *layers):
    for l in layers: base = Image.alpha_composite(base, l)
    return base

def glass_layer(w, h, r, th, content=None, spec=1.0):
    """returns (mask L, overlay RGBA): rim light, inner glow, top sheen, plus content"""
    T = THEMES[th]; k = T['spec'] * spec
    y, x = np.mgrid[0:h, 0:w].astype(np.float32); x += .5; y += .5
    qx = np.abs(x - w / 2) - (w / 2 - r); qy = np.abs(y - h / 2) - (h / 2 - r)
    sd = np.hypot(np.maximum(qx, 0), np.maximum(qy, 0)) + np.minimum(np.maximum(qx, qy), 0) - r
    mask = np.clip(.5 - sd, 0, 1)
    band = np.clip(1 - np.abs(sd + 1.0) / 1.3, 0, 1)
    nx = (x - w / 2) / w; ny = (y - h / 2) / h
    dirv = (nx * .7 + ny * .9)
    light = np.clip(.55 - dirv * 1.2, 0, 1); dark = np.clip(dirv * 1.2 - .15, 0, 1)
    border = band * (.22 + .65 * light + .25 * dark)
    depth = np.clip(-sd, 0, None)
    glow = np.exp(-depth / 9) * mask * (.10 + .14 * light)
    sheen = np.clip(1 - y / (h * .5), 0, 1) ** 2 * .08 * mask
    a = np.clip((border + glow + sheen) * k, 0, 1)
    ov = np.zeros((h, w, 4), np.float32); ov[..., :3] = 1; ov[..., 3] = a
    ovi = Image.fromarray((ov * 255 + .5).astype(np.uint8), 'RGBA')
    if content is not None: ovi = Image.alpha_composite(ovi, content)
    return Image.fromarray((mask * 255 + .5).astype(np.uint8), 'L'), ovi

def place(fr, layer, cx, cy, th, sx=1.0, sy=None, rot=0.0, op=1.0, backdrop=None, blur_s=26,
          tint_a=None, shadow=1.0, K=700.0, rim=.5, glow=None, glow_amt=0.0, sat=None):
    sy = sx if sy is None else sy
    mk, ov = layer; lw, lh = mk.size; T = THEMES[th]
    t_ = math.radians(rot); co, si = math.cos(t_), math.sin(t_)
    corners = []
    for (u, v) in [(0, 0), (lw, 0), (0, lh), (lw, lh)]:
        du, dv = (u - lw / 2) * sx, (v - lh / 2) * sy
        corners.append((cx + co * du - si * dv, cy + si * du + co * dv))
    pad = 110
    x0 = int(max(0, min(p[0] for p in corners) - pad)); x1 = int(min(W, max(p[0] for p in corners) + pad))
    y0 = int(max(0, min(p[1] for p in corners) - pad)); y1 = int(min(H, max(p[1] for p in corners) + pad))
    if x1 - x0 < 8 or y1 - y0 < 8 or op <= 0: return fr
    bw, bh = x1 - x0, y1 - y0
    a_, b_ = co / sx, si / sx; d_, e_ = -si / sy, co / sy
    c_ = lw / 2 - (co * cx + si * cy) / sx; f_ = lh / 2 - (-si * cx + co * cy) / sy
    c2 = c_ + a_ * x0 + b_ * y0; f2 = f_ + d_ * x0 + e_ * y0
    data = (a_, b_, c2, d_, e_, f2)
    m = np.asarray(mk.transform((bw, bh), Image.AFFINE, data, Image.BICUBIC), np.float32) / 255
    o = np.asarray(ov.transform((bw, bh), Image.AFFINE, data, Image.BILINEAR), np.float32) / 255
    if m.max() <= 0: return fr
    cur = fr[y0:y1, x0:x1].copy()
    bd = (backdrop if backdrop is not None else fr)[y0:y1, x0:x1]
    big = blur(bd, blur_s)
    g = blur(m, 10)
    gy_, gx_ = np.gradient(g)
    ew = (1 - np.clip((g - .5) / .35, 0, 1)) * rim
    small = remap(blur(bd, 3.0), gx_ * K, gy_ * K)
    col = big * (1 - ew[..., None]) + small * ew[..., None]
    ta = T['ta'] if tint_a is None else tint_a
    col = col * (1 - ta) + A(T['tint']) * ta
    sv = T['sat'] if sat is None else sat
    lum = col.mean(2, keepdims=True); col = np.clip(lum + (col - lum) * sv, 0, 1)
    # shadow + halo
    if shadow > 0:
        sm = np.zeros_like(m); sm[16:] = m[:-16]; sh = blur(sm, 18) * T['shadow'] * shadow * op
        cur = cur * (1 - sh[..., None] * (1 - m[..., None])) + A(T['shadow_col']) * (sh[..., None] * (1 - m[..., None]) * .25)
    if glow is not None and glow_amt > 0:
        hl = blur(m, 34) * glow_amt * op
        cur = cur + A(glow) * (hl * (1 - m))[..., None]
    mo = (m * op)[..., None]
    out = cur * (1 - mo) + col * mo
    ao = (o[..., 3] * op)[..., None]
    out = out * (1 - ao) + o[..., :3] * ao
    fr[y0:y1, x0:x1] = np.clip(out, 0, 1)
    return fr

def blit(fr, img, cx, cy, s=1.0, dy=0.0, dx=0.0, op=1.0):
    """composite a full-frame RGBA image scaled about (cx,cy) then offset"""
    iw, ih = img.size
    a_ = 1 / s; c_ = iw / 2 - (cx + dx) / s * 1 + 0
    # screen = (cx+dx,cy+dy) + s*(local-center) ; inverse: local = center + (screen-(cx+dx,cy+dy))/s
    c_ = iw / 2 - (cx + dx) / s; f_ = ih / 2 - (cy + dy) / s
    t = img.transform((W, H), Image.AFFINE, (a_, 0, c_, 0, a_, f_), Image.BICUBIC)
    arr = np.asarray(t, np.float32) / 255
    al = arr[..., 3:4] * op
    return fr * (1 - al) + arr[..., :3] * al

def shift_img(img, dx, dy):
    dx, dy = int(round(dx)), int(round(dy))
    p = np.pad(img, ((max(dy, 0), max(-dy, 0)), (max(dx, 0), max(-dx, 0)), (0, 0)), mode='edge')
    h, w = img.shape[:2]
    y0 = max(-dy, 0); x0 = max(-dx, 0)
    return p[y0:y0 + h, x0:x0 + w]

# ---------- writer ----------
def write_mp4(path, frame_fn, seed=1):
    rng = np.random.default_rng(seed)
    cmd = ['ffmpeg', '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{W}x{H}', '-r', str(FPS),
           '-i', '-', '-an', '-c:v', 'libx264', '-preset', 'slow', '-crf', '14', '-pix_fmt', 'yuv420p',
           '-colorspace', 'bt709', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-movflags', '+faststart', path]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    for i in range(N):
        fr = frame_fn(i / FPS)
        fr = fr + rng.normal(0, .0035, fr.shape).astype(np.float32)   # dither against banding
        p.stdin.write((np.clip(fr, 0, 1) * 255 + .5).astype(np.uint8).tobytes())
    p.stdin.close(); p.wait()
    return p.returncode
