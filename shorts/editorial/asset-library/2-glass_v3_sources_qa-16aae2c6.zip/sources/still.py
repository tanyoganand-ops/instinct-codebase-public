import sys, time
from scenes import *
name, th = sys.argv[1], sys.argv[2]; ts = [float(x) for x in sys.argv[3:]]
f = SCENES[name](th)
for t in ts:
    t0 = time.time(); fr = f(t)
    Image.fromarray((np.clip(fr, 0, 1) * 255).astype(np.uint8)).save(f'/tmp/st_{name}_{th}_{t}.png'); print(name, th, t, round(time.time() - t0, 2), 's')
