from PIL import Image,ImageDraw,ImageFilter,ImageFont
from pathlib import Path
import numpy as np,json
p=Path('/downloads/library-glass-v1');specs=[]
for shape,W,H,r in [('card',1000,740,66),('panel',1400,720,58),('chip',900,330,105)]:
 for tint,col in [('neutral',(246,249,251)),('blue',(172,204,238)),('peach',(246,204,178))]:
  m=64;bbox=(m,m,W-m,H-m);mask=Image.new('L',(W,H));d=ImageDraw.Draw(mask);d.rounded_rectangle(bbox,radius=r,fill=255)
  y,x=np.mgrid[:H,:W];a=np.array(mask)/255
  # Translucent body, strongest highlights near upper-left; no opaque centre.
  light=np.exp(-(((x-W*.24)/(W*.5))**2+((y-H*.1)/(H*.7))**2));alpha=(40+24*light)*a
  rgba=np.zeros((H,W,4),dtype=np.uint8);rgba[:,:,:3]=col;rgba[:,:,3]=alpha.astype('uint8');im=Image.fromarray(rgba)
  rim=Image.new('RGBA',(W,H));rd=ImageDraw.Draw(rim);rd.rounded_rectangle(bbox,radius=r,outline=(255,255,255,135),width=3);rd.rounded_rectangle((m+6,m+6,W-m-6,H-m-6),radius=r-4,outline=(255,255,255,42),width=2)
  # Restrained soft reflection across the top edge.
  glow=Image.new('RGBA',(W,H));gd=ImageDraw.Draw(glow);gd.line((m+r,m+3,W-m-r,m+3),fill=(255,255,255,175),width=5);glow=glow.filter(ImageFilter.GaussianBlur(4));im=Image.alpha_composite(im,glow);im=Image.alpha_composite(im,rim)
  name=f'{shape}-{tint}';im.save(p/f'{name}-skin.png');mask.save(p/f'{name}-mask.png')
  sh=Image.new('RGBA',(W,H));ss=mask.filter(ImageFilter.GaussianBlur(18));aa=np.array(ss)*.17;sh.putalpha(Image.fromarray(aa.astype('uint8')));sh.save(p/f'{name}-shadow.png')
  specs.append({'name':name,'size':[W,H],'inset':m,'radius':r,'body_alpha':'40-64/255','rim_alpha':135,'blur_px':24,'tint':col})
(p/'params.json').write_text(json.dumps(specs,indent=2))
# True background-aware frost demo: blur the real background underneath the mask.
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',21)
def background(W,H,dark=False):
 im=Image.new('RGBA',(W,H),'#1d2d3f' if dark else '#f4f4f2');d=ImageDraw.Draw(im)
 for y in range(30,H,70):d.line((0,y,W,y),fill='#4a5b70' if dark else '#d9e0e9',width=4)
 d.ellipse((W*.02,H*.2,W*.6,H*.8),fill='#7faddb');d.ellipse((W*.6,-80,W+50,H*.6),fill='#ebb38f');return im
board=Image.new('RGB',(1800,1350),'#f4f4f2');d=ImageDraw.Draw(board)
checks=Image.new('RGB',(1800,1350))
for i,s in enumerate(specs):
 x=i%3*600;y=i//3*450;skin=Image.open(p/(s['name']+'-skin.png')).convert('RGBA');skin.thumbnail((550,340))
 for yy in range(y,y+370,20):
  for xx in range(x,x+580,20):d.rectangle((xx,yy,xx+19,yy+19),fill='#d6dbe2' if ((xx-x)//20+(yy-y)//20)%2 else '#ffffff')
 board.paste(skin,(x+20,y+15),skin);d.text((x+16,y+392),s['name'],font=font,fill='#1d2d3f')
 # each item on pale + dark half miniature stage with real backdrop blur
 cell=Image.new('RGBA',(600,450));cd=ImageDraw.Draw(cell)
 for side in range(2):
  bg=background(300,400,bool(side));ss=Image.open(p/(s['name']+'-skin.png')).convert('RGBA');ss.thumbnail((280,280));mm=Image.open(p/(s['name']+'-mask.png')).resize(ss.size);ox=(300-ss.width)//2;oy=(400-ss.height)//2
  bg.paste(bg.filter(ImageFilter.GaussianBlur(9)).crop((ox,oy,ox+ss.width,oy+ss.height)),(ox,oy),mm);bg.alpha_composite(ss,(ox,oy));cell.alpha_composite(bg,(side*300,0))
 cd.rectangle((0,400,600,450),fill='#f4f4f2');cd.text((12,411),s['name']+' / pale + dark',font=font,fill='#1d2d3f');checks.paste(cell.convert('RGB'),(x,y))
board.save(p/'alpha-contact-sheet.png');checks.save(p/'pale-dark-frost-check.png')
