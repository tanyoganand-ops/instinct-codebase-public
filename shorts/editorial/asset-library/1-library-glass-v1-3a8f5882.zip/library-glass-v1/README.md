# Glassmorphism reusable library v1
4 October 2026. Nine blank components: card, wide panel and pill chip, each neutral/blue/peach. Each has three separate layers: RGBA skin, grayscale shape mask and RGBA soft shadow. No typography, branding or baked scene content.

Palette: neutral #f6f9fb, blue #acccEE, peach #f6ccb2; QA ground #f4f4f2 and navy #1d2d3f. Text should be placed independently in navy on pale or near-white on dark and contrast-checked at final scale.
Parameters: 64px outer inset; card 1000x740/r66, panel 1400x720/r58, chip 900x330/r105. Body alpha 40-64/255, outer white rim alpha135/255 at3px, inner rim42/255 at2px, top reflection blurred4px. Shadow separate, blur18px, peak opacity17%. params.json and generate.py included. Filenames end skin.png, mask.png or shadow.png.

IMPORTANT: a transparent PNG cannot blur arbitrary pixels behind itself. The skin is translucent tint/highlight only. For real frost, blur a duplicate of the live background and clip it with the supplied mask, then place skin above that blurred region. Recommended backdrop blur24px at full resolution; adjust proportionally when scaling. Place text/icons above both. Do not flatten the QA backdrop into the production asset.

CSS equivalent: border-radius from params, background rgba(246,249,251,.20), backdrop-filter blur(24px), border 3px solid rgba(255,255,255,.53); tint variants use the corresponding RGB. Supplied PNG skins support non-CSS compositors. Masks are intentionally grayscale, not claimed RGBA artwork.

Visual QA: inspected all nine skins over checkerboard and all nine real mask-clipped backdrop-blur composites over pale and navy. Background lines/circles stay sharp outside and soften inside the component; subtle rims remain visible. No checkerboard or scene baked into skins. Body remains partially transparent, outer pixels zero alpha. This is a reusable style kit, not a final video frame. Avoid putting many glass carriers on every beat; use deliberate accents.
