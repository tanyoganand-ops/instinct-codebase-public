from PIL import Image,ImageDraw,ImageFilter,ImageFont
from pathlib import Path
import numpy as np,json,math
p=Path(__file__).resolve().parent;specs=[];metrics=[]
for shape,W,H,r in [('card',1000,740,66),('panel',1400,720,58),('chip',900,330,105)]:
 for mode,col in [('pale',(224,235,247)),('dark',(37,62,89))]:
  for state in ['default','hover','pressed','loading']:
   m=64;b=(m,m,W-m,H-m);mask=Image.new('L',(W,H));ImageDraw.Draw(mask).rounded_rectangle(b,radius=r,fill=255)
   y,x=np.mgrid[:H,:W];light=np.exp(-(((x-W*.24)/(W*.5))**2+((y-H*.1)/(H*.7))**2));base=(45 if mode=='pale' else 75)+({'default':0,'hover':16,'pressed':28,'loading':4}[state]);alpha=(base+20*light)*np.array(mask)/255
   a=np.zeros((H,W,4),dtype=np.uint8);a[:,:,:3]=col;a[:,:,3]=alpha.astype('uint8');im=Image.fromarray(a)
   rim=Image.new('RGBA',(W,H));rd=ImageDraw.Draw(rim);rd.rounded_rectangle(b,radius=r,outline=(255,255,255,170 if state=='hover' else 110),width=3);rd.line((m+r,m+3,W-m-r,m+3),fill=(255,255,255,175),width=3);im=Image.alpha_composite(im,rim)
   name=f'{shape}-{mode}-{state}';im.save(p/f'{name}-skin.png');mask.save(p/f'{name}-mask.png');sh=Image.new('RGBA',(W,H),(8,17,27,0));sm=mask.filter(ImageFilter.GaussianBlur(18));sh.putalpha(Image.fromarray((np.array(sm)*(.11 if state=='pressed' else .21 if state=='hover' else .17)).astype('uint8')));sh.save(p/f'{name}-shadow.png')
   aa=np.array(im)[:,:,3];metrics.append({'name':name,'corner_alpha':int(aa[0,0]),'centre_alpha':int(aa[H//2,W//2]),'partial_alpha_pixels':int(((aa>0)&(aa<255)).sum())});specs.append({'name':name,'size':[W,H],'inset':m,'radius':r,'blur_px':24 if mode=='dark' else 22,'recommended_scale':.98 if state=='pressed' else 1.015 if state=='hover' else 1})
# Independent spinner animation: actual transparent PNG sequence, one-second loop.
for mode,col in [('pale',(35,52,73,255)),('dark',(243,212,190,255))]:
 q=p/f'spinner-{mode}';q.mkdir(exist_ok=True)
 for n in range(30):
  im=Image.new('RGBA',(128,128));ImageDraw.Draw(im).arc((25,25,103,103),start=n*12,end=n*12+250,fill=col,width=7);im.save(q/f'{n:03}.png')
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
board=Image.new('RGB',(1600,1440),'white');check=Image.new('RGB',(1600,1440),'white')
for i,s in enumerate(specs):
 x=i%4*400;y=i//4*240;d=ImageDraw.Draw(board)
 for yy in range(y,y+200,20):
  for xx in range(x,x+400,20):d.rectangle((xx,yy,xx+19,yy+19),fill='#d6dbe2' if ((xx-x)//20+(yy-y)//20)%2 else 'white')
 skin=Image.open(p/f"{s['name']}-skin.png");skin.thumbnail((380,190));board.paste(skin,(x+(400-skin.width)//2,y+(200-skin.height)//2),skin);d.text((x+10,y+207),s['name'],font=font,fill='#233449')
 cell=Image.new('RGBA',(400,240));
 for side in range(2):
  bg=Image.new('RGBA',(200,200),'#172638' if side else '#f4f4f2');bd=ImageDraw.Draw(bg)
  for yy in range(0,200,30):bd.line((0,yy,200,yy),fill='#547daa',width=3)
  bd.ellipse((20,45,135,160),fill='#a2c3e6');bd.ellipse((115,90,230,200),fill='#f1c3a6');ss=Image.open(p/f"{s['name']}-skin.png");ss.thumbnail((190,170));mm=Image.open(p/f"{s['name']}-mask.png").resize(ss.size);ox=(200-ss.width)//2;oy=(200-ss.height)//2;bg.paste(bg.filter(ImageFilter.GaussianBlur(5)).crop((ox,oy,ox+ss.width,oy+ss.height)),(ox,oy),mm);bg.alpha_composite(ss,(ox,oy));cell.alpha_composite(bg,(side*200,0))
 cd=ImageDraw.Draw(cell);cd.rectangle((0,200,400,240),fill='white');cd.text((10,207),s['name'],font=font,fill='#233449');check.paste(cell.convert('RGB'),(x,y))
board.save(p/'alpha-contact-sheet.png');check.save(p/'pale-dark-frost-check.png');(p/'params.json').write_text(json.dumps(specs,indent=2));(p/'alpha-metrics.json').write_text(json.dumps(metrics,indent=2))
assert all(m['corner_alpha']==0 and 0<m['centre_alpha']<255 and m['partial_alpha_pixels']>0 for m in metrics)
print('24 RGBA skins with masks/shadows and 60 spinner frames; alpha checks passed')
