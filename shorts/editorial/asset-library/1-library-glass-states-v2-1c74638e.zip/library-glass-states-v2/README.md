# Glass states v2

24 reusable blank components: card/panel/chip, pale/navy frost, default/hover/pressed/loading. Each has an RGBA skin, grayscale mask and RGBA shadow. Shared dimensions keep state swaps aligned. Hover tint is brighter; pressed tint denser. Recommended transform scales are 1.015 hover and 0.98 pressed; ease over 150-250ms around the centre. Loading skins retain the same layout and support an independent spinner.

spinner-pale and spinner-dark each contain 30 transparent 128px PNG frames, 30fps, one-second seamless rotation. Use these independently; no text is baked into skins. Tint palette: pale #e0ebf7, dark #253e59, pale spinner #233449, dark spinner #f3d4be.

Frost requires live background blur under the mask, then the skin and optional shadow. PNG skins cannot blur an unknown scene. Suggested blur: 22px pale, 24px dark at native resolution; scale blur with component size. Match mask/skin placement exactly. Shadows have the same canvas; offset them downward in your compositor. These are raster components, not interactive UI or vector meshes.

Generate with Pillow/NumPy: python3 generate.py. DejaVu Linux font path is used only for QA labels. params.json lists dimensions/radii/scale advice; alpha-metrics.json records checked corner and centre alpha. QA sheets show every state on checkerboard and with true blurred pale/dark backgrounds. No repository commits.
