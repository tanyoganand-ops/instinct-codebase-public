# Everyday clay props v1
Prepared 4 October 2026. Six independent RGBA illustration sprites, each 1254x1254. New everyday tech/study/money objects, not brand/product depictions or benchmark evidence.

## Inventory
- clay-headphones.png: study/audio/meetings.
- clay-desk-lamp.png: focus/evening study/workspace.
- clay-notebook-pencil.png: planning/study/notes.
- clay-wallet.png: money/budget/payment concepts; blank cards, no sensitive details.
- clay-savings-jar.png: savings/budget; opaque jar, plain coin disks with no denomination.
- clay-usb-drive.png: transfer/storage/backups; detached cap included within grouped sprite.

## Palette and generation parameters
Target palette: pale cream #f4f4f2, muted clay blue around #9cbcec, peach around #f0b79b; generated texture/light shifts mean exact pixels vary, do not use prop pixels as brand colour tokens. Soft upper-left directional light, matte tactile surface, elevated front three-quarter view, 15% breathing-room request. No typography, brand logos, humans or painted checkerboard. All have self-shading but no baked floor plane/shadow. Add compositor ground shadows independently when needed. QA backdrops #f4f4f2 and #1d2d3f.

## Alpha and visual QA
alpha-metrics.json records zero-alpha pixels, partial alpha and dimensions for all six. All sprites have real transparent backgrounds and partial-alpha edges. Inspected labelled checkerboard sheet and actual pale/navy composites: clean silhouettes, no opaque backgrounds, no crop or anatomy/construction issue, visible notebook pages, coherent earcups/headband and lamp support, plausible wallet folds and USB connector. No financial data or actual product UI.

## Use limits
Raster illustrations, not 3D meshes. Each grouped sprite moves as one asset; cap/pencil/cards/coins are not internally layered. No free 3D rotation. Slight bob/sway/scale is supported by transparent margins. Shadows and text remain separate in the video compositor. Wallet/cards and plain coins are conceptual, never factual payment evidence. Do not imply these are actual user-owned items.
