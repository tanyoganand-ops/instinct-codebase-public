# 17. Pets Animals

Six theme objects in four treatments: matte clay pale/dark and frosted-glass panel pale/dark.

## Files

| Object | Clay pale | Clay dark | Glass pale | Glass dark |
|---|---|---|---|---|
| puppy | `clay-puppy-pale.png` | `clay-puppy-dark.png` | `glass-puppy-pale.png` | `glass-puppy-dark.png` |
| kitten | `clay-kitten-pale.png` | `clay-kitten-dark.png` | `glass-kitten-pale.png` | `glass-kitten-dark.png` |
| paw-medallion | `clay-paw-medallion-pale.png` | `clay-paw-medallion-dark.png` | `glass-paw-medallion-pale.png` | `glass-paw-medallion-dark.png` |
| food-bowl | `clay-food-bowl-pale.png` | `clay-food-bowl-dark.png` | `glass-food-bowl-pale.png` | `glass-food-bowl-dark.png` |
| bone-toy | `clay-bone-toy-pale.png` | `clay-bone-toy-dark.png` | `glass-bone-toy-pale.png` | `glass-bone-toy-dark.png` |
| pet-carrier | `clay-pet-carrier-pale.png` | `clay-pet-carrier-dark.png` | `glass-pet-carrier-pale.png` | `glass-pet-carrier-dark.png` |

## Technical notes

- Clay assets: 1024 x 1024 RGBA PNG. Glass assets: 1408 x 1024 RGBA PNG.
- Real alpha transparency, transparent corner pixels, antialiased outlines and soft offset shadows. Contact-sheet checkerboard is not embedded in assets.
- Pale uses the supplied ivory / powder-blue / coral-peach matte palette. Dark is a cooler, slightly deeper treatment of the same geometry, not a black background.
- Glass panels are translucent gradient overlays with fine rim highlights. A PNG cannot dynamically blur whatever is behind it. For live glassmorphism apply backdrop blur in the destination UI; these PNGs supply the tint, rim, shadow and clay motif.
- Resolution caveat: image source sheets returned at 1536 x 1024, six objects per sheet. Individual clay objects are extracted and Lanczos-upscaled into the 1024 canvas, not native 1024 renders. Panel geometry is native output resolution.
- All six motifs are decorative, not medical advice, product branding or application interface controls.
- Generated to match the supplied visual references, then cleaned and composited. No third-party icon downloads.

## QA

See `alpha-contact-sheet.png` for all 24 variants over checkerboard. See `pale-dark-proof.png` for every asset over alternating pale and dark backgrounds. `manifest.json` records dimensions and source-object pixel size.
