# 18. Shopping Commerce

Six theme objects in four treatments: matte clay pale/dark and frosted-glass panel pale/dark.

## Files

| Object | Clay pale | Clay dark | Glass pale | Glass dark |
|---|---|---|---|---|
| shopping-bag | `clay-shopping-bag-pale.png` | `clay-shopping-bag-dark.png` | `glass-shopping-bag-pale.png` | `glass-shopping-bag-dark.png` |
| shopping-cart | `clay-shopping-cart-pale.png` | `clay-shopping-cart-dark.png` | `glass-shopping-cart-pale.png` | `glass-shopping-cart-dark.png` |
| price-tag | `clay-price-tag-pale.png` | `clay-price-tag-dark.png` | `glass-price-tag-pale.png` | `glass-price-tag-dark.png` |
| delivery-parcel | `clay-delivery-parcel-pale.png` | `clay-delivery-parcel-dark.png` | `glass-delivery-parcel-pale.png` | `glass-delivery-parcel-dark.png` |
| payment-card | `clay-payment-card-pale.png` | `clay-payment-card-dark.png` | `glass-payment-card-pale.png` | `glass-payment-card-dark.png` |
| storefront | `clay-storefront-pale.png` | `clay-storefront-dark.png` | `glass-storefront-pale.png` | `glass-storefront-dark.png` |

## Technical notes

- Clay assets: 1024 x 1024 RGBA PNG. Glass assets: 1408 x 1024 RGBA PNG.
- Real alpha transparency, transparent corner pixels, antialiased outlines and soft offset shadows. Contact-sheet checkerboard is not embedded in assets.
- Pale uses the supplied ivory / powder-blue / coral-peach matte palette. Dark is a cooler, slightly deeper treatment of the same geometry, not a black background.
- Glass panels are translucent gradient overlays with fine rim highlights. A PNG cannot dynamically blur whatever is behind it. For live glassmorphism apply backdrop blur in the destination UI; these PNGs supply the tint, rim, shadow and clay motif.
- Resolution caveat: image source sheets returned at 1536 x 1024, six objects per sheet. Individual clay objects are extracted and Lanczos-upscaled into the 1024 canvas, not native 1024 renders. Panel geometry is native output resolution.
- All six motifs are decorative, not medical advice, product branding or application interface controls.
- Generated to match the supplied visual references, then cleaned and composited. No third-party icon downloads.

## QA

See `alpha-contact-sheet.png` for all 24 variants over checkerboard. See `pale-dark-proof.png` for every asset over alternating pale and dark backgrounds. `manifest.json` records dimensions and source-object pixel size.
