Kinetic-type kit, 720x1280 @30fps. MP4 = gradient bg. *_alpha.webm = type only, VP9 alpha (decode with libvpx-vp9).
Re-render: python3 source/kt.py <word_punch|line_swap|counter_roll|letter_scatter> --text "A|B|C" --out out
Needs numpy, scipy, Pillow, ffmpeg. Font: Anton.
