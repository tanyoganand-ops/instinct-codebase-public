# 16. Health Medical

Six theme objects in four treatments: matte clay pale/dark and frosted-glass panel pale/dark.

## Files

| Object | Clay pale | Clay dark | Glass pale | Glass dark |
|---|---|---|---|---|
| first-aid-kit | `clay-first-aid-kit-pale.png` | `clay-first-aid-kit-dark.png` | `glass-first-aid-kit-pale.png` | `glass-first-aid-kit-dark.png` |
| stethoscope | `clay-stethoscope-pale.png` | `clay-stethoscope-dark.png` | `glass-stethoscope-pale.png` | `glass-stethoscope-dark.png` |
| capsules | `clay-capsules-pale.png` | `clay-capsules-dark.png` | `glass-capsules-pale.png` | `glass-capsules-dark.png` |
| heartbeat-heart | `clay-heartbeat-heart-pale.png` | `clay-heartbeat-heart-dark.png` | `glass-heartbeat-heart-pale.png` | `glass-heartbeat-heart-dark.png` |
| thermometer | `clay-thermometer-pale.png` | `clay-thermometer-dark.png` | `glass-thermometer-pale.png` | `glass-thermometer-dark.png` |
| medicine-bottle | `clay-medicine-bottle-pale.png` | `clay-medicine-bottle-dark.png` | `glass-medicine-bottle-pale.png` | `glass-medicine-bottle-dark.png` |

## Technical notes

- Clay assets: 1024 x 1024 RGBA PNG. Glass assets: 1408 x 1024 RGBA PNG.
- Real alpha transparency, transparent corner pixels, antialiased outlines and soft offset shadows. Contact-sheet checkerboard is not embedded in assets.
- Pale uses the supplied ivory / powder-blue / coral-peach matte palette. Dark is a cooler, slightly deeper treatment of the same geometry, not a black background.
- Glass panels are translucent gradient overlays with fine rim highlights. A PNG cannot dynamically blur whatever is behind it. For live glassmorphism apply backdrop blur in the destination UI; these PNGs supply the tint, rim, shadow and clay motif.
- Resolution caveat: image source sheets returned at 1536 x 1024, six objects per sheet. Individual clay objects are extracted and Lanczos-upscaled into the 1024 canvas, not native 1024 renders. Panel geometry is native output resolution.
- All six motifs are decorative, not medical advice, product branding or application interface controls.
- Generated to match the supplied visual references, then cleaned and composited. No third-party icon downloads.

## QA

See `alpha-contact-sheet.png` for all 24 variants over checkerboard. See `pale-dark-proof.png` for every asset over alternating pale and dark backgrounds. `manifest.json` records dimensions and source-object pixel size.
