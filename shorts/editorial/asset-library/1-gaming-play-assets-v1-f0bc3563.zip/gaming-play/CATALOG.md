# Gaming Play

Six tactile clay subjects, each in pale and dark material variants. All asset files are true RGBA PNGs, 1254 x 1254 pixels. Blue, peach and cream palette matched to the supplied clay reference; upper-left lighting and subtle alpha shadows.

## Assets

| Subject | Pale file | Dark file | Detail provenance |
|---|---|---|---|
| controller | `gaming-play-controller-pale.png` | `gaming-play-controller-dark.png` | native individual render |
| handheld-console | `gaming-play-handheld-console-pale.png` | `gaming-play-handheld-console-dark.png` | native individual render |
| arcade-cabinet | `gaming-play-arcade-cabinet-pale.png` | `gaming-play-arcade-cabinet-dark.png` | native individual render |
| dice | `gaming-play-dice-pale.png` | `gaming-play-dice-dark.png` | native individual render |
| trophy | `gaming-play-trophy-pale.png` | `gaming-play-trophy-dark.png` | upsampled from 512px source cell |
| chess-pieces | `gaming-play-chess-pieces-pale.png` | `gaming-play-chess-pieces-dark.png` | upsampled from 512px source cell |

## Use

Import an individual PNG into your slide, editor or animation timeline. The pale and dark names describe object materials, not a baked-in backdrop. Keep aspect ratio locked. Both work over light and dark backgrounds. Shadows are included in alpha. These are generated illustrative objects, not product photography or branded assets.

`alpha-contact-sheet.png` is an actual transparent sheet. The separate external preview uses a checkerboard to make the alpha easy to inspect. `pale-dark-background-check.png` previews both materials on both backgrounds.

## Resolution caveat

Native individual renders have 1254px detail. Assets labelled upsampled were extracted from a 512px-wide sheet cell, keyed, decontaminated and resized to 1254px. They meet the canvas-size requirement but do not have native 1024px object detail. Individual regeneration was stopped by the daily image quota. Do not present upsampled files as native high-resolution renders.

## Construction

Pale material preserves the source render. Dark uses a locally graded navy blue and richer muted terracotta with warmer cream, preserved shading and preserved alpha. No fake frosted blur is included: these packs follow the clay style, not backdrop-dependent glass.

## Alpha check

Visually inspected contact sheets, pale/dark-background composites and magnified edge crops. Magenta key spill was removed and edge colours pulled from the opaque object interior. Grid-derived assets are visibly softer when magnified and remain candidates for native rerender.
