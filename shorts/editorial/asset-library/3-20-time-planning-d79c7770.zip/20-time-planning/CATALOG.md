# 20. Time Planning

Six theme objects in four treatments: matte clay pale/dark and frosted-glass panel pale/dark.

## Files

| Object | Clay pale | Clay dark | Glass pale | Glass dark |
|---|---|---|---|---|
| alarm-clock | `clay-alarm-clock-pale.png` | `clay-alarm-clock-dark.png` | `glass-alarm-clock-pale.png` | `glass-alarm-clock-dark.png` |
| desk-calendar | `clay-desk-calendar-pale.png` | `clay-desk-calendar-dark.png` | `glass-desk-calendar-pale.png` | `glass-desk-calendar-dark.png` |
| hourglass | `clay-hourglass-pale.png` | `clay-hourglass-dark.png` | `glass-hourglass-pale.png` | `glass-hourglass-dark.png` |
| checklist | `clay-checklist-pale.png` | `clay-checklist-dark.png` | `glass-checklist-pale.png` | `glass-checklist-dark.png` |
| stopwatch | `clay-stopwatch-pale.png` | `clay-stopwatch-dark.png` | `glass-stopwatch-pale.png` | `glass-stopwatch-dark.png` |
| planner | `clay-planner-pale.png` | `clay-planner-dark.png` | `glass-planner-pale.png` | `glass-planner-dark.png` |

## Technical notes

- Clay assets: 1024 x 1024 RGBA PNG. Glass assets: 1408 x 1024 RGBA PNG.
- Real alpha transparency, transparent corner pixels, antialiased outlines and soft offset shadows. Contact-sheet checkerboard is not embedded in assets.
- Pale uses the supplied ivory / powder-blue / coral-peach matte palette. Dark is a cooler, slightly deeper treatment of the same geometry, not a black background.
- Glass panels are translucent gradient overlays with fine rim highlights. A PNG cannot dynamically blur whatever is behind it. For live glassmorphism apply backdrop blur in the destination UI; these PNGs supply the tint, rim, shadow and clay motif.
- Resolution caveat: image source sheets returned at 1536 x 1024, six objects per sheet. Individual clay objects are extracted and Lanczos-upscaled into the 1024 canvas, not native 1024 renders. Panel geometry is native output resolution.
- All six motifs are decorative, not medical advice, product branding or application interface controls.
- Generated to match the supplied visual references, then cleaned and composited. No third-party icon downloads.

## QA

See `alpha-contact-sheet.png` for all 24 variants over checkerboard. See `pale-dark-proof.png` for every asset over alternating pale and dark backgrounds. `manifest.json` records dimensions and source-object pixel size.
