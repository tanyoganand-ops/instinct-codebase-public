"""Kinetic-type mini-library. 720x1280 @30fps. Liquid-glass type on a moving light gradient.
Usage: python kt.py <clip> [--text "A|B|C"] [--out DIR]   clips: word_punch line_swap counter_roll letter_scatter
Outputs: <clip>.mp4 (with gradient bg) and <clip>_alpha.webm (type only, VP9 alpha)."""
import sys, os, math, subprocess, argparse, hashlib
import numpy as np
from PIL import Image, ImageFont, ImageDraw
from scipy.ndimage import gaussian_filter, shift as ndshift
from multiprocessing import Pool

W, H, FPS = 720, 1280, 30
FONT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Anton-Regular.ttf")

# ---------- easing ----------
def clamp(x, a=0., b=1.): return max(a, min(b, x))
def out_back(t, s=1.2):
    t = clamp(t) - 1; return 1 + (s + 1) * t**3 + s * t**2
def out_expo(t): t = clamp(t); return 1 if t >= 1 else 1 - 2 ** (-10 * t)
def out_quart(t): t = clamp(t); return 1 - (1 - t) ** 4
def in_out_cubic(t):
    t = clamp(t); return 4*t**3 if t < .5 else 1 - (-2*t + 2)**3 / 2
def in_cubic(t): return clamp(t) ** 3
def seg(t, t0, d): return clamp((t - t0) / d)

# ---------- background (loops over clip length) ----------
BLOBS = [((255, 205, 185), .25, .22, .30, 1.0), ((185, 215, 255), .78, .30, .34, -1.0),
         ((222, 200, 255), .30, .70, .32, 1.0), ((190, 245, 222), .75, .80, .30, -1.0),
         ((255, 228, 190), .55, .50, .22, 2.0)]
BASE = np.array([250, 249, 253], np.float32)
_yy, _xx = np.mgrid[0:128, 0:72]
def background(f, n):
    ph = 2 * math.pi * f / n
    acc = np.zeros((128, 72, 3), np.float32); wsum = np.zeros((128, 72), np.float32)
    for i, (col, bx, by, r, sp) in enumerate(BLOBS):
        cx = (bx + .18 * math.cos(ph * sp + i * 1.3)) * 72
        cy = (by + .12 * math.sin(ph * sp + i * 2.1)) * 128
        d2 = ((_xx - cx) ** 2 + (_yy - cy) ** 2) / (r * 128) ** 2
        w = np.exp(-d2 * 2.2)
        acc += w[..., None] * (np.array(col, np.float32) - BASE); wsum += w
    img = np.clip(BASE + acc * 0.85 / np.maximum(1, wsum.max() * .8), 0, 255)
    im = Image.fromarray(img.astype(np.uint8)).resize((W, H), Image.BICUBIC)
    rng = np.random.default_rng(f)
    return np.clip(np.asarray(im, np.float32) + rng.uniform(-1.2, 1.2, (H, W, 1)), 0, 255)

# ---------- glyph tiles + canvas ----------
_fc = {}
def font(size):
    if size not in _fc: _fc[size] = ImageFont.truetype(FONT, size)
    return _fc[size]
def capH(size): b = font(size).getbbox("H"); return b[3] - b[1]

_tc = {}
def tile(txt, size, track=0):
    k = (txt, size, track)
    if k in _tc: return _tc[k]
    f = font(size); ch = capH(size)
    adv = [f.getlength(c) + track for c in txt]; w = int(sum(adv) - track) + 2 * 30
    h = int(size * 1.7)
    im = Image.new("L", (w, h), 0); d = ImageDraw.Draw(im); x = 30
    for c, a in zip(txt, adv):
        d.text((x, h / 2 + ch / 2), c, font=f, fill=255, anchor="ls"); x += a
    _tc[k] = (im, ch); return _tc[k]
def text_w(txt, size, track=0): return font(size).getlength(txt) + track * (len(txt) - 1)

def put(canvas, im, cx, cy, sx=1., sy=None, rot=0., a=1., clip=None):
    """Composite tile `im` (PIL L) centred at (cx,cy) with scale/rotation, subpixel. clip=(y0,y1) rows."""
    if a <= 0.003 or sx <= 0.001: return
    sy = sx if sy is None else sy
    w, h = im.size; R = int(math.ceil(.5 * math.hypot(w * sx, h * sy))) + 2
    ox, oy = int(math.floor(cx)) - R, int(math.floor(cy)) - R
    c, s = math.cos(math.radians(rot)), math.sin(math.radians(rot))
    # inverse: in = Rot(-rot) * diag(1/sx,1/sy) * (out - ctr) + (w/2,h/2)
    ux, uy = cx - ox, cy - oy
    a11, a12 = c / sx, s / sx; a21, a22 = -s / sy, c / sy
    tr = im.transform((2 * R, 2 * R), Image.AFFINE,
        (a11, a12, w / 2 - a11 * ux - a12 * uy, a21, a22, h / 2 - a21 * ux - a22 * uy), Image.BICUBIC)
    arr = np.asarray(tr, np.float32) / 255 * a
    y0, y1, x0, x1 = oy, oy + 2 * R, ox, ox + 2 * R
    cy0, cy1 = max(0, y0), min(H, y1)
    if clip: cy0, cy1 = max(cy0, int(clip[0])), min(cy1, int(clip[1]))
    cx0, cx1 = max(0, x0), min(W, x1)
    if cy1 <= cy0 or cx1 <= cx0: return
    sub = arr[cy0 - y0:cy1 - y0, cx0 - x0:cx1 - x0]
    cur = canvas[cy0:cy1, cx0:cx1]
    canvas[cy0:cy1, cx0:cx1] = 1 - (1 - cur) * (1 - sub)

# ---------- liquid-glass styling ----------
INK_T, INK_B = np.array([38, 44, 92], np.float32), np.array([88, 104, 214], np.float32)
def style(M):
    """mask (HxW 0..1) -> (premultiplied rgb float, alpha float)."""
    ys, xs = np.nonzero(M > .02)
    if len(ys) == 0: return np.zeros((H, W, 3), np.float32), np.zeros((H, W), np.float32)
    # soft shadow, offset down
    sh = ndshift(gaussian_filter(M, 16), (18, 0), order=1) * .30
    sh2 = ndshift(gaussian_filter(M, 5), (6, 0), order=1) * .22
    sa = 1 - (1 - sh) * (1 - sh2); sc = np.array([70, 80, 170], np.float32)
    # glass body
    ba = np.clip(M, 0, 1) * .90
    gy = np.clip((np.arange(H)[:, None] - ys.min()) / max(1, ys.max() - ys.min()), 0, 1)
    body = INK_T * (1 - gy[..., None]) + INK_B * gy[..., None]
    blur4 = gaussian_filter(M, 5)
    inner = np.clip(M - blur4, 0, 1)                       # inside edge band
    tl = np.clip(M - ndshift(M, (4, 3), order=1), 0, 1)    # lit top-left rim
    br = np.clip(M - ndshift(M, (-4, -3), order=1), 0, 1)  # bounce light bottom-right
    spec = np.clip(gaussian_filter(M, 2.5) - ndshift(gaussian_filter(M, 2.5), (9, 0), order=1), 0, 1)
    col = body + inner[..., None] * np.array([70, 90, 140], np.float32) * .8
    col = col + br[..., None] * np.array([120, 200, 235], np.float32) * .9
    col = col + tl[..., None] * np.array([255, 255, 255], np.float32) * 1.0
    col = col + spec[..., None] * 90
    col = np.clip(col, 0, 255)
    ba = np.clip(ba + tl * .25 * M, 0, 1)
    A = ba + sa * (1 - ba)
    prem = col * ba[..., None] + sc * (sa * (1 - ba))[..., None]
    return prem, A

# ---------- scenes: each returns mask (HxW) for time t (seconds) ----------
def fit(txt, maxw, size0, track=0):
    s = size0
    while text_w(txt, s, track) > maxw and s > 20: s -= 4
    return s

def word_punch(t, text, dur):
    words = text.replace("|", " ").split(); M = np.zeros((H, W), np.float32)
    size = min(fit(max(words, key=len), 620, 210), 210); lh = size * 1.12
    y0 = H / 2 - (len(words) - 1) * lh / 2
    exit_a = 1 - in_cubic(seg(t, dur - .45, .35))
    for i, w in enumerate(words):
        t0 = .25 + i * .30; p = seg(t, t0, .42)
        if p <= 0: continue
        sc = .55 + .45 * out_back(p, 1.1)           # soft overshoot
        a = clamp(p * 4) * exit_a
        im, _ = tile(w, size, 2)
        put(M, im, W / 2, y0 + i * lh + (1 - out_expo(p)) * 40 + (1 - exit_a) * -30, sc, a=a)
    return M

def line_swap(t, text, dur):
    lines = [s.strip() for s in text.split("|")]
    bh = 230 * 1.25
    cy = H / 2; M = np.zeros((H, W), np.float32); clip = (cy - bh / 2, cy + bh / 2)
    step = (dur - .5) / len(lines)
    for i, ln in enumerate(lines):
        ts = .3 + i * step; im, _ = tile(ln, fit(ln, 640, 230, 1), 1)
        pin = out_expo(seg(t, ts, .55))
        pout = in_out_cubic(seg(t, ts + step - .1, .45)) if i < len(lines) - 1 else 0
        if pin <= 0 or pout >= 1: continue
        y = cy + (1 - pin) * bh - pout * bh
        put(M, im, W / 2, y, 1., a=1, clip=clip)
    # glass underline that ticks per line
    bar = np.zeros((H, W), np.float32); k = min(len(lines) - 1, max(0, int((t - .3) / step)))
    prog = (k + out_expo(seg(t, .3 + k * step, .6))) / len(lines)
    bw = 520 * clamp((k + 1) / len(lines) * 0 + prog); x0 = (W - 520) / 2
    bar[int(cy + bh / 2 + 36):int(cy + bh / 2 + 52), int(x0):int(x0 + bw)] = 1
    return np.maximum(M, gaussian_filter(bar, .8))

def counter_roll(t, text, dur):
    fields = text.split("|", 1) if text else ["500000", "SUBSCRIBERS"]
    end = int(fields[0].replace(",", "")) if fields[0].replace(",", "").isdigit() else 500000
    label = fields[1] if len(fields) > 1 else "SUBSCRIBERS"
    p = out_quart(seg(t, .35, 2.6))
    value = end * p
    # Keep each update legible: show the live integer rather than clipping separate
    # wheel glyphs. The rising count itself supplies the motion; final pop is subtle.
    shown = f"{int(value):,}"
    size = fit(shown, 630, 190, 0)
    M = np.zeros((H, W), np.float32)
    pop = 1 + .035 * math.sin(math.pi * seg(t, 3.0, .5)) * (1 - seg(t, 3.0, .5)) ** .5
    cy = H / 2 - 40
    number = tile(shown, size)[0]
    put(M, number, W / 2, cy, pop, a=1)
    lab = tile(label.upper(), 64, 10)[0]
    a = out_expo(seg(t, 1.4, .6))
    put(M, lab, W / 2, cy + capH(size) * .85 + 85 + (1 - a) * 24, 1., a=a)
    return M

def letter_scatter(t, text, dur):
    parts = text.split("|"); word = parts[0]; tag = parts[1] if len(parts) > 1 else ""
    size = fit(word, 600, 190, 4); M = np.zeros((H, W), np.float32)
    f = font(size); adv = [f.getlength(c) + 4 for c in word]; tot = sum(adv) - 4
    x = (W - tot) / 2; cy = H / 2
    rng = np.random.default_rng(int(hashlib.md5(word.encode()).hexdigest()[:6], 16))
    n = len(word)
    for i, c in enumerate(word):
        cx = x + f.getlength(c) / 2; x += adv[i]
        if c == " ": continue
        sx0, sy0 = rng.uniform(-420, 420), rng.uniform(-700, 700)
        rot0, sc0 = rng.uniform(-200, 200), rng.uniform(.5, 2.0)
        t0 = .2 + rng.uniform(0, .45); p = seg(t, t0, 1.05)
        e = out_expo(p) if p < 1 else 1; ob = out_back(p, .8)
        sc = sc0 + (1 - ob) * 0 + (1 - ob) * (1 - sc0) if False else sc0 + (1 - sc0) * ob
        im, _ = tile(c, size)
        put(M, im, cx + sx0 * (1 - ob), cy + sy0 * (1 - ob), sc, rot=rot0 * (1 - ob), a=clamp(p * 5))
    # lockup bar + tagline
    bw = 440 * out_expo(seg(t, 1.65, .6)); bar = np.zeros((H, W), np.float32)
    by = int(cy + capH(size) / 2 + 44)
    bar[by:by + 12, int(W / 2 - bw / 2):int(W / 2 + bw / 2)] = 1
    M = np.maximum(M, gaussian_filter(bar, .8))
    if tag:
        tg = tile(tag.upper(), 68, 8)[0]; q = out_expo(seg(t, 1.9, .55))
        put(M, tg, W / 2, by + 80 + (1 - q) * 20, 1., a=q)
    return M

CLIPS = {  # name: (fn, default text, seconds)
    "word_punch": (word_punch, "STOP|SCROLLING|START|BUILDING", 3.6),
    "line_swap": (line_swap, "NOTES IN|ACTIONS OUT|ZERO BUSYWORK", 4.4),
    "counter_roll": (counter_roll, "SUBSCRIBERS", 4.0),
    "letter_scatter": (letter_scatter, "INSTINCT|MAKE IT HAPPEN", 4.0),
}

def render_frame(args):
    name, text, f, n = args
    fn = CLIPS[name][0]; M = np.clip(fn(f / FPS, text, n / FPS), 0, 1)
    prem, A = style(M); bg = background(f, n)
    rgb = bg * (1 - A[..., None]) + prem
    un = np.where(A[..., None] > 1e-3, prem / np.maximum(A[..., None], 1e-3), 0)
    rgba = np.dstack([np.clip(un, 0, 255), A * 255])
    return (np.clip(rgb, 0, 255).astype(np.uint8).tobytes(), rgba.astype(np.uint8).tobytes(),
            [int(v) for v in (np.nonzero(M > .1)[1].min(), np.nonzero(M > .1)[1].max(),
                              np.nonzero(M > .1)[0].min(), np.nonzero(M > .1)[0].max())] if (M > .1).any() else None)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("clip"); ap.add_argument("--text"); ap.add_argument("--out", default="out")
    ap.add_argument("--frames", help="dump qa pngs of these frames, comma list"); a = ap.parse_args()
    fn, dtext, secs = CLIPS[a.clip]; text = a.text or dtext; n = int(round(secs * FPS))
    os.makedirs(a.out, exist_ok=True); qa = os.path.join(a.out, "qa"); os.makedirs(qa, exist_ok=True)
    mp4 = os.path.join(a.out, a.clip + ".mp4"); webm = os.path.join(a.out, a.clip + "_alpha.webm")
    raw = lambda pf: ["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", pf, "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-"]
    p1 = subprocess.Popen(raw("rgb24") + ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "19", "-preset", "ultrafast", "-movflags", "+faststart", mp4], stdin=subprocess.PIPE)
    alpha_raw = os.path.join(a.out, a.clip + "_alpha.rgba")
    alpha_file = open(alpha_raw, "wb")
    qa_set = set(int(x) for x in a.frames.split(",")) if a.frames else set(np.linspace(0, n - 1, 12).astype(int))
    boxes = []
    with Pool(min(2, os.cpu_count())) as pool:
        for i, (rgb, rgba, bb) in enumerate(pool.imap(render_frame, [(a.clip, text, f, n) for f in range(n)], chunksize=2)):
            p1.stdin.write(rgb); alpha_file.write(rgba); boxes.append(bb)
            if i in qa_set: Image.frombytes("RGB", (W, H), rgb).save(os.path.join(qa, f"{a.clip}_{i:03d}.png"))
    p1.stdin.close(); alpha_file.close(); p1.wait()
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", f"{W}x{H}", "-r", str(FPS), "-i", alpha_raw, "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", "20", "-auto-alt-ref", "0", webm], check=True)
    os.remove(alpha_raw)
    valid = [b for b in boxes if b]; 
    print(a.clip, "frames", n, "bbox-extent x[%d,%d] y[%d,%d]" % (min(b[0] for b in valid), max(b[1] for b in valid), min(b[2] for b in valid), max(b[3] for b in valid)))
if __name__ == "__main__": main()
