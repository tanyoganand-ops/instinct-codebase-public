Kinetic-type real-number clip set. Four clips in the same style as the kinetic-type-kit.
All exports 720x1280, 30fps. MP4s are delivered separately. *_alpha.webm: VP9 with alpha (type layer).

Files:
- impressions.mp4 / impressions_alpha.webm: counter to 500,000; IMPRESSIONS.
- linkedin.mp4 / linkedin_alpha.webm: counter to 180,000; LINKEDIN VIEWS.
- youtube.mp4 / youtube_alpha.webm: counter to 270,000; YOUTUBE VIEWS.
- word_punch.mp4 / word_punch_alpha.webm: 500K / IMPRESSIONS / 1K / FOLLOWERS.

Source in source/kt.py, bundled Anton-Regular.ttf. Re-render:
python3 source/kt.py counter_roll --text '500000|IMPRESSIONS' --out out
python3 source/kt.py counter_roll --text '180000|LINKEDIN VIEWS' --out out
python3 source/kt.py counter_roll --text '270000|YOUTUBE VIEWS' --out out
python3 source/kt.py word_punch --text '500K|IMPRESSIONS|1K|FOLLOWERS' --out out
Needs Python 3, numpy, scipy, Pillow, ffmpeg, and libx264/libvpx-vp9. QA frames are sampled rendered frames in qa_frames/; visual contact sheets in sheets/.
Counter roll was adapted to count-up whole-number typography to avoid unreadable clipped digit fragments during per-digit wheel motion. End holds show the exact target. H.264 uses ultrafast preset, CRF 19; format/size/fps verified by ffprobe. WebM alpha is confirmed non-empty and has 0..255 alpha range in decoded frames.
