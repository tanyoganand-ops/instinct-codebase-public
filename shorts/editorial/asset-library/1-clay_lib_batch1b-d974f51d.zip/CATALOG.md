# Clay 3D animation library - catalog (batch 1)

Common spec: RGBA VP9 webm (yuva420p), 1020x765, 24 fps, 72 frames = 3.0 s, seamless loop (frame 71 flows into frame 0). Each clip ships as two layers: `<clip>_card.webm` (the object, premultiplied-correct alpha) and `<clip>_shadow.webm` (black, alpha-only shadow), so the shadow can be recoloured, moved or dropped. Layer shadow under the object. Use VP9-alpha-capable decode (Chrome / libvpx); for ffmpeg compositing decode with `-c:v libvpx-vp9` before `-i`. Renderer: numpy SDF raymarch, source scene.py / lib.py / clips.py. Palette: blue #9cbcec, orange #F2AE80, Claude peach (.97,.78,.66), Gemini pale blue (.74,.84,.98). Camera: z=5.5, fcam 0.145, canvas half-width about 1.06 world units, half-height 0.8. Check images show frames 0, 18, 36, 54 over #9cbcec.

| Clip | Move | Parameters (t = 0..1 across the loop) |
|---|---|---|
| claude_turntable / gemini_turntable | 360 deg turntable spin of the card (logo front only, back is plain clay) | yaw = 2*pi*t (linear), pitch 0.12*sin(2*pi*t), vertical bob 0.03*sin(2*pi*t); shadow softness follows bob |
| cardflip_gemini_claude | Flip reveal, front Gemini / back Claude, flipped twice per loop | 3.0 s timeline: hold 0.7 s, flip 0.8 s (yaw 0 to pi, ease-out-back overshoot 1.2), hold 0.7 s, flip 0.8 s (pi to 2pi). During flip card lifts 0.5 toward camera (sin arc), tilts pitch -0.12, roll 0.06*sin(pi*lift); shadow gets softer and fainter when lifted |
| sphere_donut_bounce | Squash-and-stretch bounce chain: blue and orange spheres at x=-0.5 / +0.5 alternate | each sphere period 1.0 s (3 bounces per loop), second sphere phase offset 0.5; height h=1-(2u-1)^2, apex 0.62 world units; contact squash when within 12% of ground: sy=1-0.34c, sx=1+0.20c; flight stretch +0.12*sqrt(h); ground shadow is an analytic ellipse layer, shrinks and fades 55% with height. Note: despite the name, only spheres appear |
| donut_orbit | Slow camera orbit around a clay donut (orange) | camera azimuth 0 to 2*pi over the loop, elevation 0.45+0.18*sin(2*pi*t) rad, radius 5.5, looking at origin; torus R=0.40 r=0.19; shadow is the default blurred offset silhouette |

## Reuse notes
- Scale freely in the build; sizes assume the object fills about 60-85% of canvas width.
- Easing used: smoothstep for holds, outback for flips (`c=1.2`).
- Known limits: smooth matte clay (no fingerprints), fake offset shadow (not cast on other objects), 648-1360 px render resolution downsampled to 1020x765 (not 1080x1920; for a full-frame 1080x1920 hero place the clip on the canvas and scale up modestly). The turntable back face is blank.

## Batch 1b
| Clip | Move | Parameters |
|---|---|---|
| gemini_turntable | Same as claude_turntable with the Gemini card (pale blue) | identical spin/bob parameters |
| donut_roll | Donut rolls as a wheel across the canvas, enters left and exits right (loop is empty at the seam) | x = -1.75 + 3.5*t world units, scale 0.75 (radius 0.44), roll angle = -x/0.44, ground at y=-0.65; analytic ellipse ground shadow follows x. Known weakness: a torus is symmetric about its own axis so the rolling spin is not visible; reads as a sliding ring. Needs a marker (logo/dot) or tilt wobble to read as rolling |
