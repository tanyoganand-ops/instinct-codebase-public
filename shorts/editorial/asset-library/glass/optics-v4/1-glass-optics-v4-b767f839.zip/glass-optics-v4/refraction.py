"""Background-dependent refraction. Map PNGs encode signed pixels: 32768 neutral, 2048 units/pixel."""
from pathlib import Path
from PIL import Image,ImageFilter
import numpy as np, math
P=Path(__file__).resolve().parent;W,H=720,1280
def apply(background,frame):
 """Return refracted RGB image. Composite shadow and glass PNGs above this."""
 bg=background.convert('RGB').resize((W,H));a=np.asarray(bg,dtype=np.float32);yy,xx=np.mgrid[:H,:W]
 dx=(np.asarray(Image.open(P/f'refraction-x/{frame:03}.png'),dtype=np.float32)-32768)/2048
 dy=(np.asarray(Image.open(P/f'refraction-y/{frame:03}.png'),dtype=np.float32)-32768)/2048
 X=np.clip(xx+dx,0,W-1);Y=np.clip(yy+dy,0,H-1);x0=X.astype(int);y0=Y.astype(int);x1=np.minimum(x0+1,W-1);y1=np.minimum(y0+1,H-1);fx=(X-x0)[...,None];fy=(Y-y0)[...,None]
 out=a[y0,x0]*(1-fx)*(1-fy)+a[y0,x1]*fx*(1-fy)+a[y1,x0]*(1-fx)*fy+a[y1,x1]*fx*fy
 refr=Image.fromarray(out.astype(np.uint8));mask=Image.open(P/f'frost-mask/{frame:03}.png')
 soft=Image.blend(refr,refr.filter(ImageFilter.GaussianBlur(6)),.25);bg.paste(soft,(0,0),mask);return bg
if __name__=='__main__':
 for q in ['refraction-x','refraction-y']:(P/q).mkdir(exist_ok=True)
 yy,xx=np.mgrid[:H,:W].astype(np.float32)
 for n in range(180):
  t=n/30
  def e(v):v=max(0,min(1,v));return v*v*v*(v*(v*6-15)+10)
  en=e(t/1.4);ex=1-e((t-5.2)/.8);sc=.93+.07*en;cx=360+2*math.sin(t*.8);cy=651+55*(1-en)-6*(1-ex);ang=math.radians(-1.4*(1-en)+.65*math.sin((t-.8)*.9)*en)
  dx=xx-cx;dy=yy-cy;u=dx*math.cos(ang)+dy*math.sin(ang);v=-dx*math.sin(ang)+dy*math.cos(ang);u=u/(1+.014*np.sin(t*.8)*v/240);bw=268*sc;bh=226*sc;r=47
  qx=np.abs(u)-(bw-r);qy=np.abs(v)-(bh-r);sd=np.sqrt(np.maximum(qx,0)**2+np.maximum(qy,0)**2)+np.minimum(np.maximum(qx,qy),0)-r
  gy,gx=np.gradient(sd);strength=8*np.exp(-((-sd-8)/11)**2)*(sd<0)*en*ex
  for q,g in [('x',gx),('y',gy)]:Image.fromarray(np.clip(32768+2048*g*strength,0,65535).astype(np.uint16)).save(P/f'refraction-{q}/{n:03}.png')
