# Hero glass optics v4

720x1280, 30fps, six seconds. Flat pale #f4f4f2 only. No clay, typography, chips or backdrop decoration. One glass carrier with slow sub-degree optical-plane tilt, eased lift, travelling specular rim light, multi-band bevel, local surface glint, inner meniscus and subdued underside caustic.

Production layers: glass-rgba and shadow-rgba PNG sequences 000-179, matching grayscale frost-mask sequence. Import at 30fps, straight alpha, normal blend. All are full 720x1280 canvas and contain placement/timing. Preview MP4 is flattened and silent.

Background-dependent optics: refraction-x and refraction-y contain 16-bit signed displacement maps, neutral32768 and 2048 units/pixel. Edge displacement peaks around8px and follows the animated rounded glass normal, not a global scene translation. refraction.py provides a bilinear arbitrary-background compositor, with a restrained blur blended under the matching mask. Composite its output, then shadow, then glass; foreground text/artwork goes above. The map pass is usable on footage without rebuilding the animation. On uniform flat pale there is no detail to refract, so the preview shows reflected/bevel lighting instead. This is a deterministic optical approximation, not a ray-traced physical simulation or Apple's proprietary material.

render.py creates alpha sequences and preview; refraction.py creates displacement maps. Requires Pillow, NumPy, ffmpeg. No audio. No seamless loop. No repo commits.

QA: final encoded sheet and a full-resolution decoded frame inspected for clean edge bands, highlight shape, crop and restrained shadow. All180 frames encode/decode; 720x1280,30fps. PNG alpha tested separately. The accepted plain base is preserved; only glass optics and motion changed.
