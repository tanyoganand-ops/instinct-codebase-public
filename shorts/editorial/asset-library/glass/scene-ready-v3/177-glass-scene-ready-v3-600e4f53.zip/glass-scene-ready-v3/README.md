# Scene-ready glass v3

Two silent six-second previews at 720x1280, 30fps, 180 frames:
- glass-hero-pale-6s.mp4: blank hero glass card on flat house pale #f4f4f2. Smooth entrance, restrained drift, moving edge light, soft exit.
- glass-clay-context-6s.mp4: final composited pale scene using the existing notebook/pencil as the hero, a small USB behind the glass to demonstrate actual frost, and the existing peach glass chip. No QA labels, grids, branding or busy decorative shapes in either video.

## Production assets
card-rgba/000.png through 179.png: full-canvas straight RGBA card animation.
shadow-rgba/000.png through 179.png: independent full-canvas straight RGBA shadow animation, with reduced interior density to avoid a muddy grey plate.
frost-mask/000.png through 179.png: full-canvas grayscale mask animation.
flat-pale-background.png: actual 720x1280 scene background. This is the clean flat background requested, not a photograph.
source-assets/: copies of the existing notebook/pencil, USB and peach chip used by the demo.
render.py: reproducible scene source, using Pillow, NumPy and ffmpeg. Run python3 render.py from any folder; outputs go beside the script.

Import PNG sequences at 30fps with straight/unmatted alpha. They already carry placement and timing on the 720x1280 canvas, so no scaling/offset is needed. Use a normal blend, shadow underneath card. For arbitrary backgrounds, blur a duplicate of the live scene by 15px, mix 14% of a slightly displaced original, clip using the corresponding frost mask, then overlay shadow and card. Foreground artwork/text stays above the glass. Source contains exact layer order and box motion.

Flat pale has no texture to refract; its glass effect is naturally subtle and comes mostly from the rim/shadow. The demo places the USB behind the glass so its live frost is visible. This is a restrained raster approximation of liquid-glass lighting/refraction, not Apple's material shader or a 3D mesh. MP4 previews have no alpha; PNG sequences are the usable transparent assets. No audio or text is baked into the production layers. Entrance/exit are intentional, not a seamless loop.

## QA
Both final MP4s fully decoded to sampled frames; metadata: 720x1280, 30/1 fps, 180 frames, 6.000 seconds. Encoded QA sheets checked at entrance, settled state, motion and exit for edge cleanliness, crop and uncluttered layout. Alpha-layer QA inspected on checkerboard. Recorded centre alpha at settled frame 90: 22/255, corner 0. Start/end card and shadow are transparent. Alpha metrics included. No repository commits.
