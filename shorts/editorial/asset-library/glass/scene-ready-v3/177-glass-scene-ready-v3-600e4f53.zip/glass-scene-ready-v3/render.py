from PIL import Image, ImageDraw, ImageFilter, ImageFont
from pathlib import Path
import numpy as np, math, subprocess, json, shutil
P=Path(__file__).resolve().parent; W,H=720,1280;FPS=30;N=180;PALE='#f4f4f2'
for folder in ['card-rgba','shadow-rgba','frost-mask','source-assets']:(P/folder).mkdir(exist_ok=True)
def smooth(t):
 t=max(0,min(1,t));return t*t*t*(t*(t*6-15)+10)
def layers(t):
 en=smooth(t/1.35);ex=1-smooth((t-5.1)/.9);op=en*ex
 scale=.94+.06*en+.006*math.sin(t*1.1);w=540*scale;h=450*scale;x=(W-w)/2+3*math.sin(t*.8);y=425+(1-en)*65-10*(1-ex)+3*math.sin(t*.9)
 mask=Image.new('L',(W,H));d=ImageDraw.Draw(mask);d.rounded_rectangle((x,y,x+w,y+h),radius=46,fill=255)
 inside=np.array(mask,dtype=float)/255;yy,xx=np.mgrid[:H,:W]
 # Quiet transparent body with local edge lighting rather than an opaque plate.
 body=(18+10*np.exp(-(((xx-x)/(w*.7))**2+((yy-y)/(h*.8))**2)))*inside*op
 a=np.zeros((H,W,4),np.uint8);a[:,:,:3]=(231,239,246);a[:,:,3]=body.astype(np.uint8);skin=Image.fromarray(a)
 rim=Image.new('RGBA',(W,H));rd=ImageDraw.Draw(rim);rd.rounded_rectangle((x,y,x+w,y+h),radius=46,outline=(255,255,255,int(135*op)),width=2);rd.rounded_rectangle((x+3,y+3,x+w-3,y+h-3),radius=44,outline=(111,145,173,int(18*op)),width=1)
 # Moving narrow reflected light, clipped to the rim; no decorative diagonal stripe.
 outer=np.array(mask);inner=Image.new('L',(W,H));ImageDraw.Draw(inner).rounded_rectangle((x+3,y+3,x+w-3,y+h-3),radius=43,fill=255);edge=np.maximum(outer.astype(float)-np.array(inner),0)/255
 sx=x+w*(.15+.7*smooth((t-.5)/4));shine=np.exp(-((xx-sx)/95)**2)*np.exp(-((yy-y)/95)**2)*edge*op*150
 shineim=Image.new('RGBA',(W,H),(255,255,255,0));shineim.putalpha(Image.fromarray(shine.astype(np.uint8)));skin=Image.alpha_composite(Image.alpha_composite(skin,rim),shineim)
 shadow=Image.new('RGBA',(W,H),(23,38,56,0));sm=Image.new('L',(W,H));ImageDraw.Draw(sm).rounded_rectangle((x+1,y+17,x+w+1,y+h+17),radius=46,fill=int(30*op));sha=np.array(sm.filter(ImageFilter.GaussianBlur(22)),dtype=float)*(1-inside*.85);shadow.putalpha(Image.fromarray(sha.astype(np.uint8)))
 mask=mask.point(lambda z:round(z*op));return skin,shadow,mask,(x,y,w,h),op

def asset(name):
 im=Image.open(P/'source-assets'/name).convert('RGBA');b=im.getbbox();return im.crop(b)
def place(bg,im,cx,cy,width,opacity=1):
 hh=round(width*im.height/im.width);ss=im.resize((round(width),hh),Image.Resampling.LANCZOS)
 if opacity<1:ss.putalpha(ss.getchannel('A').point(lambda a:round(a*opacity)))
 bg.alpha_composite(ss,(round(cx-width/2),round(cy-hh/2)))
 return bg

def frost(bg,mask,box):
 # Background-dependent blur with a slight edge displacement from the original scene.
 softened=bg.filter(ImageFilter.GaussianBlur(15));x,y,w,h=box
 refracted=bg.transform((W,H),Image.Transform.AFFINE,(1,0,-2.5,0,1,1.5),Image.Resampling.BICUBIC)
 blended=Image.blend(softened,refracted,.14);bg.paste(blended,(0,0),mask);return bg

def writer(name):return subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pixel_format','rgb24','-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','-','-an','-c:v','libx264','-crf','18','-pix_fmt','yuv420p','-movflags','+faststart',str(P/name)],stdin=subprocess.PIPE)
def run():
 notebook=asset('clay-notebook-pencil.png');usb=asset('clay-usb-drive.png');chip=asset('chip-peach-skin.png')
 a=writer('glass-hero-pale-6s.mp4');b=writer('glass-clay-context-6s.mp4');stats=[]
 Image.new('RGB',(W,H),PALE).save(P/'flat-pale-background.png')
 for n in range(N):
  t=n/FPS;skin,shadow,mask,box,op=layers(t);skin.save(P/f'card-rgba/{n:03}.png');shadow.save(P/f'shadow-rgba/{n:03}.png');mask.save(P/f'frost-mask/{n:03}.png')
  hero=Image.new('RGBA',(W,H),PALE);hero=Image.alpha_composite(hero,shadow);hero=Image.alpha_composite(hero,skin);a.stdin.write(hero.convert('RGB').tobytes())
  demo=Image.new('RGBA',(W,H),PALE)
  # USB sits behind the hero glass to reveal actual frost; the notebook remains the hero.
  place(demo,usb,550,812+(1-op)*35,165,op*.8)
  demo=frost(demo,mask,box);demo=Image.alpha_composite(demo,shadow);demo=Image.alpha_composite(demo,skin)
  place(demo,notebook,354,620+(1-smooth(t/1.5))*65,330*(.96+.04*smooth(t/1.5)),op)
  place(demo,chip,320,790,230,op)
  b.stdin.write(demo.convert('RGB').tobytes())
  if n in [0,45,90,179]:
   aa=np.array(skin.getchannel('A'));stats.append({'frame':n,'corner_alpha':int(aa[0,0]),'centre_alpha':int(aa[640,360]),'partial_pixels':int(((aa>0)&(aa<255)).sum())})
 for proc in [a,b]:proc.stdin.close();proc.wait();assert proc.returncode==0
 (P/'alpha-metrics.json').write_text(json.dumps(stats,indent=2))
if __name__=='__main__':run()
