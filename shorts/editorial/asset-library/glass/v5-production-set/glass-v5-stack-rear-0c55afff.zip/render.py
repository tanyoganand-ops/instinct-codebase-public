from PIL import Image,ImageDraw,ImageFilter
from pathlib import Path
import numpy as np, math,subprocess,json
P=Path(__file__).resolve().parent;W,H=720,1280;FPS=30;N=180

yy,xx=np.mgrid[:H,:W].astype(np.float32)
def ease(t):
 t=max(0,min(1,t));return t*t*t*(t*(t*6-15)+10)
def image(rgb,a):
 q=np.empty((H,W,4),np.uint8);q[:,:,:3]=np.clip(rgb,0,255).astype(np.uint8);q[:,:,3]=np.clip(a,0,255).astype(np.uint8);return Image.fromarray(q,'RGBA')
def layer(t,kind,plane=0):
 en=ease(t/1.4);ex=1-ease((t-5.2)/.8);op=en*ex;sc=.93+.07*en
 cx=360+2*math.sin(t*.8);cy=651+55*(1-en)-6*(1-ex)
 if kind=='button': dims=(202,64,64);cy=640+35*(1-en);sc*=1-.025*ease((t-2.5)/.22)*(1-ease((t-2.9)/.3))
 elif kind=='stack':
  dims=(240,185,43);cx+=(-18 if plane==0 else 18)*en;cy+=(-30 if plane==0 else 30)*en;cx+=plane*12*math.sin(t*.65)*en
 else: dims=(275,305,48);cx+=650*(1-en)-650*(1-ex);cy=640
 # Optical plane tilts gently, settles without changing the carrier into a new shape.
 ang=math.radians(-1.4*(1-en)+.65*math.sin((t-.8)*.9)*en)
 dx=xx-cx;dy=yy-cy;u=dx*math.cos(ang)+dy*math.sin(ang);v=-dx*math.sin(ang)+dy*math.cos(ang)
 u=u/(1+.014*np.sin(t*.8)*v/240);bw=dims[0]*sc;bh=dims[1]*sc;r=dims[2]
 qx=np.abs(u)-(bw-r);qy=np.abs(v)-(bh-r);sd=np.sqrt(np.maximum(qx,0)**2+np.maximum(qy,0)**2)+np.minimum(np.maximum(qx,qy),0)-r
 inside=np.clip(.5-sd,0,1);dep=-sd
 edge=np.exp(-((dep-2)/1.25)**2)*inside;bevel=np.exp(-((dep-7)/5.2)**2)*inside;inner=np.exp(-((dep-14)/2.3)**2)*inside
 theta=np.arctan2(v/bh,u/bw);travel=-2.1+t*.75;diff=np.arctan2(np.sin(theta-travel),np.cos(theta-travel));spec=np.exp(-(diff/.23)**2)
 light=.45+.55*np.clip((-v/bh-u/bw)/2,-1,1)
 # Multi-band optical bevel: bright rim, cool inward refraction, subdued inner meniscus.
 tint=np.zeros((H,W,3),np.float32);tint[:]=(235,243,249)
 body=(6+6*np.exp(-((u/bw+.6)**2+(v/bh+.7)**2)))*inside
 base=image(tint,body*op)
 shade=image(np.broadcast_to(np.array([83,113,145]),(H,W,3)),(bevel*(12+18*(1-light))+inner*9)*op)
 rim=image(np.broadcast_to(np.array([255,255,255]),(H,W,3)),(edge*(80+110*light+65*spec)+bevel*spec*100)*op)
 blue=image(np.broadcast_to(np.array([160,201,235]),(H,W,3)),(bevel*(1-spec)*8)*op)
 # Short liquid glint riding across the top surface. It is local, never a broad stripe.
 glint=np.exp(-((u-bw*np.cos(travel))/55)**2-((v-bh*np.sin(travel))/34)**2)*inside
 sheen=image(np.broadcast_to(np.array([255,255,255]),(H,W,3)),glint*15*op)
 glass=Image.alpha_composite(Image.alpha_composite(Image.alpha_composite(Image.alpha_composite(base,shade),blue),sheen),rim)
 # Depth shadow with a small clean contact line plus broad lift shadow, both external.
 mask=Image.fromarray((inside*255).astype(np.uint8));shift=Image.new('L',(W,H));shift.paste(mask,(0,18));soft=np.array(shift.filter(ImageFilter.GaussianBlur(24)),np.float32)/255
 contact=np.exp(-((sd-3)/3)**2)*np.clip(v/bh,0,1)*(1-inside)
 alpha=(soft*(1-inside*.93)*25+contact*9)*op;shadow=image(np.broadcast_to(np.array([28,49,70]),(H,W,3)),alpha)
 # Quiet underside caustic, visible on flat pale without adding background shapes.
 ca=np.exp(-((u-bw*.4)/135)**2-((v-bh-12)/7)**2)*(1-inside)*5*op
 caustic=image(np.broadcast_to(np.array([148,194,227]),(H,W,3)),ca);shadow=Image.alpha_composite(shadow,caustic)
 gy,gx=np.gradient(sd);strength=8*np.exp(-((-sd-8)/11)**2)*(sd<0)*op
 return glass,shadow,Image.fromarray((inside*255*op).astype(np.uint8)),gx*strength,gy*strength

def run(kind):
 root=P/kind;root.mkdir(exist_ok=True);planes=2 if kind=='stack' else 1
 for j in range(planes):
  for k in ['glass-rgba','shadow-rgba','frost-mask','refraction-x','refraction-y']:(root/f'plane-{j+1}'/k).mkdir(parents=True,exist_ok=True)
 proc=subprocess.Popen(['ffmpeg','-y','-v','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r','30','-i','-','-an','-c:v','libx264','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',str(root/f'glass-{kind}-6s.mp4')],stdin=subprocess.PIPE)
 metrics=[]
 for n in range(N):
  im=Image.new('RGBA',(W,H),'#f4f4f2')
  for j in range(planes):
   d=root/f'plane-{j+1}'
   if (d/f'refraction-y/{n:03}.png').exists():
    g=Image.open(d/f'glass-rgba/{n:03}.png');s=Image.open(d/f'shadow-rgba/{n:03}.png');im=Image.alpha_composite(Image.alpha_composite(im,s),g);continue
   g,s,m,dx,dy=layer(n/FPS,kind,j)
   g.save(d/f'glass-rgba/{n:03}.png',compress_level=1);s.save(d/f'shadow-rgba/{n:03}.png',compress_level=1);m.save(d/f'frost-mask/{n:03}.png')
   for axis,field in [('x',dx),('y',dy)]:Image.fromarray(np.clip(32768+2048*field,0,65535).astype(np.uint16)).save(d/f'refraction-{axis}/{n:03}.png')
   im=Image.alpha_composite(Image.alpha_composite(im,s),g)
   if n in [0,45,90,179]:
    aa=np.asarray(g)[:,:,3];metrics.append({'plane':j+1,'frame':n,'corner_alpha':int(aa[0,0]),'max_alpha':int(aa.max()),'partial_pixels':int(((aa>0)&(aa<255)).sum())})
  proc.stdin.write(im.convert('RGB').tobytes())
 proc.stdin.close();proc.wait();assert proc.returncode==0
 (root/'alpha-metrics.json').write_text(json.dumps(metrics,indent=2))
if __name__=='__main__':
 import sys
 run(sys.argv[1])
