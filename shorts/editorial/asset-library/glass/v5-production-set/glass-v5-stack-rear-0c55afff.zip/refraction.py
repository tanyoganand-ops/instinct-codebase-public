"""Background-dependent refraction. Map PNGs encode signed pixels: 32768 neutral, 2048 units/pixel."""
from pathlib import Path
from PIL import Image,ImageFilter
import numpy as np, math
P=Path(__file__).resolve().parent;W,H=720,1280
def apply(background,frame,plane_directory):
 """Return refracted RGB image. Composite shadow and glass PNGs above this."""
 global P
 P=Path(plane_directory)
 bg=background.convert('RGB').resize((W,H));a=np.asarray(bg,dtype=np.float32);yy,xx=np.mgrid[:H,:W]
 dx=(np.asarray(Image.open(P/f'refraction-x/{frame:03}.png'),dtype=np.float32)-32768)/2048
 dy=(np.asarray(Image.open(P/f'refraction-y/{frame:03}.png'),dtype=np.float32)-32768)/2048
 X=np.clip(xx+dx,0,W-1);Y=np.clip(yy+dy,0,H-1);x0=X.astype(int);y0=Y.astype(int);x1=np.minimum(x0+1,W-1);y1=np.minimum(y0+1,H-1);fx=(X-x0)[...,None];fy=(Y-y0)[...,None]
 out=a[y0,x0]*(1-fx)*(1-fy)+a[y0,x1]*fx*(1-fy)+a[y1,x0]*(1-fx)*fy+a[y1,x1]*fx*fy
 refr=Image.fromarray(out.astype(np.uint8));mask=Image.open(P/f'frost-mask/{frame:03}.png')
 soft=Image.blend(refr,refr.filter(ImageFilter.GaussianBlur(6)),.25);bg.paste(soft,(0,0),mask);return bg
