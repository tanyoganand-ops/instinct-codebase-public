# Optical glass production set v5

Three accepted-v4-style components, each 720x1280,30fps,180frames,6seconds on flat pale #f4f4f2. Button: pill carrier with restrained press/release at2.5-3.2s. Stack: two separate optical cards with slow relative depth drift. Panel: lateral slide in from right, hold with moving specular light, exit left.

Each plane contains glass-rgba, shadow-rgba, frost-mask, refraction-x, refraction-y PNG sequences 000-179. All canvases are full720x1280 and placement is baked into the animation. Import at30fps, straight alpha. Shadow below glass, foreground text/art above. Blank by design: no labels or decoration baked in. Stack plane1 is rear, plane2 front; they remain separate, not a morphing carrier.

16-bit displacement maps:32768 neutral,2048units/pixel. Use refraction.apply(background,frame,plane_directory) to refract and gently frost an arbitrary scene, then composite that plane's shadow/glass. For stack, apply rear refraction then rear shadow/glass, followed by front refraction then front shadow/glass. Preview on uniform pale naturally shows reflective lighting rather than distortion; no detail exists to refract. Optical approximation, not Apple's shader or a physical raytrace.

render.py component-name creates assets and preview (button,stack,panel); resumes already-generated frames. Delete a component folder before a fresh changed render. refraction.py is background-dependent compositor. Requires Pillow,NumPy,ffmpeg. MP4 is silent and flattened; production PNG sequences have true alpha. Entrance/exit intentional, not seamless loops. No repository commits.

QA: six decoded phases per final MP4 visually checked for bevel shape, specular travel, clean pill/card edges, stack separation and panel slide crop.180frames decode; metadata720x1280,30fps,6seconds. Corner/partial alpha checks and counts recorded per plane; transparent first/last. No clay context scenes.
