# Tech Devices (clay, native render)

6 assets x 2 variants = 12 RGBA PNGs, 1024 x 1024. Each object was rendered individually by Gemini image generation (Nano Banana) at native 1024 px on a flat magenta background, keyed to true alpha, recentred, not upscaled. Soft offset shadow is in the alpha.

- `earbuds-case`: `earbuds-case-pale.png`, `earbuds-case-dark.png`
- `headphones`: `headphones-pale.png`, `headphones-dark.png`
- `laptop`: `laptop-pale.png`, `laptop-dark.png`
- `smartphone`: `smartphone-pale.png`, `smartphone-dark.png`
- `smartwatch`: `smartwatch-pale.png`, `smartwatch-dark.png`
- `wireless-mouse`: `wireless-mouse-pale.png`, `wireless-mouse-dark.png`

Style: tactile matte clay, blue #8CB6D1, peach #E6A386, cream #F3E7D0, isometric three-quarter view, soft upper-left light. Dark variant regrades blue to navy and peach to muted terracotta.
Replaces the earlier procedural/upsampled versions (5 Oct 2026). Filenames kept so they swap in place.
