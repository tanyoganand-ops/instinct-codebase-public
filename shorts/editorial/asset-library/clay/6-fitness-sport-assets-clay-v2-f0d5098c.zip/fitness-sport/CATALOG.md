# Fitness Sport (clay, native render)

6 assets x 2 variants = 12 RGBA PNGs, 1024 x 1024. Each object was rendered individually by Gemini image generation (Nano Banana) at native 1024 px on a flat magenta background, keyed to true alpha, recentred, not upscaled. Soft offset shadow is in the alpha.

- `dumbbell`: `dumbbell-pale.png`, `dumbbell-dark.png`
- `glass-heart`: `glass-heart-pale.png`, `glass-heart-dark.png`
- `sneaker`: `sneaker-pale.png`, `sneaker-dark.png`
- `soccer-ball`: `soccer-ball-pale.png`, `soccer-ball-dark.png`
- `stopwatch`: `stopwatch-pale.png`, `stopwatch-dark.png`
- `water-bottle`: `water-bottle-pale.png`, `water-bottle-dark.png`

Style: tactile matte clay, blue #8CB6D1, peach #E6A386, cream #F3E7D0, isometric three-quarter view, soft upper-left light. Dark variant regrades blue to navy and peach to muted terracotta.
Replaces the earlier procedural/upsampled versions (5 Oct 2026). Filenames kept so they swap in place.
