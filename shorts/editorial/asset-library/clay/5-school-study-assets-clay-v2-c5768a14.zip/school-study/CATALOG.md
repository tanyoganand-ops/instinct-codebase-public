# School Study (clay, native render)

6 assets x 2 variants = 12 RGBA PNGs, 1024 x 1024. Each object was rendered individually by Gemini image generation (Nano Banana) at native 1024 px on a flat magenta background, keyed to true alpha, recentred, not upscaled. Soft offset shadow is in the alpha.

- `backpack`: `backpack-pale.png`, `backpack-dark.png`
- `book-stack`: `book-stack-pale.png`, `book-stack-dark.png`
- `glass-lightbulb`: `glass-lightbulb-pale.png`, `glass-lightbulb-dark.png`
- `graduation-cap`: `graduation-cap-pale.png`, `graduation-cap-dark.png`
- `pencil`: `pencil-pale.png`, `pencil-dark.png`
- `spiral-notebook`: `spiral-notebook-pale.png`, `spiral-notebook-dark.png`

Style: tactile matte clay, blue #8CB6D1, peach #E6A386, cream #F3E7D0, isometric three-quarter view, soft upper-left light. Dark variant regrades blue to navy and peach to muted terracotta.
Replaces the earlier procedural/upsampled versions (5 Oct 2026). Filenames kept so they swap in place.
