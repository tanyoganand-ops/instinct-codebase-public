# Money Finance (clay, native render)

6 assets x 2 variants = 12 RGBA PNGs, 1024 x 1024. Each object was rendered individually by Gemini image generation (Nano Banana) at native 1024 px on a flat magenta background, keyed to true alpha, recentred, not upscaled. Soft offset shadow is in the alpha.

- `calculator`: `calculator-pale.png`, `calculator-dark.png`
- `coin-stack`: `coin-stack-pale.png`, `coin-stack-dark.png`
- `glass-credit-card`: `glass-credit-card-pale.png`, `glass-credit-card-dark.png`
- `growth-chart`: `growth-chart-pale.png`, `growth-chart-dark.png`
- `piggy-bank`: `piggy-bank-pale.png`, `piggy-bank-dark.png`
- `wallet`: `wallet-pale.png`, `wallet-dark.png`

Style: tactile matte clay, blue #8CB6D1, peach #E6A386, cream #F3E7D0, isometric three-quarter view, soft upper-left light. Dark variant regrades blue to navy and peach to muted terracotta.
Replaces the earlier procedural/upsampled versions (5 Oct 2026). Filenames kept so they swap in place.
