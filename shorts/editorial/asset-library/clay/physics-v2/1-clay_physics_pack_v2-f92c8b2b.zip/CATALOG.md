# Clay physics pack v2

Four RGBA clips, 720x1280, 24 fps. Same delivery layout and palette as v1 (clay shader, slab, cream preview backdrop, floor line y=1100). Each clip folder has the same files.

| File | What it is |
|---|---|
| layer_card_rgba.webm | Clay objects only (straight alpha, VP9 yuva420p). Includes the clay base slab. |
| layer_shadow_rgba.webm | Shadow only: black RGB, alpha 0-0.4. Put it under the card layer. |
| composite_rgba.webm | Shadow + objects flattened, still transparent background. |
| preview_on_backdrop.mp4 | Composite on a flat cream wall and table, for quick viewing. |
| qa/ | contact_sheet.png (8 evenly spaced frames), preview_fNNN.png, card_alpha_fNNN.png (RGBA stills). |
| simulation_trace.json | Per-frame body positions, angles, speeds from the sim (QA aid). |

| Clip | Frames | Length | Content |
|---|---|---|---|
| 01_wrecking_ball | 156 | 6.5 s | A clay wrecking ball on a cable swings in from the left and smashes a 2x6 block tower. Blocks scatter; the ball swings back and parks. |
| 02_marble_run | 192 | 8.0 s | Three clay marbles (red, yellow, blue) roll down three switchback ramps and gather in the catch corner. |
| 03_bowling_strike | 96 | 4.0 s | A clay bowling ball rolls in and strikes four pins; they cascade flat left to right and the ball rolls over them to a stop. |
| 04_spring_launch | 140 | 5.8 s | A clay coil spring compresses under a clay ball (visible squash), launches it high; the ball arcs into a catch cup with a landing squash, and the spring recovers with a wobble. |

## Notes
- Side-view 2D physics (pymunk) rendered with the v1 clay shader. Same palette, slab, lighting and backdrop as v1.
- Polish over v1: no lean jams (domino/bowling cascades fall fully flat), every clip ends on a clean static hold, and the spring launch has a clear area-preserving squash on compression and landing.
- The bowling pins and ball are driven kinematically (scripted falls synced to the ball). It reads as physics but is deterministic; the other three clips are live rigid-body sims.
- 01: the tower's left half scatters; part of the right column re-stacks and stays standing (real rigid-body result). The ball keeps a barely visible pendulum sway at the very end.
- 02: marbles end piled against the left wall of the catch area.
- 03: ball rides over the fallen pins (it lifts ~26 px while crossing the rack).
- Alpha only works in players/editors that read VP9 alpha (Chrome, Firefox, ffmpeg libvpx-vp9, most compositors). Safari and QuickTime may drop it. src/ regenerates everything (Python: pymunk, numpy, scipy, Pillow, ffmpeg). Nothing was committed to any repo.

## QA done
- ffprobe: all 16 files are 720x1280, 24 fps, correct frame counts (156/192/96/140 per layer).
- Decoded the card layer with libvpx-vp9: alpha runs 0-255, corners transparent.
- Contact sheets checked by eye for all four clips: no clipping at frame edges except intended entrances (ball off-screen left in 01/03, marbles from top in 02), no jams, all motion settled on the final frames.
