import sys,os,subprocess,glob
from clay import *
name,outdir=sys.argv[1],sys.argv[2]
fd='/tmp/frames_'+name; os.makedirs(outdir+'/qa',exist_ok=True)
n=len(glob.glob(fd+'/c*.png'))
bg=backdrop()
def enc(fn,pix,extra):
    cmd=['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt',pix,'-s',f'{W}x{H}','-r',str(FPS),'-i','-']+extra+[os.path.join(outdir,fn)]
    return subprocess.Popen(cmd,stdin=subprocess.PIPE)
vp9=['-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','30','-deadline','good','-cpu-used','5','-lag-in-frames','6','-auto-alt-ref','0','-metadata:s:v:0','alpha_mode=1']
h264=['-c:v','libx264','-pix_fmt','yuv420p','-crf','20','-preset','medium']
def loadall(kind):
    for i in range(n):
        yield np.asarray(Image.open(f'{fd}/{kind}{i:04d}.png').convert('RGBA'))
# streams
p=enc('layer_card_rgba.webm','rgba',vp9)
for a in loadall('c'): p.stdin.write(a.tobytes())
p.stdin.close(); p.wait()
p=enc('layer_shadow_rgba.webm','rgba',vp9)
for a in loadall('s'): p.stdin.write(a.tobytes())
p.stdin.close(); p.wait()
pc=enc('composite_rgba.webm','rgba',vp9); pp=enc('preview_on_backdrop.mp4','rgb24',h264)
sheet=[]; keys=sorted(set(int(x) for x in np.linspace(0,n-1,8)))
for i in range(n):
    c=np.asarray(Image.open(f'{fd}/c{i:04d}.png').convert('RGBA')).astype(np.float32)/255
    s=np.asarray(Image.open(f'{fd}/s{i:04d}.png').convert('RGBA'))[...,3].astype(np.float32)/255
    ca=c[...,3]; ta=ca+s*(1-ca)
    pm=c[...,:3]*ca[...,None]
    cstr=np.where(ta[...,None]>1e-4,pm/np.maximum(ta[...,None],1e-4),0)
    comp=(np.dstack([np.clip(cstr,0,1),ta])*255+.5).astype(np.uint8)
    prev=bg*(1-ta[...,None])+pm
    prev8=(np.clip(prev,0,1)*255+.5).astype(np.uint8)
    pc.stdin.write(comp.tobytes()); pp.stdin.write(prev8.tobytes())
    if i in keys:
        sheet.append(Image.fromarray(prev8).resize((270,480),Image.LANCZOS))
        Image.fromarray(prev8).save(f'{outdir}/qa/preview_f{i:03d}.png')
        Image.fromarray((c*255).astype(np.uint8),'RGBA').save(f'{outdir}/qa/card_alpha_f{i:03d}.png')
pc.stdin.close(); pp.stdin.close(); pc.wait(); pp.wait()
sh=Image.new('RGB',(270*4+50,480*2+30),(30,30,30))
for i,im in enumerate(sheet): sh.paste(im,(10+(i%4)*280,10+(i//4)*490))
sh.save(outdir+'/qa/contact_sheet.png')
print('encoded',n)
