from clay import *
import pymunk,json
ROOT='/home/sandbox/pack_v2'
DIMP=[(.3,.2,.93),(-.5,.4,.77),(.4,-.6,.69)]
# Reuse v1's exact shader. Area-preserving impact deformation is applied only to the visible skin.
def softball(dst,cx,cy,r,ang,col,squash=0):
    sy=1-squash; sx=1/sy
    if squash<.01: return ball(dst,cx,cy,r,ang,col,DIMP)
    tmp=np.zeros((H,W,4),np.float32); ball(tmp,360,640,r,ang,col,DIMP)
    crop=tmp[int(640-r-3):int(640+r+4),int(360-r-3):int(360+r+4)]
    # resize premultiplied color channels, then composite
    h,w=crop.shape[:2]; nw,nh=round(w*sx),round(h*sy)
    arr=np.stack([np.asarray(Image.fromarray(crop[:,:,k],'F').resize((nw,nh),Image.Resampling.BICUBIC)) for k in range(4)],axis=2)
    a=np.clip(arr[:,:,3],0,1); rgb=np.clip(arr[:,:,:3]/np.maximum(a[:,:,None],1e-5),0,1)
    over(dst,rgb,a,round(cx-nw/2),round(cy-nh/2))

def setup():
    s=pymunk.Space();s.gravity=(0,1650);s.iterations=50;s.damping=.995;s.sleep_time_threshold=.45
    return s

def seg(s,a,b,r=5):
    sh=pymunk.Segment(s.static_body,a,b,r);sh.friction=.08;sh.elasticity=.12;s.add(sh);return sh

def block(s,x,y,w,h,col,m=1):
    b=pymunk.Body(m,pymunk.moment_for_box(m,(w,h)));b.position=x,y
    sh=pymunk.Poly.create_box(b,(w,h),radius=2);sh.friction=.65;sh.elasticity=.08;s.add(b,sh)
    return dict(b=b,sh=sh,w=w,h=h,col=col,kind='box')

def orb(s,x,y,r,col,m=1):
    b=pymunk.Body(m,pymunk.moment_for_circle(m,0,r));b.position=x,y
    sh=pymunk.Circle(b,r);sh.friction=.2;sh.elasticity=.15;s.add(b,sh)
    return dict(b=b,sh=sh,r=r,col=col,kind='ball',impact=-99)

def run(name):
    s=setup(); objects=[]; ramps=[]; NF=168
    seg(s,(40,FLOOR),(680,FLOOR),2);seg(s,(42,420),(42,FLOOR),4);seg(s,(678,420),(678,FLOOR),4)
    if name=='01_wrecking_ball':
        NF=156
        for row in range(6):
            for col in range(2): objects.append(block(s,432+col*54,FLOOR-28-row*58,50,54,PAL[(row+col)%5]))
        o=orb(s,96,878,64,PAL[3],12);objects.append(o)
        pivot=(230,500);j=pymunk.PinJoint(s.static_body,o['b'],pivot,(0,0));j.distance=400;s.add(j)
        o['b'].velocity=(690,240)
    elif name=='02_marble_run':
        NF=192
        ramps=[((100,525),(550,675)),((625,765),(150,875)),((85,985),(560,1050))]
        for a,b in ramps:seg(s,a,b,12)
        seg(s,(650,705),(650,835),10);seg(s,(65,885),(65,1020),10)
        seg(s,(650,1050),(650,1100),10)
        for i in range(3):
            o=orb(s,145,440-i*100,27,PAL[[0,1,3][i]],1);objects.append(o)
    elif name=='03_bowling_strike':
        NF=96
        for i,x in enumerate([260,330,400,470]):
            objects.append(block(s,x,1043,26,110,PAL[(i+2)%7],.45)); objects[-1]['b'].body_type=pymunk.Body.KINEMATIC; objects[-1]['x0']=x
        o=orb(s,-60,1042,58,PAL[0],8);o['b'].body_type=pymunk.Body.KINEMATIC;objects.append(o)
        for ob in objects[:-1]: ob['sh'].collision_type=1
        objects[-1]['sh'].collision_type=2
        s.on_collision(1,1,begin=lambda *a: False)
        s.on_collision(1,2,begin=lambda *a: False)
    elif name=='04_spring_launch':
        NF=140
        # Spring pushes the ball vertically and sideways towards a clay catch cup.
        o=orb(s,185,990,58,PAL[1],3);objects.append(o)
        seg(s,(475,1005),(475,1100),13);seg(s,(655,1005),(655,1100),13)
    out=Out(name,ROOT+'/'+name,NF); trace=[]
    for f in range(NF):
        t=f/FPS
        if name=='03_bowling_strike':
            for i,pin in enumerate(objects[:-1]):
                fi=9+round(2.67*i); b=pin['b']
                if f<fi: continue
                th=(math.pi/2)*min(1,((f-fi)/9)**1.7)
                if f>=fi+9: th=math.pi/2-0.055*math.exp(-(f-fi-9)/4)*math.sin((f-fi-9)*0.9)
                b.position=(pin['x0']+13-13*math.cos(th)+55*math.sin(th),1098-13*math.sin(th)-55*math.cos(th))
                b.angle=th; b.velocity=(0,0); b.angular_velocity=0
            bb=objects[-1]['b']
            if f<24: bx=-60+640*(f/24)
            else: bx=580+14.67*(1-0.55**(f-23))/0.45
            def sm(t): t=min(max(t,0),1); return t*t*(3-2*t)
            bb.position=(bx,1042-26*sm((bx-170)/60)+26*sm((bx-520)/60)); bb.velocity=(0,0); bb.angle=-bx/58
        if name=='04_spring_launch' and f<19:
            o=objects[0];o['b'].position=(185,990+27*math.sin(math.pi*f/36));o['b'].velocity=(0,0)
        if name=='04_spring_launch' and f==19:objects[0]['b'].velocity=(305,-1080)
        for sub in range(12):
            s.step(1/FPS/12)
            for ob in objects:
                b=ob['b']
                if name=='01_wrecking_ball' and ob is objects[-1] and f>120: b.velocity*=.87
                if name=='03_bowling_strike' and ob is objects[-1] and f>18: b.velocity=b.velocity*.93; b.angular_velocity*=.97
                if name!='02_marble_run' and f>94:
                    b.velocity=b.velocity*.976;b.angular_velocity*=.967
                elif name=='02_marble_run' and b.position.y>1060:b.velocity*=.98;b.angular_velocity*=.98
        cm=np.zeros((H,W,4),np.float32);slab(cm,40,FLOOR,680,FLOOR+56)
        ell=[]
        if name=='01_wrecking_ball':
            x,y=objects[-1]['b'].position
            # clay-coated cable and rounded anchor
            d=np.array([x-230,y-500]);nn=np.array([-d[1],d[0]])/np.linalg.norm(d)*5
            shade_poly(cm,[(230+nn[0],500+nn[1]),(x+nn[0],y+nn[1]),(x-nn[0],y-nn[1]),(230-nn[0],500-nn[1])],SLAB,4)
            ball(cm,230,500,18,0,PAL[5],DIMP)
        for a,b in ramps:
            dx,dy=b[0]-a[0],b[1]-a[1];ang=math.atan2(dy,dx)
            shade_poly(cm,rrect((a[0]+b[0])/2,(a[1]+b[1])/2,math.hypot(dx,dy)+18,28,ang,12),SLAB,12)
        if name=='02_marble_run':
            slab(cm,640,695,660,845,rad=9);slab(cm,55,875,75,1030,rad=9);slab(cm,637,1040,663,1108,rad=11)
        if name=='04_spring_launch':
            # Coil compression then a damped elastic recovery.
            comp=27*math.sin(math.pi*f/36) if f<19 else 24*math.exp(-(f-19)/11)*math.cos((f-19)*.55)
            top=1048+comp
            for k in range(7):
                yy=top+(1090-top)*k/6
                shade_poly(cm,rrect(185,yy,91,12,(-1)**k*.12,5),PAL[3],5)
            slab(cm,133,top-12,237,top+5,col=PAL[3],rad=8)
            slab(cm,462,995,488,1105,rad=12);slab(cm,642,995,668,1105,rad=12)
        for ob in objects:
            b=ob['b'];x,y=b.position;a=b.angle
            if ob['kind']=='box':
                w,h=ob['w'],ob['h'];shade_poly(cm,rrect(x,y,w,h,a,min(9,w*.25)),ob['col'],min(12,w*.4),noise_rot=a,center=(x,y))
                bot=y+abs(math.cos(a))*h/2+abs(math.sin(a))*w/2;rx=abs(math.cos(a))*w/2+abs(math.sin(a))*h/2
            else:
                r=ob['r'];sq=0
                if name=='04_spring_launch':
                    if f<19:sq=.04+.27*math.sin(math.pi*f/36)
                    # squash at the catch-cup impact and a short recovery.
                    if y+r>1091 and abs(b.velocity.y)>100: ob['impact']=f
                    dt=f-ob['impact']
                    if dt>=0:sq=max(sq,.32*math.exp(-dt/5))
                softball(cm,x,y,r,a,ob['col'],sq);bot=y+r;rx=r
            ell.append((x,rx+4,10,.4*max(0,1-(FLOOR-bot)/180)))
        out.push(cm,shadow_layer(cm[...,3],ell))
        trace.append([[round(o['b'].position.x,2),round(o['b'].position.y,2),round(o['b'].angle,3),round(o['b'].velocity.length,2)] for o in objects])
    out.close();json.dump(trace,open(ROOT+'/'+name+'/simulation_trace.json','w'))
if __name__=='__main__':run(sys.argv[1])
