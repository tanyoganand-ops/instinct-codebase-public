import numpy as np, math, subprocess, os, sys
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt, gaussian_filter, shift as ndshift
W,H,FPS=720,1280,24
FLOOR=1100
PAL=[(201,98,72),(226,170,72),(140,166,122),(110,146,170),(232,170,170),(238,226,200),(150,116,160)]
SLAB=(196,178,154)
L=np.array([-0.5,-0.55,0.67]); L/=np.linalg.norm(L)
Hh=L+np.array([0,0,1.0]); Hh/=np.linalg.norm(Hh)

def light(nx,ny,nz,col,extra=None):
    d=np.clip(nx*L[0]+ny*L[1]+nz*L[2],0,1)
    s=np.clip(nx*Hh[0]+ny*Hh[1]+nz*Hh[2],0,1)**14*0.10
    amb=0.40+0.12*nz
    c=np.array(col,np.float32)/255.
    rgb=c[None,None,:]*(amb+0.78*d)[...,None]+s[...,None]
    # warm bounce light from bottom
    rgb+= (np.clip(ny,0,1)*0.06)[...,None]*np.array([1.0,0.7,0.5])
    return np.clip(rgb,0,1)

def over(dst,rgb,a,x0,y0):
    h,w=a.shape
    xa,ya=max(x0,0),max(y0,0); xb,yb=min(x0+w,W),min(y0+h,H)
    if xa>=xb or ya>=yb: return
    sa=a[ya-y0:yb-y0,xa-x0:xb-x0]; sr=rgb[ya-y0:yb-y0,xa-x0:xb-x0]
    d=dst[ya:yb,xa:xb]
    d[...,:3]=sr*sa[...,None]+d[...,:3]*(1-sa[...,None])
    d[...,3]=sa+d[...,3]*(1-sa)

def noise_tex(seed,size=256):
    r=np.random.RandomState(seed)
    n=gaussian_filter(r.rand(size,size),2.2,mode='wrap')+0.5*gaussian_filter(r.rand(size,size),0.9,mode='wrap')
    n=(n-n.mean())/n.std(); return n.astype(np.float32)
NT=noise_tex(1)
def noise_at(X,Y):
    return NT[(Y.astype(int))%256,(X.astype(int))%256]

def ball(dst,cx,cy,r,ang,col,dimples):
    x0,y0=int(math.floor(cx-r-2)),int(math.floor(cy-r-2)); n=int(2*r+6)
    if x0>=W or y0>=H or x0+n<0 or y0+n<0: return
    yy,xx=np.mgrid[y0:y0+n,x0:x0+n].astype(np.float32)
    dx,dy=xx+0.5-cx,yy+0.5-cy
    dist=np.sqrt(dx*dx+dy*dy); a=np.clip(r+0.5-dist,0,1).astype(np.float32)
    u,v=dx/r,dy/r; w=np.sqrt(np.clip(1-u*u-v*v,0,1))
    nx,ny,nz=u,v,w
    ca,sa=math.cos(ang),math.sin(ang)
    dark=np.zeros_like(u)
    for (a1,a2,a3) in dimples:
        px,py,pz=a1*ca-a2*sa,a1*sa+a2*ca,a3
        dd=nx*px+ny*py+nz*pz
        b=np.exp(-(np.clip(1-dd,0,2)/0.012)); dark+=b
        # perturb normal toward the dimple center (bowl)
        nx=nx-0.5*b*(nx-px); ny=ny-0.5*b*(ny-py)
        nn=np.sqrt(nx*nx+ny*ny+nz*nz)+1e-6
    nz=np.sqrt(np.clip(1-nx*nx-ny*ny,0,1))
    rgb=light(nx,ny,nz,col)
    # fine clay grain, rotating with ball
    gx=(u*ca-v*sa)*r*0.9+128; gy=(u*sa+v*ca)*r*0.9+128
    g=noise_at(gx,gy)
    rgb=rgb*(1+0.035*g)[...,None]
    rgb*= (1-0.28*np.clip(dark,0,1))[...,None]
    # ambient occlusion rim
    rgb*= (0.82+0.18*np.clip(w*2.2,0,1))[...,None]
    over(dst,rgb.astype(np.float32),a,x0,y0)

def poly_mask(pts,ss=2):
    pts=np.array(pts,np.float32)
    x0,y0=int(math.floor(pts[:,0].min()))-4,int(math.floor(pts[:,1].min()))-4
    x1,y1=int(math.ceil(pts[:,0].max()))+5,int(math.ceil(pts[:,1].max()))+5
    w,h=x1-x0,y1-y0
    im=Image.new('L',(w*ss,h*ss),0)
    ImageDraw.Draw(im).polygon([((x-x0)*ss,(y-y0)*ss) for x,y in pts],fill=255)
    m=np.asarray(im.resize((w,h),Image.BOX),np.float32)/255.
    return m,x0,y0

def shade_poly(dst,pts,col,bevel,noise_origin=(0,0),noise_rot=0.0,center=(0,0)):
    m,x0,y0=poly_mask(pts)
    if m.max()<=0: return
    d=distance_transform_edt(np.pad(m>0.5,1))[1:-1,1:-1]+m*0.5
    t=np.clip(d/bevel,0,1)
    h=bevel*np.sqrt(1-(1-t)**2)
    h=gaussian_filter(h,1.2)
    gy,gx=np.gradient(h)
    nz=1/np.sqrt(1+gx*gx+gy*gy); nx=-gx*nz; ny=-gy*nz
    hh,ww=m.shape
    yy,xx=np.mgrid[0:hh,0:ww].astype(np.float32)
    X,Y=xx+x0-center[0],yy+y0-center[1]
    c,s=math.cos(-noise_rot),math.sin(-noise_rot)
    g=noise_at(X*c-Y*s+128+noise_origin[0],X*s+Y*c+128+noise_origin[1])
    rgb=light(nx,ny,nz,col)*(1+0.04*g)[...,None]
    rgb*=(0.80+0.20*np.clip(t*1.5,0,1))[...,None]
    over(dst,np.clip(rgb,0,1).astype(np.float32),m.astype(np.float32),x0,y0)

def rrect(cx,cy,w,h,ang,rad=5):
    pts=[]
    for (sx,sy,a0) in [(1,1,0),(-1,1,90),(-1,-1,180),(1,-1,270)]:
        ccx,ccy=sx*(w/2-rad),sy*(h/2-rad)
        for k in range(7):
            t=math.radians(a0+k*15)
            pts.append((ccx+rad*math.cos(t),ccy+rad*math.sin(t)))
    c,s=math.cos(ang),math.sin(ang)
    return [(cx+x*c-y*s,cy+x*s+y*c) for x,y in pts]

def slab(dst,x0,y0,x1,y1,col=SLAB,rad=10,bevel=14):
    shade_poly(dst,rrect((x0+x1)/2,(y0+y1)/2,x1-x0,y1-y0,0,rad),col,bevel,center=(x0,y0))

def shadow_layer(color_a,ell):
    """color_a: alpha of objects (H,W). ell: list of (cx,rx,ry,strength)"""
    sh=ndshift(color_a,(12,16),order=1)
    sh=gaussian_filter(sh,10)*0.34
    sh2=gaussian_filter(ndshift(color_a,(3,4),order=1),3.5)*0.22
    out=np.maximum(sh,sh2)
    if ell:
        yy,xx=np.mgrid[FLOOR-30:FLOOR+40,0:W].astype(np.float32)
        e=np.zeros(xx.shape,np.float32)
        for cx,rx,ry,st in ell:
            q=((xx-cx)/rx)**2+((yy-(FLOOR+4))/ry)**2
            e=np.maximum(e,st*np.exp(-q*1.6))
        e=gaussian_filter(e,4)
        out[FLOOR-30:FLOOR+40]=np.maximum(out[FLOOR-30:FLOOR+40],e)
    return np.clip(out,0,0.8).astype(np.float32)

def backdrop():
    y=np.linspace(0,1,H)[:,None,None]
    wall=np.array([240,230,214],np.float32)*(1-0.12*y)+np.array([226,214,196],np.float32)*0.0
    bg=np.repeat(wall,W,1)/255.
    # table below floor line
    tab=np.array([214,196,170],np.float32)/255.
    bg=np.broadcast_to(bg,(H,W,3)).copy()
    yy=np.arange(H)[:,None]
    fl=np.clip((yy-(FLOOR+50))/6.0,0,1)[...,None]
    bg=bg*(1-fl)+tab[None,None,:]*fl*(0.92+0.08*np.linspace(0,1,W)[None,:,None])
    return bg.astype(np.float32)
BG=None

class Out:
    def __init__(s,name,outdir,nframes):
        s.outdir=outdir; s.name=name; s.n=0; s.nframes=nframes
        os.makedirs(os.path.join(outdir,'qa'),exist_ok=True)
        s.fd='/tmp/frames_'+name
        os.makedirs(s.fd,exist_ok=True)
        s.keys=set(int(x) for x in np.linspace(0,nframes-1,8)); s.stats=[]
    def push(s,color_pm,shadow_a):
        a=color_pm[...,3:4]
        straight=np.where(a>1e-4,color_pm[...,:3]/np.maximum(a,1e-4),0)
        col=(np.dstack([np.clip(straight,0,1),a])*255+0.5).astype(np.uint8)
        sh=np.zeros((H,W,4),np.uint8); sh[...,3]=(np.clip(shadow_a,0,1)*255+0.5).astype(np.uint8)
        Image.fromarray(col,'RGBA').save(f'{s.fd}/c{s.n:04d}.png',compress_level=1)
        Image.fromarray(sh,'RGBA').save(f'{s.fd}/s{s.n:04d}.png',compress_level=1)
        s.stats.append((float(a.max()),float(a.mean()),float(shadow_a.max())))
        s.n+=1
    def close(s):
        np.save(s.fd+'/stats.npy',np.array(s.stats))
