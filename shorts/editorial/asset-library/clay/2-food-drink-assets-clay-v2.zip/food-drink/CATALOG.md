# Food Drink (clay, native render)

6 assets x 2 variants = 12 RGBA PNGs, 1024 x 1024. Each object was rendered individually by Gemini image generation (Nano Banana) at native 1024 px on a flat magenta background, keyed to true alpha, recentred, not upscaled. Soft offset shadow is in the alpha.

- `boba-cup`: `boba-cup-pale.png`, `boba-cup-dark.png`
- `burger`: `burger-pale.png`, `burger-dark.png`
- `coffee-cup`: `coffee-cup-pale.png`, `coffee-cup-dark.png`
- `donut`: `donut-pale.png`, `donut-dark.png`
- `ice-cream-cone`: `ice-cream-cone-pale.png`, `ice-cream-cone-dark.png`
- `pizza-slice`: `pizza-slice-pale.png`, `pizza-slice-dark.png`

Style: tactile matte clay, blue #8CB6D1, peach #E6A386, cream #F3E7D0, isometric three-quarter view, soft upper-left light. Dark variant regrades blue to navy and peach to muted terracotta.
Replaces the earlier procedural/upsampled versions (5 Oct 2026). Filenames kept so they swap in place.
