# Beauty Selfcare

Six tactile clay subjects, each in pale and dark material variants. All asset files are true RGBA PNGs, 1254 x 1254 pixels. Blue, peach and cream palette matched to the supplied clay reference; upper-left lighting and subtle alpha shadows.

## Assets

| Subject | Pale file | Dark file | Detail provenance |
|---|---|---|---|
| lotion-pump | `beauty-selfcare-lotion-pump-pale.png` | `beauty-selfcare-lotion-pump-dark.png` | upsampled from 512px source cell |
| perfume | `beauty-selfcare-perfume-pale.png` | `beauty-selfcare-perfume-dark.png` | upsampled from 512px source cell |
| lipstick | `beauty-selfcare-lipstick-pale.png` | `beauty-selfcare-lipstick-dark.png` | upsampled from 512px source cell |
| compact-mirror | `beauty-selfcare-compact-mirror-pale.png` | `beauty-selfcare-compact-mirror-dark.png` | upsampled from 512px source cell |
| hairbrush | `beauty-selfcare-hairbrush-pale.png` | `beauty-selfcare-hairbrush-dark.png` | upsampled from 512px source cell |
| skincare-towel | `beauty-selfcare-skincare-towel-pale.png` | `beauty-selfcare-skincare-towel-dark.png` | upsampled from 512px source cell |

## Use

Import an individual PNG into your slide, editor or animation timeline. The pale and dark names describe object materials, not a baked-in backdrop. Keep aspect ratio locked. Both work over light and dark backgrounds. Shadows are included in alpha. These are generated illustrative objects, not product photography or branded assets.

`alpha-contact-sheet.png` is an actual transparent sheet. The separate external preview uses a checkerboard to make the alpha easy to inspect. `pale-dark-background-check.png` previews both materials on both backgrounds.

## Resolution caveat

Native individual renders have 1254px detail. Assets labelled upsampled were extracted from a 512px-wide sheet cell, keyed, decontaminated and resized to 1254px. They meet the canvas-size requirement but do not have native 1024px object detail. Individual regeneration was stopped by the daily image quota. Do not present upsampled files as native high-resolution renders.

## Construction

Pale material preserves the source render. Dark uses a locally graded navy blue and richer muted terracotta with warmer cream, preserved shading and preserved alpha. No fake frosted blur is included: these packs follow the clay style, not backdrop-dependent glass.

## Alpha check

Visually inspected contact sheets, pale/dark-background composites and magnified edge crops. Magenta key spill was removed and edge colours pulled from the opaque object interior. Grid-derived assets are visibly softer when magnified and remain candidates for native rerender.
