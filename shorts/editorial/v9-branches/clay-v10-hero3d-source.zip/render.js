const pp=require('puppeteer-core');const fs=require('fs');
(async()=>{const [a,b,dir]=[+process.argv[2],+process.argv[3],process.argv[4]||'frames'];fs.mkdirSync(dir,{recursive:true});
const br=await pp.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--allow-file-access-from-files']});
const pg=await br.newPage();await pg.setViewport({width:1080,height:1920,deviceScaleFactor:1});pg.on('pageerror',e=>console.log('ERR',e));pg.on('console',m=>console.log(m.text()));
await pg.goto('file:///tmp/b/index.html');await pg.evaluate(()=>document.fonts.ready);await new Promise(r=>setTimeout(r,500));
const bad=[];
for(let f=a;f<b;f++){const t=f/30;await pg.evaluate(t=>seek(t),t);
 const viol=await pg.evaluate(()=>{const o=[];for(const id of ['lab','head','ver','cA','cB','sA','sB','cta','rail']){const el=document.getElementById(id);if(+getComputedStyle(el).opacity<.5||el.style.display==='none')continue;const r=el.getBoundingClientRect();
 const cs=getComputedStyle(el);let x0=r.left,x1=r.right;if(['lab','head','ver','sA','sB','rail'].includes(id)){const rg=document.createRange();rg.selectNodeContents(el);const q=rg.getBoundingClientRect();x0=q.left;x1=q.right}
 if(x0<47.5||x1>888.5||r.top<287||r.bottom>1249)o.push(id+':'+[x0,x1,r.top,r.bottom].map(Math.round))}return o});
 if(viol.length)bad.push(f+' '+viol.join(' '));
 await pg.screenshot({path:`${dir}/f${String(f).padStart(4,'0')}.jpg`,type:'jpeg',quality:93});}
fs.writeFileSync(`${dir}/viol_${a}.txt`,bad.join('\n'));await br.close()})();
