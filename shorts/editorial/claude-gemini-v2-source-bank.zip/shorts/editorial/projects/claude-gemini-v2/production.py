from PIL import Image,ImageDraw,ImageFont,ImageFilter
import numpy as np,json,pathlib,subprocess,math,sys
from frame_engine import expand,track,curve,clamp,FPS,FRAMES,W,H,write_plan
R=pathlib.Path(__file__).parent
PAPER='#f4f3ef';INK='#171717';MUTED='#696661';CLAY='#d57855';BLUE='#4285f4'
FONT='/usr/share/fonts/truetype/liberation2/LiberationSans-Regular.ttf';BOLD='/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf'
F={}
def ft(size,bold=False):
 k=(round(size),bold)
 if k not in F:F[k]=ImageFont.truetype(BOLD if bold else FONT,max(1,round(size)))
 return F[k]
N=[]
def node(id,kind,start=0,end=450,z=10,**kw):
 n={'id':id,'kind':kind,'start':start,'end':end,'z':z,'x':0,'y':0,'scale':1,'rotation':0,'opacity':1,'progress':1,'tracks':[],**kw};N.append(n);return n
def tr(n,prop,start,end,a,b,c='out_quint'):
 n['tracks'].append({'property':prop,'start':start,'end':end,'from':a,'to':b,'curve':c});return n

def text(id,t,x,y,size=70,bold=False,col=INK,start=0,end=450,z=30,center=True):
 return node(id,'text',start,end,z,x=x,y=y,text=t,size=size,bold=bold,color=col,center=center)
def enter(n,start,delay=0,dur=14,offset=36):
 y=n['y'];tr(n,'y',start+delay,start+delay+dur,y+offset,y);tr(n,'opacity',start+delay,start+delay+dur,0,1);return n
def exit(n,start,end,offset=-24):
 tr(n,'opacity',start,end,1,0);tr(n,'y',start,end,n['y'],n['y']+offset);return n
node('paper','background',z=0,color=PAPER)
node('grid','grid',z=1)
# Decorative marginal rails are distinct from logo carriers.
node('left-rail','rect',0,390,2,x=-180,y=340,width=500,height=44,color='#e4e2dd')
node('right-rail','rect',0,390,2,x=760,y=340,width=500,height=44,color='#e4e2dd')
# Start with readable promise and product lockups on elevated carriers.
head=text('hook-top','CLAUDE',540,225,126,True,start=0,end=90)
enter(head,0,dur=10,offset=20);head['tracks'][1]['from']=.75;exit(head,67,80)
h2=text('hook-bottom','OR GEMINI?',540,358,112,True,start=0,end=90)
enter(h2,0,delay=4,dur=12);h2['tracks'][1]['from']=.6;exit(h2,67,80)
claude=str(R/'../../banks/assets/logos/Claude-logo-Slate-0aff1e24.png');gemini=str(R/'../../banks/assets/logos/Gemini-logo-2025-32a9eb8b.png')
for side,x,path in [('claude',105,claude),('gemini',575,gemini)]:
 n=node(side+'-carrier','logo-card',0,450,20,x=x,y=595,width=400,height=190,path=path)
 tr(n,'y',0,18,635,595,'critically_damped');tr(n,'rotation',0,18,-4 if side=='claude' else 4,0,'critically_damped')
 tr(n,'x',60,88,x,105 if side=='claude' else 575,'in_out_cubic');tr(n,'y',60,75,595,240,'in_out_cubic');tr(n,'scale',60,75,1,.9,'in_out_cubic')
 tr(n,'opacity',370,388,1,0)
for id,t,x in [('name-c','Sonnet 5.5',305),('name-g','Gemini 4 Argon',775)]:
 n=text(id,t,x,823,43,True,start=30,end=90);enter(n,30,dur=12,offset=24);exit(n,66,83)
vs=text('vs','VS',540,985,142,True,start=0,end=69,col=CLAY);enter(vs,0,delay=8,dur=17,offset=45);exit(vs,58,68)
stamp=node('better','stamp',30,75,35,x=540,y=1170,text='BETTER?',size=64)
enter(stamp,30,dur=10);tr(stamp,'rotation',30,40,-6,-3);tr(stamp,'opacity',61,73,1,0)
intro=text('depends','Depends on',540,474,71,start=75,end=112);enter(intro,75,dur=8);exit(intro,102,112)
intro2=text('depends-bold','THE TEST.',540,556,101,True,start=75,end=112);enter(intro2,75,delay=3,dur=9);exit(intro2,102,112)
# A chart is a group of separately addressable components, not a single PNG.
# State resolver applies parent's exact group transform into child draw calls.
groups={}
def chart(prefix,title,subtitle,start,reveal,values,colors,winner):
 group={'x':108,'y':695,'scale':1,'opacity':1};groups[prefix]=group
 base=node(prefix+'-group','group',start,450,8,x=108,y=695)
 enter(base,start,dur=18,offset=150)
 # Raised shell/title/axis/bars/labels/counts each separately retained in frame JSON.
 node(prefix+'-shell','shell',start,450,9,group=prefix,x=0,y=0,width=864,height=518,color='white',radius=24)
 titleN=text(prefix+'-title',title,54,46,43,True,start=start,end=450,center=False);titleN['group']=prefix
 sub=text(prefix+'-subtitle',subtitle,54,101,30,start=start,end=450,center=False,col=MUTED);sub['group']=prefix
 node(prefix+'-axis','rule',start,450,10,group=prefix,x=55,y=166,width=755,height=2,color='#e9e6e0')
 for i,(name,v,col) in enumerate(zip(['Sonnet 5.5','Gemini 4 Argon'],values,colors)):
  yy=208+i*136
  label=text(prefix+f'-label-{i}',name,54,yy-22,30,True,start=start,end=450,center=False);label['group']=prefix
  node(prefix+f'-track-{i}','rect',start,450,11,group=prefix,x=54,y=yy+26,width=627,height=32,color='#eeeae4',radius=16)
  bar=node(prefix+f'-bar-{i}','bar',start,450,12,group=prefix,x=54,y=yy+26,width=627,height=32,color=col,value=v,progress=0)
  tr(bar,'progress',reveal,reveal+27,0,1,'in_out_cubic')
  count=text(prefix+f'-count-{i}','0%',754,yy+13,54,True,start=start,end=450);count['group']=prefix;count['value']=v;count['count_start']=reveal;count['count_end']=reveal+27
  mark=node(prefix+f'-winner-{i}','rule',reveal+30,450,13,group=prefix,x=54,y=yy+72,width=192 if winner==i else 0,height=4,color=col,progress=0)
  tr(mark,'progress',reveal+30,reveal+42,0,1)
 effort=text(prefix+'-effort','SONNET: MAX  /  ARGON: HIGH',54,457,25,True,start=start,end=450,center=False,col=MUTED);effort['group']=prefix
 return base
c=chart('terminal','Terminal-Bench 4.0','Agentic coding · Higher is better',78,112,[64,57],[CLAY,BLUE],0)
# Terminal begins 3-4s, second heading is visible only after the test description is read.
tr(c,'y',180,207,695,448,'in_out_cubic');tr(c,'scale',180,207,1,.72,'in_out_cubic');tr(c,'x',180,207,108,229,'in_out_cubic')
a=chart('automation','AutomationBench-AA','Business workflows · Higher is better',198,228,[71,78],[CLAY,BLUE],1)
# Temporarily allow one compact previous chart + full new comparison, with no overlap.
tr(a,'y',198,216,930,855,'out_quint')
# At 10s both become scoreboard proof cards, remain readable.
tr(c,'y',300,326,448,610,'in_out_cubic');tr(c,'scale',300,326,.72,.76,'in_out_cubic');tr(c,'x',300,326,229,212,'in_out_cubic')
tr(a,'y',300,326,855,1042,'in_out_cubic');tr(a,'scale',300,326,1,.76,'in_out_cubic');tr(a,'x',300,326,108,212,'in_out_cubic')
# End CTA has a distinct hold while charts move down slightly.
tr(c,'y',390,408,610,700,'in_out_cubic');tr(a,'y',390,408,1042,1100,'in_out_cubic');tr(c,'scale',390,408,.76,.68);tr(a,'scale',390,408,.76,.68);tr(c,'x',390,408,212,246);tr(a,'x',390,408,212,246)
lead=text('terminal-lead','Sonnet leads here.',540,1280,65,True,col=CLAY,start=150,end=181);enter(lead,150,dur=10);exit(lead,170,181)
lead=text('automation-lead','Gemini leads here.',540,1447,63,True,col=BLUE,start=270,end=310);enter(lead,270,dur=10);exit(lead,300,310)
diff=text('different-tests','Different tests.',540,413,91,True,start=330,end=389);enter(diff,330,dur=12)
diff2=text('different-winners','Different winners.',540,516,87,True,start=342,end=389);enter(diff2,342,dur=12)
# No overall winner in two tests appears as a caption, not a universally declaring verdict.
n=text('caveat','No overall winner from these two tests.',540,1514,37,start=360,end=390);enter(n,360,dur=10)
# Overwrites the earlier question per the owner's approved CTA addition.
for id,t,y,size,b in [('cta1','Want to make',252,79,False),('cta2','videos like this?',343,94,True)]:
 n=text(id,t,540,y,size,b,start=390,end=450);enter(n,390,dur=12)
cta=node('comment-cta','stamp',397,450,50,x=540,y=500,text='Comment "VIDEO"',size=59);enter(cta,397,dur=13,offset=35)
# Attribution remains visible throughout the actual factual graphics.
src=text('source','Source: Artificial Analysis · 30 Sep 2026',540,1576,29,start=90,end=450,col=MUTED);enter(src,90,dur=10)
roll=node('rollout','pill',300,450,48,x=540,y=1667,text='ARGON: LIMITED ROLLOUT',size=25,color='#e6e1d9');enter(roll,300,dur=12)
# Wipe is a separately addressable procedural element. A very short final wipe maintains CTA hold.
wipe=node('paper-wipe','wipe',442,450,100,progress=0);tr(wipe,'progress',442,449,0,1,'in_out_cubic')
SHOTS=[{'id':f'sec-{i:02}','start':i*30,'end':(i+1)*30,'purpose':p} for i,p in enumerate(['Immediate Claude/Gemini faceoff','Model names plus question','Dock logos; distinguish tests','Introduce terminal coding chart','Resolve terminal scores','Hold Sonnet lead','Stack terminal; bring workflow chart','Introduce AutomationBench-AA','Resolve workflow scores','Hold Argon lead','Stack comparison evidence','Different tests, different winners','Scope verdict to these two tests','Owner-requested comment CTA','Hold CTA; brief loop wipe'])]
frames=expand(N,SHOTS)
# Materialize count text and group transforms into each actual frame, no model/renderer improvisation.
for f in frames:
 for n in f['nodes']:
  if 'count_start' in n:
   p=track(f['frame'],n['count_start'],n['count_end'],0,1,'in_out_cubic');n['text']=str(round(n['value']*p))+'%'
write_plan(R/'frames-v2.json',frames,'Approved second-by-second argument: Sonnet leads Terminal-Bench 4.0 (64 vs 57); Argon leads AutomationBench-AA (78 vs 71). Source Artificial Analysis 30 September 2026; Sonnet Max versus Argon High. Owner approved a comment VIDEO end card. Model logos are identification only, no endorsement. Full state for each of 450 frames follows.')
(R/'tracks-v2.json').write_text(json.dumps({'nodes':N,'shots':SHOTS},indent=2))
# Renderer consumes only the saved, resolved frame states.
frames=json.loads((R/'frames-v2.json').read_text())['frames']
imgcache={};fontcache={};shadowcache={}
def surface(n):
 kind=n['kind']
 if kind=='text':
  font=ft(n['size'],n.get('bold',False));t=n['text'];bbox=font.getbbox(t);ww=math.ceil(font.getlength(t))+4;hh=n['size']+16
  s=Image.new('RGBA',(ww,hh));ImageDraw.Draw(s).text((2,2-bbox[1]),t,font=font,fill=n['color']);return s
 if kind in ['stamp','pill']:
  font=ft(n['size'],True);t=n['text'];ww=math.ceil(font.getlength(t))+64;hh=n['size']+45;s=Image.new('RGBA',(ww,hh));d=ImageDraw.Draw(s)
  d.rounded_rectangle((1,1,ww-2,hh-2),10 if kind=='stamp' else hh//2,fill=INK if kind=='stamp' else n['color']);bb=font.getbbox(t);d.text((32,19-bb[1]),t,font=font,fill='white' if kind=='stamp' else MUTED);return s
 if kind=='logo-card':
  s=Image.new('RGBA',(n['width'],n['height']));d=ImageDraw.Draw(s);d.rounded_rectangle((0,0,n['width']-1,n['height']-1),24,fill='white')
  if n['path'] not in imgcache:imgcache[n['path']]=Image.open(n['path']).convert('RGBA')
  logo=imgcache[n['path']].copy();logo.thumbnail((n['width']-62,n['height']-68),Image.Resampling.LANCZOS);s.alpha_composite(logo,((n['width']-logo.width)//2,(n['height']-logo.height)//2));return s
 if kind in ['shell','rect','bar','rule']:
  ww=n['width'];hh=n['height']
  if kind=='bar':ww*=n['progress']*n['value']/100
  if kind=='rule':ww*=n.get('progress',1)
  s=Image.new('RGBA',(max(1,round(ww)),max(1,round(hh))));d=ImageDraw.Draw(s)
  if ww>0:d.rounded_rectangle((0,0,s.width-1,s.height-1),n.get('radius',min(hh/2,16)),fill=n['color'])
  return s
 return None

def draw(fr):
 out=Image.new('RGBA',(W,H),PAPER);group={n['id'][:-6]:n for n in fr['nodes'] if n['kind']=='group'}
 for n in fr['nodes']:
  kind=n['kind']
  if kind in ['background','group']:continue
  if kind=='grid':
   gl=Image.new('RGBA',(W,H));d=ImageDraw.Draw(gl)
   for x in range(0,W,72):d.line((x,140,x,1680),fill=(203,198,188,28),width=1)
   for y in range(140,1680,72):d.line((0,y,W,y),fill=(203,198,188,28),width=1)
   out.alpha_composite(gl)
   continue
  if kind=='wipe':
   boundary=round(W*n['progress']);opening=draw(frames[0]);out.paste(opening.crop((0,0,boundary,H)),(0,0));continue
  x=n['x'];y=n['y'];scale=n['scale'];alpha=n['opacity']
  if 'group' in n:
   g=group[n['group']];x=g['x']+x*g['scale'];y=g['y']+y*g['scale'];scale*=g['scale'];alpha*=g['opacity']
  if alpha<=0:continue
  s=surface(n)
  if s is None:continue
  if n.get('center',False) or kind in ['stamp','pill']:
   x-=s.width*scale/2
  if scale!=1:s=s.resize((max(1,round(s.width*scale)),max(1,round(s.height*scale))),Image.Resampling.LANCZOS)
  if n['rotation']:s=s.rotate(n['rotation'],Image.Resampling.BICUBIC,expand=True)
  # Shadow is carrier-following; card contents remain separate render nodes.
  if kind in ['shell','logo-card']:
   key=(s.width,s.height)
   if key not in shadowcache:
    sw,sh=key;sha=Image.new('RGBA',(sw+80,sh+80));d=ImageDraw.Draw(sha);d.rounded_rectangle((35,39,35+sw,39+sh),24,fill=(0,0,0,47));shadowcache[key]=sha.filter(ImageFilter.GaussianBlur(16))
   sha=shadowcache[key]
   if alpha<1:sha=sha.copy();sha.putalpha(sha.getchannel('A').point(lambda a:round(a*alpha)))
   out.alpha_composite(sha,(round(x)-35,round(y)-27))
  if alpha<1:s=s.copy();s.putalpha(s.getchannel('A').point(lambda a:round(a*alpha)))
  out.alpha_composite(s,(round(x),round(y)))
 return out

if __name__=='__main__':
 # The plan has been written BEFORE the first visual frame.
 chosen=[0,15,35,55,75,95,120,145,165,185,205,225,245,265,285,305,325,345,365,385,405,425,443,449]
 sh=Image.new('RGB',(360*4,665*6),'white');d=ImageDraw.Draw(sh)
 for i,f in enumerate(chosen):
  im=draw(frames[f]).convert('RGB');im.save(R/f'qa-{f:03}.png');x=i%4*360;y=i//4*665;sh.paste(im.resize((360,640),Image.Resampling.LANCZOS),(x,y));d.text((x+5,y+643),f'{f:03} / {f/30:.2f}s',font=ft(18),fill='black')
 sh.save(R/'qa-v2-contact.png')
 if '--preview' in sys.argv:sys.exit()
 cmd=['ffmpeg','-y','-hide_banner','-loglevel','warning','-f','rawvideo','-vcodec','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-i',str(R/'v2-cues.wav'),'-map','0:v','-map','1:a','-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','160k','-t','15','-movflags','+faststart',str(R/'claude-vs-gemini-v2.mp4')]
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE)
 for f in frames:
  p.stdin.write(draw(f).convert('RGB').tobytes())
  if f['frame']%90==0:print('rendered',f['frame'],flush=True)
 p.stdin.close();assert p.wait()==0
