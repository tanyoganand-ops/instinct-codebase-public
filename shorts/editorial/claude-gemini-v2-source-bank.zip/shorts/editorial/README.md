# Reusable editorial Shorts

Project: Claude vs Gemini v2, rendered 15s review video.

- `projects/claude-gemini-v2/production.py`: working scene/visual primitives and JSON-driven renderer.
- `banks/motion/frame_engine.py`: reusable deterministic curves and frame expansion.
- `banks/assets/logos/`: original mark files plus provenance.
- Project has all 450 frame states, per-frame Markdown, tracks, sound, MP4 and QA.
- Run from the project folder with Python 3, Pillow, NumPy and ffmpeg. Linux font paths are in source.
- No secrets, account cookies or external downloaded scripts are included.
