import math, subprocess, json, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
S='/tmp/src/assets/'
W,H,FPS,N=1080,1920,30,450
ANT=lambda s: ImageFont.truetype(S+'Anton-Regular.ttf',s)
SANS=lambda s: ImageFont.truetype(S+'LiberationSans-Bold.ttf',s)
INK=(42,47,58,255)
def fit(txt,fnt,maxw,size):
    while fnt(size).getlength(txt)>maxw: size-=1
    return fnt(size)
_cache={}
def clay(w,h,r,top,bot):
    k=(w,h,r,top,bot)
    if k in _cache: return _cache[k]
    P=30
    m=Image.new('L',(w+2*P,h+2*P),0); ImageDraw.Draw(m).rounded_rectangle((P,P,P+w,P+h),r,fill=255)
    M=np.asarray(m,np.float32)/255
    yy,xx=np.mgrid[0:h+2*P,0:w+2*P]; g=np.clip(((xx-P)/w+(yy-P)/h)/2,0,1)[...,None]
    base=np.array(top,np.float32)*(1-g)+np.array(bot,np.float32)*g
    def sh(a,dx,dy): return np.roll(np.roll(a,dy,0),dx,1)
    bl=lambda a,r_: np.asarray(Image.fromarray((a*255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r_)),np.float32)/255
    hi=bl(np.clip(M-sh(M,9,9),0,1)*M,6)[...,None]
    lo=bl(np.clip(M-sh(M,-9,-9),0,1)*M,7)[...,None]
    rgb=base*(1-lo*.22)+255*hi*.75
    rgb=np.clip(rgb,0,255)
    out=np.dstack([rgb,M*255]).astype(np.uint8)
    im=Image.fromarray(out,'RGBA').crop((P,P,P+w,P+h)); _cache[k]=im; return im
def ctext(d,cx,cy,txt,f,fill=INK):
    d.text((cx,cy),txt,font=f,fill=fill,anchor='mm')
logoC=Image.open(S+'Claude-logo-Slate-0aff1e24.png').convert('RGBA'); logoG=Image.open(S+'Gemini-logo-2025-32a9eb8b.png').convert('RGBA')
def lg(im,w):
    return im.resize((w,int(im.height*w/im.width)),Image.LANCZOS)
PEACH=((252,222,203),(240,196,170)); BLUE=((214,226,248),(184,203,240)); CREAM=((255,250,243),(240,232,222)); MINT=((222,240,228),(190,222,200)); LILAC=((232,224,246),(208,196,234))
def brand(kind):
    im=clay(380,330,60,*(PEACH if kind=='c' else BLUE)).copy(); d=ImageDraw.Draw(im)
    lo=lg(logoC if kind=='c' else logoG,290); im.alpha_composite(lo,(45,50))
    txt='SONNET 5.5 (MAX)' if kind=='c' else 'GEMINI 4 (ARGON HIGH)'
    ctext(d,190,255,txt,fit(txt,ANT,320,40))
    return im
def title():
    im=clay(800,200,60,*CREAM).copy(); d=ImageDraw.Draw(im)
    ctext(d,400,100,'SONNET 5.5 VS GEMINI 4',fit('SONNET 5.5 VS GEMINI 4',ANT,730,100)); return im
def rail():
    im=clay(800,140,40,*LILAC).copy(); d=ImageDraw.Draw(im)
    ctext(d,400,38+6,'ARTIFICIAL ANALYSIS - 30 SEP 2026',fit('ARTIFICIAL ANALYSIS - 30 SEP 2026',ANT,740,48))
    ctext(d,400,98,'SONNET MAX / ARGON HIGH',ANT(48)); return im
def pill(txt,pal,col):
    im=clay(640,130,65,*pal).copy(); d=ImageDraw.Draw(im); ctext(d,320,68,txt,ANT(72),col); return im
def tile(txt,pal,fs):
    im=clay(800,170,55,*pal).copy(); d=ImageDraw.Draw(im); ctext(d,400,88,txt,fit(txt,ANT,740,fs)); return im
def chip(txt,pal):
    im=clay(800,112,40,*pal).copy(); d=ImageDraw.Draw(im); ctext(d,400,60,txt,fit(txt,ANT,750,56)); return im
def bench(name,a,b,q):
    im=clay(800,450,60,*CREAM).copy(); d=ImageDraw.Draw(im)
    ctext(d,400,62,name,ANT(56))
    for i,(lab,v,col,pal) in enumerate([('SONNET',a,(151,80,49,255),((222,171,141),(183,115,78))),('GEMINI',b,(51,91,185,255),((162,188,237),(87,127,202)))]):
        y=130+i*150
        d.text((50,y+28),lab,font=ANT(44),fill=INK,anchor='lm')
        d.text((750,y+28),str(int(round(v*q))),font=ANT(76),fill=col,anchor='rm')
        d.rounded_rectangle((50,y+75,750,y+111),18,fill=(228,233,240,255))
        fw=int(700*v/100*q)
        if fw>=36:
            d.rounded_rectangle((50,y+75,50+fw,y+111),18,fill=pal[1])
            d.rounded_rectangle((54,y+78,50+fw-4,y+90),8,fill=pal[0])
    return im
def word(txt,fnt,size,col):
    f=fnt(size); l=int(f.getlength(txt))+20; im=Image.new('RGBA',(l,int(size*1.15)),(0,0,0,0))
    ImageDraw.Draw(im).text((l//2,im.height//2),txt,font=f,fill=col,anchor='mm'); return im
def bar(txt):
    f=ANT(52); l=int(f.getlength(txt))+60; im=Image.new('RGBA',(l,100),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.rounded_rectangle((0,0,l,100),10,fill=(17,17,19,255)); d.text((l//2,52),txt,font=f,fill=(255,255,255,255),anchor='mm'); return im
# ---- timeline
def ease(x): x=min(1,max(0,x)); return x*x*x*(x*(6*x-15)+10)
BCP,BGP=(160,375),(776,375)
class A:
    def __init__(s,name,spr,kf,ph=0,dyn=None,fl=1.0): s.name,s.spr,s.kf,s.ph,s.dyn,s.fl=name,spr,kf,ph,dyn,fl
    def state(s,t):
        k=s.kf
        if t<k[0][0] or t>k[-1][0]: return None
        for i in range(len(k)-1):
            if k[i][0]<=t<=k[i+1][0]: break
        a,b=k[i],k[i+1]; e=ease((t-a[0])/(b[0]-a[0])) if b[0]>a[0] else 1
        v=[a[j]+(b[j]-a[j])*e for j in range(1,7)]
        x,y,sc,rot,al,_=v
        return x,y,sc,rot,al
# kf: (t,x,y,scale,rot,alpha,0)
def K(t,x,y,s=1,r=0,a=1): return (t,x,y,s,r,a,0)
C=(468,0)
assets=[]
def add(*a,**k): assets.append(A(*a,**k)); return assets[-1]
add('w1',word('Sonnet 5.5',SANS,124,INK),[K(0.0,468,430,.45,0,.4),K(0.8,468,368,1,0,1),K(3.0,468,368,1,0,1),K(3.8,468,330,.5,0,0)],0.5)
add('w2',word('vs',SANS,60,(120,126,138,255)),[K(0.0,468,480,.4,0,0),K(1.05,468,455,1,0,1),K(3.0,468,455,1,0,1),K(3.8,468,380,.4,0,0)],1.5)
add('w3',word('Gemini 4',SANS,124,INK),[K(0.0,468,590,.45,0,0),K(1.0,468,568,1,0,1),K(3.0,468,568,1,0,1),K(3.8,468,380,.5,0,0)],2.5)
add('claudeBig',brand('c'),[K(0.0,468,820,.3,-5,.5),K(1.7,262,840,1,-5,1),K(3.0,262,840,1,-5,1),K(4.2,160,375,.5,0,1),K(10.2,160,375,.5,0,1),K(11.0,300,400,.25,-3,0)],1.0)
add('geminiBig',brand('g'),[K(0.0,468,820,.3,5,.5),K(2.0,674,840,1,5,1),K(3.0,674,840,1,5,1),K(4.2,776,375,.5,0,1),K(10.2,776,375,.5,0,1),K(11.0,640,400,.25,3,0)],2.0)
add('rail',rail(),[K(1.8,468,1225,.7,0,0),K(2.8,468,1165,1,0,1),K(10.0,468,1165,1,0,1),K(10.9,468,1230,.6,0,0)],3.0)
add('tb',None,[K(3.2,160,375,.3,-6,0),K(4.5,468,725,1,-3,1),K(6.4,468,725,1,-3,1),K(7.5,200,560,.35,-5,0)],4.0,dyn=lambda t:bench('TERMINAL-BENCH 4.0',64,57,ease((t-4.7)/1.0)))
add('leadS',pill('SONNET LEADS',PEACH,(151,80,49,255)),[K(4.9,160,375,.3,4,0),K(5.9,468,1035,1,0,1),K(6.6,468,1035,1,0,1),K(7.5,200,1180,.45,-4,0)],5.0)
add('ab',None,[K(6.9,776,375,.3,6,0),K(8.2,468,725,1,3,1),K(10.0,468,725,1,3,1),K(11.0,736,560,.35,5,0)],6.0,dyn=lambda t:bench('AUTOMATIONBENCH-AA',71,78,ease((t-8.4)/1.0)))
add('leadG',pill('GEMINI LEADS',BLUE,(51,91,185,255)),[K(8.5,776,375,.3,-4,0),K(9.5,468,1035,1,0,1),K(10.2,468,1035,1,0,1),K(11.0,740,1180,.45,4,0)],7.0)
add('v1',tile('DIFFERENT TESTS.',PEACH,88),[K(10.4,160,375,.3,-5,0),K(11.5,468,380,1,0,1),K(14.9,468,380,1,0,1),K(15.0,468,380,1,0,1)],8.0)
add('v2',tile('DIFFERENT WINNERS.',BLUE,88),[K(10.7,776,375,.3,5,0),K(11.8,468,560,1,0,1),K(15.0,468,560,1,0,1)],9.0)
add('c1',chip('TERMINAL-BENCH  64 / 57',MINT),[K(11.0,200,1180,.35,-4,0),K(12.0,468,790,1,0,1),K(12.6,468,790,1,0,1),K(13.4,300,880,.5,0,0)],10.0)
add('c2',chip('AUTOMATIONBENCH  71 / 78',MINT),[K(11.3,740,1180,.35,4,0),K(12.3,468,930,1,0,1),K(12.9,468,930,1,0,1),K(13.5,640,880,.5,0,0)],11.0)
add('cta0',word('Comment',SANS,72,(120,126,138,255)),[K(12.9,468,1230,.4,0,0),K(13.7,468,800,1,0,1),K(15.0,468,800,1,0,1)],12.0)
add('cta',word('"VIDEO"',ANT,150,INK),[K(13.1,468,1230,.4,0,0),K(14.0,468,930,1,0,1),K(15.0,468,930,1,0,1)],12.6)
add('cav',bar('ARGON: LIMITED ROLLOUT'),[K(13.3,776,375,.3,4,0),K(14.3,468,1110,1,0,1),K(15.0,468,1110,1,0,1)],13.0)
# background
bg=Image.new('RGB',(W,H),(240,240,241))
pl=Image.new('RGB',(W,H),(240,240,241)); d=ImageDraw.Draw(pl)
d.ellipse((-300,-100,800,900),fill=(228,236,245)); d.ellipse((450,1000,1450,1900),fill=(245,234,236))
pl=pl.filter(ImageFilter.GaussianBlur(160)); bg=pl
dd=ImageDraw.Draw(bg)
for x in range(0,W,90): dd.line((x,0,x,H),fill=(228,229,232),width=1)
for y in range(0,H,90): dd.line((0,y,W,y),fill=(228,229,232),width=1)
shcache={}
def shadow(spr):
    a=spr.split()[3]; sm=a.resize((a.width//2,a.height//2)).filter(ImageFilter.GaussianBlur(16))
    sh=Image.new('RGBA',sm.size,(110,125,150,0)); sh.putalpha(sm.point(lambda v:int(v*.34)))
    return sh.resize(a.size)
def render(f,audit=None):
    t=f/FPS; im=bg.copy().convert('RGBA'); moving=0; info=[]
    for a in assets:
        st=a.state(t)
        if not st: continue
        x,y,sc,rot,al=st
        fl=a.fl*min(1,al*3)
        x+=9*math.sin(2*math.pi*(t/3.1+a.ph*.17)); y+=10*math.cos(2*math.pi*(t/2.7+a.ph*.23)); rot+=1.2*math.sin(2*math.pi*(t/4+a.ph*.3))
        sc*=1+.012*math.sin(2*math.pi*(t/2.3+a.ph*.1))
        if al<=0.01: continue
        spr=a.dyn(t) if a.dyn else a.spr
        w=max(2,int(spr.width*sc)); h=max(2,int(spr.height*sc))
        s2=spr.resize((w,h),Image.LANCZOS)
        sh=shadow(s2) if not a.name.startswith(('w','cta')) else Image.new('RGBA',s2.size,(0,0,0,0))
        s2s=sh.rotate(rot,expand=True,resample=Image.BICUBIC); s2=s2.rotate(rot,expand=True,resample=Image.BICUBIC)
        ca=s2.split()[3].point(lambda v:int(v*min(1,al))); s2.putalpha(ca)
        sa=s2s.split()[3].point(lambda v:int(v*min(1,al))); s2s.putalpha(sa)
        px,py=int(x-s2.width/2),int(y-s2.height/2)
        im.alpha_composite(s2s,(max(0,px+22),max(0,py+34))) if px+14>=0 and py+22>=0 else None
        im.alpha_composite(s2,(px,py)) if px>=0 and py>=0 and px+s2.width<=W and py+s2.height<=H else im.paste(s2,(px,py),s2)
        info.append((a.name,round(x,1),round(y,1),round(sc,3),round(al,2),px,py,px+s2.width,py+s2.height))
    return im.convert('RGB'),info
if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='still':
        for f in map(int,sys.argv[2:]): render(f)[0].save(f'/tmp/v12/s{f}.png')
    else:
        ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-i','/tmp/src/cues.wav','-t','15','-c:v','libx264','-preset','slow','-crf','16','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','/tmp/v12/v12.mp4'],stdin=subprocess.PIPE)
        log=[]
        for f in range(N):
            im,info=render(f); ff.stdin.write(im.tobytes()); log.append(info)
        ff.stdin.close(); ff.wait(); json.dump(log,open('/tmp/v12/log.json','w'))
