# Clay moves / track 02

Four original procedural 3D animation assets. Each foreground has a separate aligned shadow layer.

## Delivery specification

- Canvas: 720 x 1280 px, portrait 9:16.
- Timing: 4.00 seconds, 24 fps, 96 frames per clip.
- Video: VP9 WebM with alpha (YUVA 4:2:0 encoding of RGBA render frames).
- No sound, text, logos, faces or characters.
- Fixed three-quarter orthographic camera; warm directional lighting, pastel clay colours, soft surface grain and rounded edges.
- Transparent backgrounds. Preview checkerboards and warm backgrounds appear only in check PNGs, not in video assets.

## Clips

| Foreground | Move | Matching shadow |
| --- | --- | --- |
| `clips/01_liquid_morph.webm` | Coral sphere melts into a rounded cube through rippled intermediate shapes, rotates and returns to a sphere. | `shadows/01_liquid_morph_shadow.webm` |
| `clips/02_spiral_ascend.webm` | Small coloured clay spheres climb a two-turn helix beside fixed clay step beads. Spheres scale in and out at the ends for continuous circulation. | `shadows/02_spiral_ascend_shadow.webm` |
| `clips/03_card_fan.webm` | Seven rounded clay cards spread into a layered fan and regather into a neat stack. | `shadows/03_card_fan_shadow.webm` |
| `clips/04_jelly_chain.webm` | Six coloured clay blobs carry a phase-offset squash-stretch wave through a vertical chain. | `shadows/04_jelly_chain_shadow.webm` |

## Compositing

Put the shadow below the matching foreground, with both starting at frame 0. Use normal alpha compositing. The shadow is soft black on transparent pixels and may be dimmed or omitted. It is a stylised projected grounding layer, not a physically traced shadow pass.

All clips use cyclic motion and omit a duplicate closing frame. For the helix, endpoint scaling hides the bottom-to-top circulation reset. Leave the foreground and shadow synchronized when looping or retiming.

## Checks and source

- `checks/contact_sheet.png`: all four moves at 0, 1, 2 and 3 seconds on a warm background.
- `checks/*_CHECK.png`: 2-second decoded-video frames composited over a checkerboard with the corresponding shadow.
- `checks/*_foreground_*.png` and `checks/*_shadow_*.png`: original RGBA sample frames at 0, 1, 2 and 3 seconds.
- `checks/technical_validation.json`: actual probe metadata and decoded alpha extrema for all eight WebMs. All have 96 decoded frames, 720 x 1280 dimensions, 24 fps, 4-second duration and alpha metadata. Every layer was decoded with libvpx-vp9 to verify nonempty alpha and transparent pixels.
- `source/render.py`: editable procedural mesh, animation, material, camera and export code.
- `source/requirements.txt`: Python dependencies. The renderer also needs ffmpeg and an EGL-capable OpenGL runtime. Run `python3 source/render.py` to rebuild all clips.

The four-point contact sheet and full-size decoded check frames were visually inspected. Card lighting and fan spread were revised after the first check. The jelly chain's lateral motion was made cyclic before the final export.

## Compatibility

Alpha WebM is not supported equally by every player or editor. A player can show black behind the object when it ignores the alpha plane. Use an alpha-capable decoder; with ffmpeg, explicitly select `-c:v libvpx-vp9` before `-i`. PNG sample frames are provided for direct transparency inspection. These files are rendered animation assets, not a Blender project or physical clay simulation.
