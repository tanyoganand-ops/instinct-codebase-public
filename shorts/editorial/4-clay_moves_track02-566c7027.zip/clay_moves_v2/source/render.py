#!/usr/bin/env python3
"""Procedural 3D clay moves. Python 3 + numpy, Pillow, moderngl, ffmpeg."""
import os, math, json, subprocess
import numpy as np
from PIL import Image,ImageDraw,ImageFont
import moderngl
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
W,H,FPS,N=720,1280,24,96
ctx=moderngl.create_standalone_context(backend='egl')
ctx.enable(moderngl.DEPTH_TEST)
vs='''#version 330
in vec3 in_pos; in vec3 in_normal; uniform mat4 mvp; uniform mat4 model; out vec3 normal; out vec3 pos;
void main(){vec4 p=model*vec4(in_pos,1);pos=p.xyz;normal=mat3(transpose(inverse(model)))*in_normal;gl_Position=mvp*vec4(in_pos,1);}'''
fs='''#version 330
in vec3 normal;in vec3 pos;uniform vec3 color;out vec4 frag;
void main(){vec3 n=normalize(normal);vec3 l=normalize(vec3(-3,7,5));float d=max(dot(n,l),0);float fill=max(dot(n,normalize(vec3(4,2,-3))),0);float grain=sin(pos.x*92+sin(pos.y*61))*sin(pos.z*87+pos.y*113)*0.014;float h=pow(max(dot(n,normalize(l+normalize(vec3(6,4,9)-pos))),0),34);vec3 rgb=color*(0.49+0.48*d+0.12*fill+grain)+vec3(0.065)*h;frag=vec4(rgb,1);}'''
prog=ctx.program(vertex_shader=vs,fragment_shader=fs)
shadow_prog=ctx.program(vertex_shader='''#version 330
in vec3 in_pos;uniform mat4 mvp;out vec2 uv;void main(){uv=in_pos.xz;gl_Position=mvp*vec4(in_pos,1);}''',fragment_shader='''#version 330
in vec2 uv;uniform float opacity;out vec4 frag;void main(){float r=dot(uv,uv);float a=opacity*exp(-r*3.5)*smoothstep(1.0,0.7,r);frag=vec4(0,0,0,a);}''')
ms=ctx.framebuffer([ctx.renderbuffer((W,H),components=4,samples=4)],ctx.depth_renderbuffer((W,H),samples=4))
resolved=ctx.framebuffer([ctx.texture((W,H),4)])
cam=np.array([6.,4.2,9.]);target=np.array([0.,0.,0.]);f=(target-cam);f/=np.linalg.norm(f);r=np.cross(f,[0,1,0]);r/=np.linalg.norm(r);u=np.cross(r,f)
view=np.eye(4);view[:3,:3]=[r,u,-f];view[:3,3]=-view[:3,:3]@cam
# Large portrait safe area; scene fits 4.9 world-unit width.
a=2.45;b=a*H/W;proj=np.array([[1/a,0,0,0],[0,1/b,0,0],[0,0,-2/40,-1],[0,0,0,1.]])
VP=proj@view
COLORS=[(0.94,0.39,0.28),(0.35,0.65,0.72),(0.69,0.51,0.85),(0.97,0.72,0.28),(0.30,0.72,0.59),(0.91,0.58,0.67)]
def mat(pos=(0,0,0),scale=(1,1,1),rot=0,tilt=0):
 c,s=math.cos(rot),math.sin(rot);cx,sx=math.cos(tilt),math.sin(tilt)
 Ry=np.array([[c,0,s],[0,1,0],[-s,0,c]]);Rx=np.array([[1,0,0],[0,cx,-sx],[0,sx,cx]])
 M=np.eye(4);M[:3,:3]=Ry@Rx@np.diag(scale);M[:3,3]=pos;return M

def mesh(vertices,faces):
 v=np.array(vertices,dtype='f4');ix=np.array(faces,dtype='i4');n=np.zeros_like(v)
 tri=v[ix];norm=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
 for k in range(3): np.add.at(n,ix[:,k],norm)
 n/=np.maximum(np.linalg.norm(n,axis=1,keepdims=True),1e-8)
 vb=ctx.buffer(np.hstack((v,n)).astype('f4').tobytes());ib=ctx.buffer(ix.astype('i4').tobytes())
 return ctx.vertex_array(prog,[(vb,'3f 3f','in_pos','in_normal')],ib),vb,ib

U,V=80,48
phi=np.linspace(0,2*np.pi,U+1);theta=np.linspace(0,np.pi,V+1)
PH,TH=np.meshgrid(phi,theta)
base=np.stack([np.sin(TH)*np.cos(PH),np.cos(TH),np.sin(TH)*np.sin(PH)],axis=-1).reshape(-1,3)
faces=[]
for j in range(V):
 for i in range(U):
  a0=j*(U+1)+i;b0=a0+U+1
  faces.extend([[a0,b0,a0+1],[a0+1,b0,b0+1]])
# outward normals, verify orientation then reverse if necessary.
faces=np.array(faces)[:,::-1]
sphere=mesh(base,faces)

def card_mesh():
 pts=[];corner=0.20
 for cx,cz,angle in [(0.94,0.58,0),(-0.94,0.58,90),(-0.94,-0.58,180),(0.94,-0.58,270)]:
  for a0 in np.linspace(angle,angle+90,12,endpoint=False):
   a0=np.radians(a0);pts.append((cx+corner*np.cos(a0),cz+corner*np.sin(a0)))
 # perimeter order: start top-right, sweep round rect.
 verts=[]
 for y,shrink in [(-.060,.045),(-.025,0),(.025,0),(.060,.045)]:
  verts.extend([(x*(1-shrink),y,z*(1-shrink)) for x,z in pts])
 L=len(pts);fs=[]
 for ring in range(3):
  for i in range(L):
   k=ring*L+i;n=ring*L+(i+1)%L
   fs.extend([[k,n,k+L],[n,n+L,k+L]])
 verts.extend([(0,-.060,0),(0,.060,0)])
 for i in range(L):
  n=(i+1)%L;fs.extend([[4*L,n,i],[4*L+1,3*L+i,3*L+n]])
 return mesh(verts,np.array(fs)[:,::-1])
card=card_mesh()
quad=ctx.buffer(np.array([[-1,0,-1],[1,0,-1],[-1,0,1],[1,0,1]],dtype='f4').tobytes())
shadowvao=ctx.vertex_array(shadow_prog,[(quad,'3f','in_pos')])

def draw(geo,M,color):
 prog['mvp'].write((VP@M).T.astype('f4').tobytes());prog['model'].write(M.T.astype('f4').tobytes());prog['color'].value=color;geo[0].render()

def shadow(pos,size,opacity):
 M=mat((pos[0],-2.7,pos[2]),(size[0],1,size[1]))
 shadow_prog['mvp'].write((VP@M).T.astype('f4').tobytes());shadow_prog['opacity'].value=opacity;shadowvao.render(moderngl.TRIANGLE_STRIP)

def smooth(t):return t*t*(3-2*t)
def scene(name,t):
 objs=[];dynamic=[]
 if name=='01_liquid_morph':
  # sphere -> rounded cube -> sphere; transient axial liquid bulges.
  blend=(1-math.cos(2*math.pi*t))/2
  p=2+5*blend
  radius=np.sum(np.abs(base)**p,axis=1)**(-1/p)
  v=base*radius[:,None]
  wave=np.sin(TH.reshape(-1)*3+2*math.pi*t)*np.sin(PH.reshape(-1)*2-4*math.pi*t)
  v*= (1+0.11*math.sin(math.pi*blend)*wave)[:,None]
  v[:,1]+=0.17*math.sin(2*math.pi*t)*np.sin(TH.reshape(-1))**2
  geo=mesh(v,faces);dynamic.append(geo)
  objs=[(geo,mat((0,.1+0.12*math.sin(2*math.pi*t),0),(1.37,1.37,1.37),rot=.35+2*math.pi*t),COLORS[0],(0,0,0),(1.6,1.25),.22)]
 elif name=='02_spiral_ascend':
  # Closed helical circulation: small spheres step upwards and arc back in depth.
  for k in range(11):
   q=(t+k/11)%1;ang=4*math.pi*q
   y=-2.25+4.5*q
   pos=(1.05*math.cos(ang),y,1.05*math.sin(ang))
   step=math.sin(q*22*math.pi)**2
   sy=1-.13*step;sx=1/math.sqrt(sy)
   fade=min(1,q/.055,(1-q)/.055);fade=max(.001,smooth(max(0,fade)))
   sx*=fade;sy*=fade
   objs.append((sphere,mat(pos,(.265*sx,.265*sy,.265*sx)),COLORS[k%6],pos,(.47,.38),.075*(1-q)))
  # Raised stair beads provide the fixed spiral visual landmark.
  for k in range(20):
   q=k/19;ang=4*math.pi*q;pos=(1.27*math.cos(ang),-2.33+4.5*q,1.27*math.sin(ang))
   objs.append((sphere,mat(pos,(.14,.05,.14)),(.83,.77,.66),pos,(.24,.19),.022))
 elif name=='03_card_fan':
  openv=smooth((1-math.cos(2*math.pi*t))/2)
  for k in range(7):
   signed=k-3;rot=signed*.34*openv
   pos=(signed*.28*openv,-.7+k*.18+openv*.15,abs(signed)*.18*openv)
   objs.append((card,mat(pos,rot=rot,tilt=-.17*openv),COLORS[k%6],pos,(1.38,.82),.075))
 elif name=='04_jelly_chain':
  for k in range(6):
   phase=2*math.pi*t-k*.72;stretch=1+.28*math.sin(phase)
   pos=(.65*math.sin(k*.85+.22*math.sin(phase)),-2.05+k*.79+.085*math.sin(phase),.22*math.cos(k*.9))
   sc=(.62/math.sqrt(stretch),.44*stretch,.62/math.sqrt(stretch))
   objs.append((sphere,mat(pos,sc,rot=.1*k),COLORS[k],pos,(.85,.55),.055))
 return objs,dynamic

def render(name,frame,layer):
 t=frame/N;objs,dyn=scene(name,t)
 ms.use();ms.clear(0,0,0,0,depth=1)
 if layer=='foreground':
  ctx.enable(moderngl.DEPTH_TEST);ctx.disable(moderngl.BLEND)
  for geo,M,col,pos,size,op in objs:draw(geo,M,col)
 else:
  ctx.disable(moderngl.DEPTH_TEST);ctx.enable(moderngl.BLEND)
  ctx.blend_func=(moderngl.SRC_ALPHA,moderngl.ONE_MINUS_SRC_ALPHA,moderngl.ONE,moderngl.ONE_MINUS_SRC_ALPHA)
  for geo,M,col,pos,size,op in objs:shadow(pos,size,op)
 ctx.copy_framebuffer(resolved,ms)
 im=Image.frombytes('RGBA',(W,H),resolved.read(components=4,alignment=1)).transpose(Image.Transpose.FLIP_TOP_BOTTOM)
 for geo in dyn:
  for x in geo:x.release()
 return im

def encode(path):
 return subprocess.Popen(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo','-pix_fmt','rgba','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-an','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','24','-deadline','good','-cpu-used','5','-row-mt','1','-threads','4','-metadata:s:v:0','alpha_mode=1',path],stdin=subprocess.PIPE)
NAMES=['01_liquid_morph','02_spiral_ascend','03_card_fan','04_jelly_chain']
if __name__=='__main__':
 import sys
 names=sys.argv[1:] or NAMES
 for name in names:
  for layer,folder in [('foreground','clips'),('shadow','shadows')]:
   enc=encode(os.path.join(ROOT,folder,name+('_shadow' if layer=='shadow' else '')+'.webm'))
   for i in range(N):
    im=render(name,i,layer);enc.stdin.write(im.tobytes())
    if i in [0,24,48,72]: im.save(os.path.join(ROOT,'checks',f'{name}_{layer}_{i:03d}.png'))
   enc.stdin.close();assert enc.wait()==0
  print(name,'complete',flush=True)
