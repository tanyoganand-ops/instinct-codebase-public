import math, subprocess, json, sys
from build import *
import build as B
F=lambda s: s*FPS
def eo(x): x=min(1,max(0,x)); return 1-(1-x)**3
GREY=(168,172,180); 
class N:
    def __init__(s,name,spr,t_in,t_out,rest,kind='left',dyn=None,ph=0,fl=1,dur=None):
        s.name,s.spr,s.t_in,s.t_out,s.rest,s.kind,s.dyn,s.ph,s.fl=name,spr,t_in,t_out,rest,kind,dyn,ph,fl
    def state(s,t):
        if t<s.t_in or t>=s.t_out: return None
        x,y,sc,rot=s.rest; dt=(t-s.t_in)*FPS; al=1
        if s.kind in('left','right'):
            d=-1 if s.kind=='left' else 1
            al=min(1,dt/3)
            if dt<4: p=dt/4; x=x-d*330+(330+d*24)*p*1 ; x=(x if True else x)
            elif dt<16: x=x+d*24*(1-ease((dt-4)/12))
            if dt<4: x=rest_x=s.rest[0]-d*330*(1-dt/4)+d*24*(dt/4)
            sc*=1
        elif s.kind=='top':
            e=eo(dt/24); y=y-140*(1-e); al=min(1,dt/6)
        elif s.kind=='bottom':
            e=eo(dt/24); y=y+140*(1-e); al=min(1,dt/6)
        elif s.kind=='zoom':
            e=eo(dt/25); sc*=.15+.85*e; ox,oy=s.dyn_from; x=ox+(x-ox)*e; y=oy+(y-oy)*e; al=min(1,dt/4)
        elif s.kind=='word':
            e=eo(dt/25); y=y+50*(1-e); al=min(1,dt/10)
        return x,y,sc,rot,al
def mkword(txt,fnt,size,col):
    def fn(t,self=None): pass
    return None
assets=[]
def add(*a,**k): assets.append(N(*a,**k)); return assets[-1]
def wordspr(txt,fnt,size,col):
    def g(t0):
        def f(t):
            e=eo((t-t0)*FPS/25); c=tuple(int(GREY[i]+(col[i]-GREY[i])*e) for i in range(3))+(255,)
            return word(txt,fnt,size,c)
        return f
    return g
INKc=(42,47,58); MUT=(120,126,138)
BCP,BGP=(160,375),(776,375)
# Scene A 0-3.4
for i,(txt,fnt,sz,col,y,t0) in enumerate([('Sonnet 5.5',SANS,124,INKc,368,0.0),('vs',SANS,60,MUT,455,0.3),('Gemini 4',SANS,124,INKc,568,0.55)]):
    add('w%d'%i,None,t0,3.4,(468,y,1,0),'word',dyn=wordspr(txt,fnt,sz,col)(t0),ph=i)
add('claudeBig',brand('c'),0.05,3.4,(262,840,1,-5),'left',ph=1)
add('geminiBig',brand('g'),0.2,3.4,(674,840,1,5),'right',ph=2)
add('rail',rail(),1.6,10.2,(468,1165,1,0),'bottom',ph=3)
# Scene B 3.2-6.8
a=add('claudeBadge',brand('c'),3.2,10.2,(160,375,.5,0),'zoom',ph=1); a.dyn_from=(160,375)
a=add('geminiBadge',brand('g'),3.3,10.2,(776,375,.5,0),'zoom',ph=2); a.dyn_from=(776,375)
add('tb',None,3.5,6.8,(468,725,1,-3),'left',dyn=lambda t:bench('TERMINAL-BENCH 4.0',64,57,ease((t-4.2)/1.0)),ph=4)
add('leadS',pill('SONNET LEADS',PEACH,(151,80,49,255)),5.0,6.8,(468,1020,1,2),'right',ph=5)
# Scene C 6.7-10.2
add('ab',None,6.7,10.2,(468,725,1,3),'right',dyn=lambda t:bench('AUTOMATIONBENCH-AA',71,78,ease((t-7.4)/1.0)),ph=6)
add('leadG',pill('GEMINI LEADS',BLUE,(51,91,185,255)),8.3,10.2,(468,1020,1,-2),'left',ph=7)
# Scene D 10.1-12.6
add('v1',tile('DIFFERENT TESTS.',PEACH,88),10.0,15.1,(468,380,1,-1.5),'left',ph=8)
add('v2',tile('DIFFERENT WINNERS.',BLUE,88),10.2,15.1,(468,560,1,1.5),'right',ph=9)
add('c1',chip('TERMINAL-BENCH  64 / 57',MINT),10.6,12.6,(468,800,1,0),'top',ph=10)
add('c2',chip('AUTOMATIONBENCH  71 / 78',MINT),11.2,12.6,(468,935,1,0),'top',ph=11)
# Scene E 12.6-15
add('cta0',None,12.6,15.1,(468,800,1,0),'word',dyn=wordspr('Comment',SANS,72,MUT)(12.6),ph=12)
a=add('cta',word('"VIDEO"',ANT,150,INKc+(255,)),13.0,15.1,(468,930,1,0),'zoom',ph=13); a.dyn_from=(468,930)
class Wipe(N):
    pass
add('cav',None,13.9,15.1,(468,1110,1,0),'left',dyn=None,ph=14)
cavspr=bar('ARGON: LIMITED ROLLOUT'); assets[-1].spr=cavspr
def dyn_wipe(t):
    p=eo((t-13.9)*FPS/8); w=max(2,int(cavspr.width*p)); im=Image.new('RGBA',cavspr.size,(0,0,0,0)); im.paste(cavspr.crop((0,0,w,cavspr.height)),(0,0)); return im
assets[-1].dyn=dyn_wipe; assets[-1].kind='wipe'
_old=N.state
def st(s,t):
    if s.kind=='wipe':
        if t<s.t_in or t>=s.t_out: return None
        return s.rest[0],s.rest[1],1,0,1
    return _old(s,t)
N.state=st
# bg dots instead of grid
bg2=B.bg.copy()
bgp=Image.new('RGB',(W,H),(240,240,241)); pl=Image.new('RGB',(W,H),(240,240,241)); d=ImageDraw.Draw(pl)
d.ellipse((-300,-100,800,900),fill=(228,236,245)); d.ellipse((450,1000,1450,1900),fill=(245,234,236)); pl=pl.filter(ImageFilter.GaussianBlur(160)); dd=ImageDraw.Draw(pl)
for y in range(45,H,60):
    for x in range(45,W,60): dd.ellipse((x-1.6,y-1.6,x+1.6,y+1.6),fill=(212,215,220))
BG=pl
def render(f):
    t=f/FPS; im=BG.copy().convert('RGBA'); info=[]
    for a in assets:
        st_=a.state(t)
        if not st_: continue
        x,y,sc,rot,al=st_
        x+=9*math.sin(2*math.pi*(t/3.1+a.ph*.17)); y+=10*math.cos(2*math.pi*(t/2.7+a.ph*.23)); rot+=1.0*math.sin(2*math.pi*(t/4+a.ph*.3))
        sc*=1+.012*math.sin(2*math.pi*(t/2.3+a.ph*.1))
        spr=a.dyn(t) if a.dyn else a.spr
        w=max(2,int(spr.width*sc)); h=max(2,int(spr.height*sc))
        s2=spr.resize((w,h),Image.LANCZOS)
        isw=a.name.startswith(('w','cta'))
        sh=Image.new('RGBA',s2.size,(0,0,0,0)) if isw else shadow(s2)
        sh=sh.rotate(rot,expand=True,resample=Image.BICUBIC); s2=s2.rotate(rot,expand=True,resample=Image.BICUBIC)
        for q in (s2,sh):
            q.putalpha(q.split()[3].point(lambda v:int(v*min(1,al))))
        px,py=int(x-s2.width/2),int(y-s2.height/2)
        im.paste(sh,(px+22,py+34),sh); im.paste(s2,(px,py),s2)
        info.append((a.name,round(x,1),round(y,1),round(sc,3),round(al,2),px,py,px+s2.width,py+s2.height))
    return im.convert('RGB'),info
if __name__=='__main__':
    if sys.argv[1]=='still':
        fs=list(map(int,sys.argv[2:])); sh=Image.new('RGB',(360*len(fs),640))
        for i,f in enumerate(fs): sh.paste(render(f)[0].resize((360,640)),(i*360,0))
        sh.save('/tmp/v12/sheet2.png')
    else:
        ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s','1080x1920','-r','30','-i','-','-i','/tmp/src/cues.wav','-t','15','-c:v','libx264','-preset','slow','-crf','16','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-shortest','/tmp/v12/v12b.mp4'],stdin=subprocess.PIPE)
        log=[]
        for f in range(N_ if False else 450):
            im,info=render(f); ff.stdin.write(im.tobytes()); log.append(info)
        ff.stdin.close(); ff.wait(); json.dump(log,open('/tmp/v12/log2.json','w'))
